<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap.Min.CSS  -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <!-- Owl.Carousel.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- Owl.Theme.Default.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
        <!-- Animate.CSS -->
		<link rel="stylesheet" href="../assets/css/animate.css">
        <!-- Font-Awesome.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
		<link rel="stylesheet" href="../assets/css/fontello.css">
        <!-- Flaticon.CSS -->
        <link rel="stylesheet" href="../assets/font/flaticon.css">
        <!-- Magnific-Popup.CSS -->
		<link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- Style.CSS -->
        <link rel="stylesheet" href="../assets/css/style.css">
        <!-- Responsive.CSS -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="../assets/img/favicon.png">

        <!-- TITLE -->
        <title>NEPRA | Licences Generation WAPDA Hydel</title>

    </head>

    <body>

        <!-- Start Preloader Section -->
        <div class="preloader">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
        <!-- End Preloader Section -->

        <head>
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle7.css"><script>
if (window.self !== window.top) {
  window.top.location = window.self.location;
}
</script>
</head>
<!-- Start Header Section -->
         <!-- Start Header Section -->
        <header class="header header-style-one header-style-four">
           <div class="header-wrapper-one header-wrapper-four">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-3" align="right">
                            <a class="navbar-brand" href="../index.php">
                                <img src="https://nepra.org.pk/assets/img/nepra.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-8 col-md-7">
						<h2 align="center" class="header-Filing-titleArea style="color:#fff">National Electric Power Regulatory Authority</h2> <h4 align="center" class="headerSec-Filing-titleArea" style="padding-top:5px;color:#fff">Islamic Republic of Pakistan</h4> 
                        </div>
						<div class="col-lg-2 col-md-2">
                                    <div class="right-btn">
                                        <a href="" data-toggle="modal" data-target="#myModal2">
                                            <ul class="contact-info contact-info-three four">
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                            </ul>
                                        </a>
                                    </div>
                      </div>
						
                  </div>
              </div>
          </div>
            </div>
            <!-- End header-wrapper-Four -->

            <!-- Start Navbar Area -->
		    <div class="navbar-area">
                <!-- Menu For Mobile Device -->
                <div class="mobile-nav">
                    <a href="index.php" class="logo">
                        <img src="https://nepra.org.pk/assets/img/logo.png" alt="">
                    </a>
                </div>
    
                <!-- Menu For Desktop Device -->
                <div class="construction-nav-one construction-nav-four">
                    <div class="container">
                        <nav class="navbar navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/index.php" class="nav-link">Home</a> </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">About Us</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/About.php">About NEPRA</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Authority.php">The Authority</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Management.php">Sr. Management</a>                                            </li>
											
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/careers.php">Careers</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/tenders.php">Tenders</a>                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Legal.php" class="nav-link">Legal</a>									</li>
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Licences</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Concurrences.php">Concurrences</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation GENCOs.php">GENCOs</a>  </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation K-Electric.php">K-Electric</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IPPs.php">IPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Netmetering.php">Net-Metering</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IGCs.php">IGCs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation SPPs.php">SPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation CPPs.php">CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NCPPs.php">N-CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NPPs.php">NPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation WAPDA Hydel.php">WAPDA Hydel</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Distributed Generation.php">Distributed Generation</a>                                                    </li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Transmission.php">Transmission</a>                                          </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Industrial Estates.php">Industrial Estates</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution CPPs.php">CPPs</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution SPPs.php">SPPs</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Independent System and Market Operator.php" class="nav-link">ISMO</a>   
								            </li>
											 
											 <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Electric Power Suppliers</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Suppliers of Last Resort.php">Suppliers of Last Resort</a>                                                    </li>
                                                    
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Special Purpose Agent.php">Special Purpose Agent</a>
								             </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/elicensing" class="nav-link">e-Licensing</a>   
								             </li>  
											  
											   
                                        </ul>
                                    </li> 
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Tariff</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation K-Electric.php">K-Electric</a></li>
                                                        <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation GENCOs.php">GENCOs</a></li>

                                                   <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation WAPDA Hydroelectric.php">WAPDA Hydroelectric</a></li>
												    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation IPPs.php">IPPs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Upfront.php">UP-front</a></li>
													
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Benchmark.php">Benchmark</a></li>
													
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation CPPs.php">CPPs</a></li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Transmission</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission NTDC.php">NTDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission HVDC.php">HVDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission STDCPL.php">ST&DCPL</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution WAPDA.php">WAPDA</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Market Operators.php" class="nav-link">Market Operators</a>                                          </li> 
											 <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Petitions.php" class="nav-link">Petitions</a>                                             </li>      
                                        </ul>
                                    </li>   
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Consumer Affairs</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" target="_blank" href="https://nepra.org.pk/consumer affairs/cad/NEPRA Asaan Approach1.jpg">NEPRA Asaan Approach</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/cregister.php">Register Complaint</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/tcomplaint.php">Track a Complaint</a>                                            </li>
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Authority Decisions.php">Authority Decisions</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Appellate Board.php">Appellate Board</a>                                            </li>
											
											
												<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Understand Your Electricity Bill.php">Understand Electricity Bill</a>                                            </li>
                                        </ul>
                                    </li>
                                   
                                    
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">M & E</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/M&E/Orders%20of%20the%20Authority.php">Orders of the Authority</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/dxp/">Data Exchange Portal</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Performance%20Reports.php">Performance Evaluation Reports</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Inquiry%20Reports.php">Inquiry Reports</a> </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Publications</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Annual Reports.php">Annual Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/State of Industry Reports.php">State of Industry Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/News Letters.php">News Letters</a></li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Performance Reports.php">Performance Reports</a></li>
                                        </ul>
                                    </li>
									
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/news.php" class="nav-link">News</a>                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Suggestions</a>
                                        <ul class="dropdown-menu">
                                           
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Suggestion Box.php">NEPRA Employees Only</a></li>
                                        </ul>
                                    </li>
									
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Contact.php" class="nav-link">contact</a>                                    </li>
                                     
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div><!-- End Navbar Area -->
        </header> 
		<!-- End Header Section -->

        <!-- Start Sidebar Modal -->
		<div class="sidebar-modal">  
            <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="flaticon-close-cross"></i></span></button>

                            <h2 class="modal-title" id="myModalLabel2"><a href="index.php"><img src="https://nepra.org.pk/assets/img/logo.png" alt="logo"></a></h2>
                        </div>

                        <div class="modal-body">
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Additional Links</h3>

                                <ul>
                                    <li><a href="https://nepra.org.pk/energyweek.php">NEPRA Energy Week</a></li>
									<li><a href="https://nepra.org.pk/Media%20Gallery.php">Media Gallery</a></li>
									<li><a href="https://nepra.org.pk/Power Policies.php">Power Policies</a></li>
                                    
                                    <li><a href="https://nepra.org.pk/consumer affairs/Electricity Bill.php">Applicable Tariff</a></li>
                                    <li><a href="https://webmail.nepra.org.pk:2096/">E-mail (NEPRA Officials Only)</a></li>
                                </ul>
                            </div>
                            
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Contact Info</h3>

                                <ul class="contact-info">
                                    <li>
                                        <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
                                        Address
                                        <span>NEPRA Tower G-5/1, Islamabad, Pakistan</span>
                                    </li>
                                    <li>
                                        <i class="flaticon-close-envelope"></i>
                                        Email
                                        <span><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="c7aea9a1a887a9a2b7b5a6e9a8b5a0e9b7ac">[email&#160;protected]</a></span>
                                    </li>
                                    <li>
                                        <i class="flaticon-telephone-handle-silhouette"></i>
                                        Phone
                                        <span>+92 51 2013200</span>
                                    </li>
									<li>
                                        <i class="flaticon-call"></i>
                                        Fax
                                        <span>+92 51 9210215</span>
                                    </li>
                                </ul>
                            </div>

                            <div class="sidebar-modal-widget">
                                <h3 class="title">Connect With Us</h3>

                                <ul class="social-list">
                                    <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://webmail.nepra.org.pk/"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
        </div>
        <div align="justify">
          <!-- End Sidebar Modal -->        <!-- End Header Section -->

        <!-- Start Page Banner Section -->
        <section class="banner-section nepra-ipps-hydel">
            <div class="d-table">
                <div class="d-tablecell">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title">
                                    <h2>Licences Generation <span>WAPDA Hydel</span></h2>
                                    <ul> 
                                        <li><a href="../index.php">home <i class="flaticon-right"></i> </a>
                                        <li>WAPDA Hydel</li>
                                    </ul>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </section>
        <!-- End Page Banner Section -->

        <!-- Start Blogs Section -->
         <section class="team-man-section team-man-section-two ptb-100">
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-12 col-md-6 col-sm-6">
                        
                            
                            <div class="blogs-content">
                                
									<!-- Accordions -->
						<ul class="accordions">
								
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6> WAPDA Hydel</h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									 <tr > 
                  <td width="50%" > 
                   
                      <div align="center">Gross 
						Capacityy</div></td>
                            
                  <td width="50%" style="text-align:center" > 
                    
					<div align="center">17,367.96 MW</div></td>
                </tr>
                <tr > 
                  <td > 
                   
                      <div align="center">Licence No. </div></td>
                            <td style="text-align:center" >
                            
							  <div align="center">GL(Hydel)/05/2004</div></td>
                </tr>
                <tr> 
                  <td > 
                   
                      <div align="center">Licence Details</div></td>
                  <td style="text-align:center"> 
                   
							<div align="center"><a target="_blank" href="Licences/Generation/wapda%20hydel/LAG-23%20Generation%20Licence%20WAPDA-dated%2003-11-2004.PDF" class="default-btn">View
					  </a>					      </div></td>
                </tr>
                <tr>
                  <td > 
                    <div align="center">Licence 
                    Modification -I</div></td>
                  <td style="text-align:center"> 
                  			<div align="center"><a target="_blank" href="Licences/Generation/wapda%20hydel/LAG-23%20Modification%20in%20Generation%20Lic%20-dated%2027-06-2008.PDF" class="default-btn">View
           			  </a>           			      </div></td>
                </tr>
                <tr> 
                  <td > 
                    <div align="center">Licence 
                    Modification -II</div></td>
                  <td style="text-align:center"> 
                  			<div align="center"><a target="_blank" href="Licences/Generation/wapda%20hydel/Modification-II%20of%20WAPDA%20Hydel%20dated%2020-06-2011.PDF" class="default-btn">View
           			  </a>           			      </div></td>
                </tr>
                <tr> 
                  <td > 
                    <div align="center">Licence 
                    Modification -III</div></td>
                  <td style="text-align:center"> 
                  			<div align="center"><a href="Licences/Generation/wapda%20hydel/LAG-23%20WAPDA%20MODIFICATION-III%20GEN%20LIC%2017-01-2014%20684-85.PDF" class="default-btn">View</a> </div></td>
                </tr>
                						<tr>
                  <td > 
                    <div align="center">Licence 
                    Modification -IV</div></td>
                  <td style="text-align:center"> 
                  			<div align="center"><a target="_blank" href="Licences/Generation/wapda%20hydel/LAG-23%20Modification-IV%20WAPDA%20HYDEL%2009-01-2015.PDF" class="default-btn">View</a> </div></td>
                						</tr>
                						<tr>
                  <td > 
                    <div align="center">Licence 
                    Modification -V</div></td>
                  <td style="text-align:center"> 
                  			<div align="center">
								<a target="_blank" class="default-btn" href="Licences/Generation/wapda%20hydel/LAG-23%20Mod%20in%20GL%20WAPDA%20Hydel%20Power%20Stations%2007-04-2020.PDF">View</a> </div></td>
                						</tr>
                <tr> 
                  <td > 
                    <div align="center">Licence 
                    Modification -VI &amp; VII</div></td>
                  <td style="text-align:center"> 
                  			<div align="center">
								<a target="_blank" class="default-btn" href="Licences/Generation/wapda%20hydel/LAG-23%20LPM%20of%20WAPDA%20Hydel%2001-03-2024%203158-79.PDF">View</a> </div></td>
                </tr>
								</table>
								
									 
								</div>
								
							</li>
							<!-- /Accordion -->
							
							
						</ul>
						<!-- /Accordions -->						
					
                                
                            </div>
                        </div>
						</div>
                   
                       
                    

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Blogs Section -->

        
        
       
         <!-- Start Top Footer Section -->
		<!-- Start Top Footer Section -->
        <footer class="footer-top footer-top-four">
            <div class="container">
                <div class="row">
                    
					<div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Contact</h3>
                            <ul>
                               
								<li>
                                    National Electric Power Regulatory Authority
                                </li>
								<li>
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
									
                                    
                                    NEPRA Tower, G-5/1, Islamabad 
                                </li>
                                <li>
                                    <i class="flaticon-mail-black-envelope-symbol"></i>
                                    
                                    <a href="/cdn-cgi/l/email-protection#a4cdcac2cbe4cac1d4d6c58acbd6c38ad4cf"><span class="__cf_email__" data-cfemail="61080f070e210f041113004f0e13064f110a">[email&#160;protected]</span></a>                                </li>
                                <li>
                                    <i class="flaticon-telephone-handle-silhouette"></i>
                                    
                                    +92 51 2013200 
                                </li>
                                <li>
                                    <i class="flaticon-call"></i>
                                    
                                    +92 51 9210215  
                                </li>
								
                            </ul>
                        </div>

                    </div>
					
                    
                    <div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Important Links</h3>
                            <ul>
                                
                                <li>
								<li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="https://www.sifc.gov.pk">SIFC</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="licensing/Licences/SOPs/Timelines flow chart check list.pdf">SOPs of Licensing</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Power Policies.php">Power Policies</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Admission%20Notices/2019/Intervention%20Request%20Form.pdf" target="_blank">Intervention Request Form</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://webmail.nepra.org.pk:2096/" target="_blank">E-mail (NEPRA Officials Only)</a>                                </li>
                                
                            </ul>
                        </div>
                    </div>
					 <div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                            <h3>Search Website</h3>
                            <div><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://cse.google.com/cse.js?cx=014945713357202780521:kaf1vdqbqiv"></script>
<div class="gcse-searchbox-only"></div></div> <br>
<a href="https://play.google.com/store/apps/details?id=com.govpk.citizensportal&hl=en"><img src="../assets/img/Pakistan Citzen Portal Banner.png" /></a>                    </div>
                    
                </div>
           
			<div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                           
<img src="../assets/img/FBR - ABI Flyer.jpg" />                  </div>
                    
                </div>
            </div>
        </footer>
        <!-- End Top Footer Section -->

        <!-- Start Bottom Footer Section -->
        <footer class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <ul>
                                <li>
                                    <p>NEPRA Copyright 2023. All Rights Reserved.</p> </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <p><i class="flaticon-clock-of-circular-shape-outline"></i> Open Hours 9:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                        <div class="single-widgets">
                            <ul class="social-links">
                                <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://mail.nepra.org.pk"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        
        <!-- End Bottom Footer Section -->		<!-- Stop  Footer Section -->
     

        <!-- Jquery-3.2.1.Slim.Mim.JS -->
       <script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/jquery.waypoints.min.js"></script>
<script src="../assets/js/owl.carousel.min.js"></script>
        <!-- Popper.Mim.JS -->
        <script src="../assets/js/popper.min.js"></script>
        <!-- Bootstrap.Mim.JS -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- Meanmenu.JS -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- Magnific.Popup.Min.JS -->
	    <script src="../assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl.Carousel.Min.JS -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- Wow.Min.JS -->
		<script src="../assets/js/wow.min.js"></script>
        <!-- Waypoints.Min.JS -->
		<script src="../assets/js/waypoints.min.js"></script>
		<!-- Jquery.Counterup.Min.JS -->
		<script src="../assets/js/jquery.counterup.min.js"></script>
		<!-- Jquery.Mixitup.Min.JS -->
		<script src="../assets/js/jquery.mixitup.min.js"></script>
        <!-- Active.JS -->
        <script src="../assets/js/active.js"></script>
		<script src="../assets/js/script.js"></script>
    </body>
</html>