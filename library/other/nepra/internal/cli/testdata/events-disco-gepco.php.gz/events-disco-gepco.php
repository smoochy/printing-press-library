<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap.Min.CSS  -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <!-- Owl.Carousel.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- Owl.Theme.Default.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
        <!-- Animate.CSS -->
		<link rel="stylesheet" href="../assets/css/animate.css">
        <!-- Font-Awesome.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
		<link rel="stylesheet" href="../assets/css/fontello.css">
        <!-- Flaticon.CSS -->
        <link rel="stylesheet" href="../assets/font/flaticon.css">
        <!-- Magnific-Popup.CSS -->
		<link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- Style.CSS -->
        <link rel="stylesheet" href="../assets/css/style.css">
        <!-- Responsive.CSS -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="../assets/img/favicon.png">

        <!-- TITLE -->
        <title>NEPRA | Tariff Distribution GEPCO</title>

    </head>

    <body>

        <!-- Start Preloader Section -->
        <div class="preloader">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
        <!-- End Preloader Section -->

        <head>
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle7.css"><script>
if (window.self !== window.top) {
  window.top.location = window.self.location;
}
</script>
</head>
<!-- Start Header Section -->
         <!-- Start Header Section -->
        <header class="header header-style-one header-style-four">
           <div class="header-wrapper-one header-wrapper-four">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-3" align="right">
                            <a class="navbar-brand" href="../index.php">
                                <img src="https://nepra.org.pk/assets/img/nepra.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-8 col-md-7">
						<h2 align="center" class="header-Filing-titleArea style="color:#fff">National Electric Power Regulatory Authority</h2> <h4 align="center" class="headerSec-Filing-titleArea" style="padding-top:5px;color:#fff">Islamic Republic of Pakistan</h4> 
                        </div>
						<div class="col-lg-2 col-md-2">
                                    <div class="right-btn">
                                        <a href="" data-toggle="modal" data-target="#myModal2">
                                            <ul class="contact-info contact-info-three four">
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                            </ul>
                                        </a>
                                    </div>
                      </div>
						
                  </div>
              </div>
          </div>
            </div>
            <!-- End header-wrapper-Four -->

            <!-- Start Navbar Area -->
		    <div class="navbar-area">
                <!-- Menu For Mobile Device -->
                <div class="mobile-nav">
                    <a href="index.php" class="logo">
                        <img src="https://nepra.org.pk/assets/img/logo.png" alt="">
                    </a>
                </div>
    
                <!-- Menu For Desktop Device -->
                <div class="construction-nav-one construction-nav-four">
                    <div class="container">
                        <nav class="navbar navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/index.php" class="nav-link">Home</a> </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">About Us</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/About.php">About NEPRA</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Authority.php">The Authority</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Management.php">Sr. Management</a>                                            </li>
											
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/careers.php">Careers</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/tenders.php">Tenders</a>                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Legal.php" class="nav-link">Legal</a>									</li>
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Licences</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Concurrences.php">Concurrences</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation GENCOs.php">GENCOs</a>  </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation K-Electric.php">K-Electric</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IPPs.php">IPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Netmetering.php">Net-Metering</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IGCs.php">IGCs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation SPPs.php">SPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation CPPs.php">CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NCPPs.php">N-CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NPPs.php">NPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation WAPDA Hydel.php">WAPDA Hydel</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Distributed Generation.php">Distributed Generation</a>                                                    </li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Transmission.php">Transmission</a>                                          </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Industrial Estates.php">Industrial Estates</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution CPPs.php">CPPs</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution SPPs.php">SPPs</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Independent System and Market Operator.php" class="nav-link">ISMO</a>   
								            </li>
											 
											 <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Electric Power Suppliers</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Suppliers of Last Resort.php">Suppliers of Last Resort</a>                                                    </li>
                                                    
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Special Purpose Agent.php">Special Purpose Agent</a>
								             </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/elicensing" class="nav-link">e-Licensing</a>   
								             </li>  
											  
											   
                                        </ul>
                                    </li> 
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Tariff</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation K-Electric.php">K-Electric</a></li>
                                                        <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation GENCOs.php">GENCOs</a></li>

                                                   <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation WAPDA Hydroelectric.php">WAPDA Hydroelectric</a></li>
												    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation IPPs.php">IPPs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Upfront.php">UP-front</a></li>
													
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Benchmark.php">Benchmark</a></li>
													
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation CPPs.php">CPPs</a></li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Transmission</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission NTDC.php">NTDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission HVDC.php">HVDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission STDCPL.php">ST&DCPL</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution WAPDA.php">WAPDA</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Market Operators.php" class="nav-link">Market Operators</a>                                          </li> 
											 <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Petitions.php" class="nav-link">Petitions</a>                                             </li>      
                                        </ul>
                                    </li>   
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Consumer Affairs</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" target="_blank" href="https://nepra.org.pk/consumer affairs/cad/NEPRA Asaan Approach1.jpg">NEPRA Asaan Approach</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/cregister.php">Register Complaint</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/tcomplaint.php">Track a Complaint</a>                                            </li>
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Authority Decisions.php">Authority Decisions</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Appellate Board.php">Appellate Board</a>                                            </li>
											
											
												<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Understand Your Electricity Bill.php">Understand Electricity Bill</a>                                            </li>
                                        </ul>
                                    </li>
                                   
                                    
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">M & E</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/M&E/Orders%20of%20the%20Authority.php">Orders of the Authority</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/dxp/">Data Exchange Portal</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Performance%20Reports.php">Performance Evaluation Reports</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Inquiry%20Reports.php">Inquiry Reports</a> </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Publications</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Annual Reports.php">Annual Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/State of Industry Reports.php">State of Industry Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/News Letters.php">News Letters</a></li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Performance Reports.php">Performance Reports</a></li>
                                        </ul>
                                    </li>
									
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/news.php" class="nav-link">News</a>                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Suggestions</a>
                                        <ul class="dropdown-menu">
                                           
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Suggestion Box.php">NEPRA Employees Only</a></li>
                                        </ul>
                                    </li>
									
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Contact.php" class="nav-link">contact</a>                                    </li>
                                     
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div><!-- End Navbar Area -->
        </header> 
		<!-- End Header Section -->

        <!-- Start Sidebar Modal -->
		<div class="sidebar-modal">  
            <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="flaticon-close-cross"></i></span></button>

                            <h2 class="modal-title" id="myModalLabel2"><a href="index.php"><img src="https://nepra.org.pk/assets/img/logo.png" alt="logo"></a></h2>
                        </div>

                        <div class="modal-body">
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Additional Links</h3>

                                <ul>
                                    <li><a href="https://nepra.org.pk/energyweek.php">NEPRA Energy Week</a></li>
									<li><a href="https://nepra.org.pk/Media%20Gallery.php">Media Gallery</a></li>
									<li><a href="https://nepra.org.pk/Power Policies.php">Power Policies</a></li>
                                    
                                    <li><a href="https://nepra.org.pk/consumer affairs/Electricity Bill.php">Applicable Tariff</a></li>
                                    <li><a href="https://webmail.nepra.org.pk:2096/">E-mail (NEPRA Officials Only)</a></li>
                                </ul>
                            </div>
                            
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Contact Info</h3>

                                <ul class="contact-info">
                                    <li>
                                        <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
                                        Address
                                        <span>NEPRA Tower G-5/1, Islamabad, Pakistan</span>
                                    </li>
                                    <li>
                                        <i class="flaticon-close-envelope"></i>
                                        Email
                                        <span><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="cca5a2aaa38ca2a9bcbeade2a3beabe2bca7">[email&#160;protected]</a></span>
                                    </li>
                                    <li>
                                        <i class="flaticon-telephone-handle-silhouette"></i>
                                        Phone
                                        <span>+92 51 2013200</span>
                                    </li>
									<li>
                                        <i class="flaticon-call"></i>
                                        Fax
                                        <span>+92 51 9210215</span>
                                    </li>
                                </ul>
                            </div>

                            <div class="sidebar-modal-widget">
                                <h3 class="title">Connect With Us</h3>

                                <ul class="social-list">
                                    <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://webmail.nepra.org.pk/"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
        </div>
        <div align="justify">
          <!-- End Sidebar Modal -->        <!-- End Header Section -->

        <!-- Start Page Banner Section -->
        <section class="banner-section nepra-tariff-xwdiscos-gepco">
            <div class="d-table">
                <div class="d-tablecell">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title page-title-one">
                                    <h2><span>Gujranwala Electric Power Company Limited</span> - GEPCO</h2>
                                    <ul>
                                        <li><a href="../index.php">home <i class="flaticon-right"></i></a><a href="Distribution XWDISCOs.php">XWDISCOs <i class="flaticon-right"></i> </a></li><li>GEPCO</li>
                                    </ul>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </section>
        <!-- End Page Banner Section -->

        <!-- Start Blogs Section -->
         <section class="team-man-section team-man-section-two ptb-100">
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-9 col-md-6 col-sm-6">
                     <!-- Accordions -->
						<ul class="accordions toggles">
							
							<!-- Accordion -->
							<li class="accordion">
									<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6> 2026 </h6>
									</div>
								
								<div class="accordion-content">
								<table border="1" width="100%">
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-09-2026</div> </td>
                  <td width="1084" style="text-align: justify" >
									DECISION OF THE AUTHORITY IN THE MATTER OF
									<b>FEDERAL GOVERNMENT MOTION</b> AND POLICY 
									GUIDELINES FOR UNIFORM APPLICATION OF <b>USE 
									OF SYSTEM CHARGES</b></td>
                  <td width="98" align="center" ><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20Decision%20i.r.o.%20Use%20of%20System%20Charges%2007-09-2026%2018389-18406.pdf">view</a></div></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									04-09-2026</div>  </td>
                  <td width="1084" style="text-align: justify" >
									Decision of the Authority in the matter of 
									Fuel Charges Adjustment for the month of 
									July 2026 for <b>EX-WAPDA DISCOs </b></td>
                  <td width="98" align="center" ><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20FOR%20THE%20MONTH%20OF%20JULY%202026%20EX-WAPDA%20DISCOS%2004-09-2026%2018342-60.PDF">view</a></div></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									04-09-2026</div>  </td>
                  <td width="1084" style="text-align: justify" >
									Decision of the Authority in the matter of 
									requests filed by <b>XWDISCOs</b> for 
									Periodic Adjustment in tariff for the 2nd 
									Quarter of CY 2026 </td>
                  <td width="98" align="center" ><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20DISCOS%20REQUEST%20BY%20XWDISCOS%20FOR%20ADJ%202ND%20QUARTER%20OF%20CY%202026%2004-09-2026%2018362-78.PDF">view</a></div></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-08-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of <b>Fuel Charges Adjustment</b> 
			for the month of June 2026 for <b>EX-WAPDA DISCOs </b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20XWDISCOS%20FCA%20JUN%202026%2007-08-2026%2017536-54.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									08-07-2026</div> <div align="center"></div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of May 2026 for <b>EX-WAPDA DISCOs </b></td>
                  <td width="98" align="center" ><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20FCA%20FOR%20MONTH%20OF%20MAY%202026%20FOR%20EX-WDISCOS%20MAY%202026%2008-07-2026%2011323-41.PDF">view</a></div></td>
                					</tr>
									<tr>
                  <td width="152" style="text-align: center">
					08-06-2026</td>
                  <td width="1108" style="text-align: justify">
							<b>Notification S.R.O 953(I)/2026 - </b> NEPRA hereby notifies complete Decision of the Authority in the matter of Requests filed
							by XWDISCOs for Periodic Adjustment in Tariff for the 1st Quarter of CY 2026 already intimated
							to the Ministry of Energy (Power Division) on June 04, 2026</td>
                  <td style="text-align: center">
									<a target="_blank" class="default-btn" href="Tariff/Notifications/2026/06%20June/SRO%20953(I)2026%20-%20Notification%20regarding%201st%20Quarter%20CY%202026%20XW-DISCOs%2008.06.2026.PDF">view</a></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									04-06-2026</div> <div align="center"></div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of requests filed by XWDISCOs for Periodic
									Adjustment in tariff for the 1st Quarter of CY 2026</td>
                  <td width="98" align="center" ><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20XWDISCOS%20PERIODIC%20ADJUSTMENT%201st%20QUARTER%2004-06-2026%209812-29.pdf">view</a></div></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									04-06-2026</div> <div align="center"></div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of Fuel Charges Adjustment for the month of
									April 2026 for EX-WAPDA DISCOs</td>
                  <td width="98" align="center" ><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20FCA%20APR-2026%2004-06-2026%209831-49.pdf">view</a></div></td>
                					</tr>
									
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									05-05-2026</div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of March 2026 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20FCA%20MAR-2026%2005-05-2026%208301-18.pdf">view</a></div></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									15-04-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           
									DECISION OF THE AUTHORITY IN THE MATTER OF 
									DISTRIBUTION INVESTMENT PLAN AND LOSSES 
									ASSESSMENT OF GUJRANWALA ELECTRIC POWER 
									COMPANY LIMITED (GEPCO) FOR CONTROL PERIOD 
									FROM FY 2025-26 TO 2029-30</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2026/LAD-03%20GEPCO%20DISTRIBUTION%20INVESTMENT%20PLAN%20FY%202025-26%20TO%202029-30%2015-04-2026%207588-95.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									08-04-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of February 2026 for <b>XWDISCOs</b> along 
									with Notification Thereof </td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20FCA%20FEB-2026%2008-04-2026%206904-21.pdf">View 
					</a></td>
        								</tr>
									<tr>
                  <td width="152" style="text-align: center">
					06-03-2026</td>
                  <td width="1108" style="text-align: justify">
							<b>Notification S.R.O 459(I)/2026 - </b>NEPRA hereby 
							notifies complete Decision of the Authority in the 
							matter of Requests filed by <b>XWDISCOs</b> for 
							Periodic Adjustment in Tariff for the 2nd Quarter of 
							FY 2025-26 already intimated to the Ministry of 
							Energy (Power Division) on March 03, 2026</td>
                  <td style="text-align: center">
									<a target="_blank" class="default-btn" href="Tariff/Notifications/2026/03%20Mar/SRO%20459%20XWDISCOs%202nd%20QTR%20FY%202025-26%2006-03-2026.PDF">view</a></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									04-03-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of January 2026 for <b>EX-WAPDA DISCOs</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20XWDISCOS%20FCA%20JAN-2026%2004-03-2026%204592-4609.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									03-03-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           
									Decision of the Authority in the matter of 
									requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in tariff for the 
									2nd Quarter of FY 2025-26 </td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20XWDISCOs%2003-02-2026%204582-85.PDF">View 
					</a></td>
        								</tr>
									<tr>
                  <td width="152" style="text-align: center">
					12-02-2026</td>
                  <td width="1108" style="text-align: justify">
							<b>Notification S.R.O 279(I)/2026 - </b>Federal 
							Government is pleased to notify immediately the 
							National Electric Power Regulatory Authority's 
							decision dated 11th day of February, 2026 which is 
							hereby read in modification of the earlier issued 
							applicable notifications vide S.R.O No's: 41(I)/2026 
							to 52(I)/2026 of dated the 13th January, 2026 in 
							respect of <b>XWDISCO's and K-Electric </b></td>
                  <td style="text-align: center">
									<a target="_blank" class="default-btn" href="Tariff/Notifications/2026/02%20Feb/S.R.O.%20279(1)2026%20dated%2012-02-2026.pdf">view</a></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									11-02-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           
			DECISION OF THE AUTHORITY IN THE MATTER OF FEDERAL GOVERNMENT MOTION 
			&amp; POLICY GUIDELINES FOR RATIONALIZATION OF TARIFF OF <b>XWDISCOS AND 
			K-ELECTRIC</b> UNDER SECTION 7 AND 31 OF NEPRA ACT READ WITH RULE 17 
			OF THE NEPRA TARIFF (STANDARDS AND PROCEDURES) RULES. 1998</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20XWDISCOS%20AND%20KE%20RATIONALIZATION%20OF%20TARIFF%2011-02-2026%202935-57.pdf">View 
					</a></td>
        								</tr>
									<tr>
										
									  <td width="12%" style="text-align: center">
										06-02-2026</td>
										<td width="80%">Decision of the 
										Authority in the matter of <b>Fuel 
										Charges Adjustment</b> for the month of 
										December 2025 for <b>EX-WAPDA DISCOs</b> </td>
										<td width="8%" style="text-align: center">
                  
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20XWDISCOS%20FCA%20DEC-2025%2006-02-2026%202698-15.pdf">View</a></td>
									</tr>
									<tr>
                  <td width="152" style="text-align: center">
					15-01-2026</td>
                  <td width="1108" style="text-align: justify">
							<b>Notification S.R.O 80(I)/2026 - </b>NEPRA hereby 
							notifies the&nbsp; Decision of the Authority dated 
							December 31, 2015 pursuant to Judgements of the 
							Honorable Supreme Court of Pakistan, Islamabad High 
							Court and NEPRA. Appellate Tribunal in the matter of 
							petitions filed by various parties regarding, 
							monthly fuel charges adjustments and quarterly 
							tariff adjustments of <b>XWDISCOs</b></td>
                  <td style="text-align: center">
									<a target="_blank" class="default-btn" href="Tariff/Notifications/2026/01%20Jan/SRO%2080(I)-2026%20Dated%2015-01-2026.pdf">view</a></td>
                					</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									13-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           <b>Notification S.R.O No. 42(I)/2026 GEPCO</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Notifications/2026/01%20Jan/S.R.O.%2042(1)2026%20dated%2013.01.2026.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									12-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           DECISION OF THE AUTHORITY IN THE MATTER OF MOTION FILED BY THE <b>
			FEDERAL GOVERNMENT</b> UNDER SECTION 7 AND 31(7) OF THE NEPRA ACT 
			1997 (THE ACT) READ WITH THE RULE 17 OF NEPRA (TARIFF STANDARDS AND 
			PROCEDURE) RULES, 1998 (THE RULES) WITH RESPECT TO RECOMMENDATION OF
			<b>CONSUMER END TARIFF</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/Decision%20of%20the%20Authority%20Motion%20of%20Federal%20Govt.%201004-23%20dated%2012.01.2026.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of request filed by <b>
			Central Power Purchasing Agency (Guarantee) Limited (CPPA-G)</b> for 
			Approval of <b>Power Purchase Price Forecast</b> for the CY 2026 
			i.e. January 2026 to December 2026 </td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/Rebasing%20Decisions/TRF-100%20CPPAG%20FOR%20APPROVAL%20OF%20POWER%20PURCHASE%20PRICE%20FORECAST%2007-01-2026%20437-76.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of Fuel Charges Adjustment for the month of
			<b>November 2025</b> for <b>EX-WAPDA DISCOs</b> along with Notification Thereof</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF-100%20MFPA%20CHARGES%20ADJ%20FOR%20MONTH%20OF%20NOV%202025%20FOR%20EX-WAPDA%20DISCOs%2007-01-2026%20400-17.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           DETERMINATION OF THE AUTHORITY IN THE MATTER OF PETITION FILED BY <b>
			GUJRANWALA ELECTRIC POWER COMPANY LIMITED (GEPCO)</b> FOR 
			DETERMINATION OF DISTRIBUTION TARIFF UNDER MYT REGIME FOR THE FY 
			2025-26 TO FY 2029-30 </td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/Rebasing%20Decisions/TRF-619%20GEPCO%20FOR%20DETERMINATION%20OF%20DISTRIBUTION%20TARIFF%2007-01-2026%20282-89.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of Motion for Leave for 
			Review filed by <b>Gujranwala Electric Power Company (GEPCO)</b> 
			against decision of the Authority dated 14.06.2025 in the matter of 
			Annual Adjustment/Indexation of tariff for FY 2024-25 </td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/Rebasing%20Decisions/TRF-619%20AND%20620%20REVIEW%20BY%20GEPCO%20MATTER%20OF%20ANNUAL%20ADJ%2007-01-2026%20464-71.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-01-2026</div></td>
          <td  width="80%" style="text-align: justify"> 
           DETERMINATION OF THE AUTHORITY IN THE MATTER OF PETITION
			FILED BY GUJRANWALA ELECTRIC POWER COMPANY LIMITED
			(GEPCO) FOR DETERMINATION OF SUPPLY TARIFF UNDER MYT
			REGIME FOR THE FY 2025-26 TO FY 2029-30</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2026/TRF%20620%20GEPCO%20FOR%20DETERMINATION%20OF%20SUPPLY%20TARIFF%2007-01-2026%20273-80.PDF">View 
					</a></td>
        								</tr>
									

								</table>	
							
							
								</div>
								
							</li>
							<!-- /Accordion -->


							<!-- Accordion -->
							<li class="accordion">
									<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6> 2025 </h6>
									</div>
								
								<div class="accordion-content">
								<table border="1" width="100%">
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									31-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority pursuant to Judgments 
			of the Honorable Supreme Court of Pakistan, Islamabad High Court and 
			NEPRA Appellate Tribunal (NAT) in the matter of petitions filed by 
			various parties regarding monthly <b>Fuel Charges Adjustments (FCAs)
			</b>and<b> Quarterly Tariff Adjustments (QTAs)</b> of <b>XWDISCOS</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20ISLAMABAD%20HIGH%20COURT%20AND%20OHTERS%20REGARDING%20FCA%20AND%20QTA%2031-12-2025%2021310-32.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									18-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority regarding petitions filed by <b>XWDISCOS</b> for determination 
		   of use of <b>System Charges to the extent of Grid Charges</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20Decision%20Use%20of%20System%20Charges%2018-12-2025%2021171-87.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									10-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           <b>Notification S.R.O No. 2409(I)/2025 </b>-<b> </b>NEPRA hereby 
			notifies the Decision of the Authority dated December 09, 2025 in 
			the Matter of Motion filed by Federal Government with respect to 
			Incremental Consumption Package for Industrial and Agriculture 
			Electricity Consumers of XWDISCOs &amp; K-Electric</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Notifications/2025/12%20Dec/SRO%202409(I)-2025%20Dated%2010-12-2025.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									10-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           <b>Notification S.R.O No. 2408(I)/2025</b> - NEPRA hereby notifies 
			complete Decision of the Authority in the matter of Requests filed 
			by XWDISCOs for Periodic Adjustment in Tariff for the 1st Quarter of 
			FY 2025-26 already intimated to the Ministry of Energy (Power 
			Division) on December 09, 2025</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Notifications/2025/12%20Dec/SRO%202408(I)-2025%20Dated%2010-12-2025.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									09-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of <b>Fuel Charges Adjustment</b> 
			for the month of October 2025 for <b>EX-WAPDA DISCOs</b> along with 
			Notification Thereof</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20FCA%20FOR%20OCT-2025%2009-12-2025%2020862-79.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									09-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of requests filed by <b>
			XWDISCOs</b> for Periodic Adjustment in tariff for the <b>1st 
			Quarter</b> of FY 2025-26</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%201st%20QTR%202025-26%2009-12-2025%2020884-87.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									09-12-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
           Decision of the Authority in the matter of <b>Motion</b> filed by the
			<b>Federal Government</b> with respect to <b>Incremental Consumption 
			Package</b> for Industrial and Agriculture Electricity Consumers of
			<b>XWDISCOs &amp; K-Electric</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20&%20KE%20INCREMENTAL%20CONSUMPTION%20PACKAGE%20FOR%20INDUSTRIAL%20AND%20AGRICULTURE%20CONSUMERS%2009-12-2025%2020846-50.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									07-11-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
            Decision of the Authority in the matter of <b>Fuel Charges 
			Adjustment</b> for the month of September 2025 for <b>EX-WAPDA 
			DISCOs</b> along with Notification Thereof</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20MFPA%20Sepetember-2025%2007-11-2025%2019301-18.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									14-10-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
            Decision of the Authority in the matter of Fuel Charges Adjustment for the month of
			<b>August 2025</b> for <b>EX-WAPDA DISCOs</b> along with Notification Thereof</td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20FCA%20MONTH%20OF%20AUGUST%202025%20EX-WAPDA%20DISCOS%2014-10-2025%2016389-16406.PDF">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									16-09-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
            Decision in the Matter of Motions for Leave for Review filed under 
			Regulation 3(2) of the NEPRA (Review Procedure) Regulations, 2009 
			against the Decision of NEPRA dated December 23, 2024 regarding 
			Application of Tariff Category for <b>Cold Storages</b></td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TCD-10%20DECISION%20OF%20THE%20AUTHORITY%20FOR%20COLD%20STORAGE%2016-09-2025%2014867-83.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width="12%" style="text-align: center"> <div align="center">
									09-09-2025</div></td>
          <td  width="80%" style="text-align: justify"> 
            Decision of the Authority in the matter of <b>Fuel Charges 
			Adjustment</b> for the month of July 2025 for <b>EX-WAPDA DISCOs</b> 
			along with Notification Thereof </td>
          <td width="8%" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDSICSOs%20FCA%20July-2025%2009-09-2025%2014230-47.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width=100 style="text-align: center"> <div align="center">
									07-08-2025</div></td>
          <td  width="671" style="text-align: justify"> 
            <b>Notification S.R.O No. 1468(I)/2025</b> NEPRA hereby notifies 
			complete Decision of the Authority along-with attached Annexure-A in 
			the matter of Requests filed by <b>XWDISCOs</b> for <b>Periodic 
			Adjustment</b> in Tariff for the 4th Quarter of FY 2024-25 </td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/SRO%201468%20XWDISCOs%204th%20QTR%20FY%202024-25%20Dated%2007-08-2025.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width=100 style="text-align: center"> <div align="center">
									07-08-2025</div></td>
          <td  width="671" style="text-align: justify"> 
            Decision of the Authority in the matter of requests filed by <b>
			XWDISCOs</b> for <b>Periodic Adjustment</b> in tariff for the 4th 
			Quarter of FY 2024-25 </td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20PERIODIC%20ADJUSTMENT%20FY%202024-25%2007-08-2025%2012380-83.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width=100 style="text-align: center"><div align="center"> 
									07-08-2025</div></td>
          <td  width="671" style="text-align: justify"> 
            Decision of the Authority in the matter of <b>Fuel Charges 
			Adjustment</b> for the month of June 2025 for <b>EX-WAPDA DISCOs</b> 
			along with Notification Thereof</td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20FCA%20JUN%202025%2007-08-2025%2012350-66.pdf">View 
					</a></td>
        								</tr>
									<tr>
          <td width=100 style="text-align: center"> 
									09-07-2025</td>
          <td  width="671" style="text-align: justify"> 
            Decision of the Authority in the matter of <b>Fuel Charges 
			Adjustment</b> for the month of May 2025 for <b>EX-WAPDA DISCOs</b> 
			along with Notification Thereof</td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20FCA%20MONTH%20OF%20MAY%202025%20FOR%20EX-WAPDA%20DISCOs%2009-07-2025%2010512-27.PDF">View 
					</a></td>
        								</tr>
									<tr>
									<td width="12%"><div align="center">
										01-07-2025</div></td>
                  					<td width="80%"><b>Notification S.R.O No. 
									1160 (I)/2025</b> - Federal Government is 
									pleased to direct that the following further 
									amendments shall be made in its notification 
									No. S.R.O. 379(I)/2018 dated the 22nd day of 
									March, 2018 as amended from time to time,</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Notifications/2025/07%20Jul/SRO%201160%2001-07-2025%20GEPCO.pdf">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">01-07-2025</div></td>
                  					 <td  width="80%"> Decision of the Authority 
										in the matter of Motion filed by the 
										<b>Federal Government</b> under Section 7 and 
										31(7) of the NEPRA Act 1997 read with 
										Rule 17 of NEPRA (Tariff Standards and 
										Procedure) Rules, 1998 with respect to 
										Recommendation of <b>Consumer-end-Tariff</b>. </td>
                  			 <td  width="8%"><div align="center"> 
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MOTION%20BY%20FG%20UNDER%20SECTION%207%20AND%2031(7)%20OF%20NEPRA%2001-07-2025%209641-61.PDF">View</a> </div>
					</td>
                						</tr>
									<tr>
          <td width="12%"> <div align="center">
									23-06-2025</td>
          <td  width="71%" style="text-align: justify"> 
            Decision of the Authority in the matter of request filed by <b>
			Gujranwala Electric Power Company (GEPCO)</b> for Determination of 
			Interim tariff for the FY 2025-26 for its Distribution and Supply of 
			Power functions</td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/23-06-2025/TRF-619%20&%20TRF-620%20GEPCO%20DETERMINATION%20IN%20TARIFF%2023-06-2025%209281-87.pdf">View 
					</a></td>
        							</tr>
									<tr>
          <td width="12%"> <div align="center">
									23-06-2025</td>
          <td  width="71%" style="text-align: justify"> 
            Decision of the Authority in the matter of request filed by <b>CPPA-G</b> 
			for <b>Power Purchase Price</b> Forecast for the FY 2025-26</td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/23-06-2025/TRF-100%20CPPA%20G%20FOR%20POWER%20PURCHASE%20PRICE%20FORECAST%20FOR%20THE%20FY%202025-26%209267-71.pdf">View 
					</a></td>
        							</tr>
									<tr>
									<td width="12%"><div align="center">
										05-06-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of <b>Fuel Charges Adjustment</b> 
									for the month of April 2025 for <b>XWDlSCOs</b> 
									along with Notification Thereof</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20FCA%20APR-2025%2005-06-2025%207873-88.pdf">View</a> </div>
					</td>
                					</tr>
									<tr>
          <td width="12%"> <div align="center">
									22-05-2025</td>
          <td  width="671" style="text-align: justify"> 
            Decision of the Authority under NEPRA (Review Procedure Regulations) 
			regarding Motion and Policy Guidelines filed by the <b>Federal 
			Government</b> for rationalization of tariff for <b>Electric Vehicle 
			Charging Stations (EVCS) </b></td>
          <td width="70" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20EV%20REVIEW%20PROCEDURE%20REGULATION%20RATIONALIZATION%20OF%20TARIFF%20FOR%20EV%20%2022-05-2025%20%206886-90.PDF">View 
					</a></td>
        							</tr>
									<tr>
									<td width="12%"><div align="center">
										09-05-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of <b>Fuel Charges Adjustment</b> 
									for the month of March 2025 for <b>XWDlSCOs</b> 
									along with Notification Thereof</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20FCA%20MARCH%202025%20FOR%20XWDISCOS%2009-05-2025%205845-60.PDF">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">
										10-04-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of Motion filed by the <b>Federal 
									Government</b> with respect to 
									recommendation of Consumer end Tariff for <b>
									XWDISCOs</b> and <b>K-Electric</b></td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20&%20KE%20CONSUMER%20END%20TARIFF%2010-04-2025%205329-32.pdf">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">
										03-04-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of <b>Fuel Charges Adjustment</b> 
									for the month of <b>February 2025</b> for <b>
									XWDISCOs</b> along with Notification Thereof </td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20XWDISCOS%20FCA%20FEB%202025%2003-04-2025%204895-4910.PDF">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">
										03-04-2025</div></td>
                  					<td width="80%"><b>Notification S.R.O No. 
									488 (I)/2025</b> - NEPRA hereby notifies 
									complete Decision of the Authority 
									along-with attached Annexure-A in the matter 
									of Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the <b>
									2nd Quarter</b> of FY 2024-25</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/S.R.O%20488%20(1)2025%2003-04-2025.PDF">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">
										27-03-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of requests filed by <b>XWDISCOs</b> 
									for <b>Periodic Adjustment</b> in tariff for 
									the <b>2nd Quarter</b> of FY 2024-25 </td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%202ND%20QUARTERLY%20ADJUSTMENT%20FY%202024-25%2027-03-2025%204587-90.pdf">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">
										06-03-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of <b>Fuel Charges Adjustment </b>
									for the month of January 2025 for <b>
									XWDISCOs</b> along with Notification Thereof</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20XWDISCOS%20FCA%20JAN-2025%2006-03-2025%203386-01.pdf">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">12-02-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of Fuel Charges Adjustment for 
									the month of <b>December 2024</b> for <b>
									XWDISCOs</b> along with Notification Thereof</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20XWDISCOS%20FCA%20DEC-2024%2012-02-2025%202311-26.pdf">View</a> </div>
					</td>
                					</tr>
									<tr>
									<td width="12%"><div align="center">07-01-2025</div></td>
                  					<td width="80%">Decision of the Authority in 
									the matter of <b>Fuel Charges Adjustment</b> 
									for the month of November 2024 for <b>
									XWDISCOs</b> along with Notification Thereof</td>
                  				<td width="2%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2025/TRF-100%20MFPA%20FCA%20NOV-2024%2007-01-2025%20159-174.pdf">View</a> </div>
					</td>
                					</tr>
									
									
									</table>
									 
								</div>
								
							</li>
							<!-- /Accordion -->
								<!-- Accordion -->
							<li class="accordion">
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2024</h6>
									
								</div>
								
								<div class="accordion-content">
		<table width="100%" border="0" align="center" cellpadding="2" >
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									23-12-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision Of The Authority In The Matter Of Application of
									<b>Tariff Category For Cold Storages</b>
									</td>
                  <td width="8%"style="text-align: center" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/TCD-10%20CATEGORY%20FOR%20COLD%20STORAGES%2023-12-2024%2019837-76.PDF">View</a></div></td>
                						</tr>
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									13-12-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority under NEPRA (Review Procedure) Regulations. 2009 
									in the matter of <b>SUO MOTO</b> proceedings regarding transition from 
									London Interbank Offered Rate <b>(LIBOR)</b> to Secured Overnight Financing rate <b>(SOFR)</b>
									</td>
                  <td width="8%"style="text-align: center" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20LIBOR%20TO%20SOFR%20REVIEW%2013-12-2024%2019158-61.pdf">View</a></div></td>
                						</tr>
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									06-12-2024</td>
                  <td width="80%" style="text-align: justify" >Decision of the 
					Authority in the matter of <b>Fuel Charges Adjustment</b> 
					for the month of October 2024 for <b>XWDISCOs</b> along with 
					Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20MFPA%20FCA%20OCT-2024%2006-12-2024%2019024-39.pdf">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									06-12-2024</td>
                  <td width="80%" style="text-align: justify" >Decision of the 
					Authority in the matter of <b>Motion</b> filed by <b>Federal 
					Government </b>with respect to <b>Winter Demand Initiative</b> 
					FY 24-25 for Electricity Consumers on Incremental 
					Consumption of <b>XWDISCOs &amp; K-Electric</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20&%20KE%20IRO%20RESPECT%20TO%20WINTER%20DEMAND%20INITIATIVE%20FY%202024-25%2006-12-2024%2019019-22.pdf">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									05-12-2024</td>
                  <td width="80%" style="text-align: justify" >Decision of the 
					Authority in the matter of <b>Suo Moto Proceeding</b> 
					regarding Transition from London Interbank offered Rate (<b>LIBOR</b>) 
					to Secured Overnight Financing Rate (<b>SOFR</b>)</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20Decision%20-%20LIBOR%20to%20SOFR%2005-12-2024%2018983-86.pdf">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									05-12-2024</td>
                  <td width="80%" style="text-align: justify" >Decision of the 
					Authority in the matter of requests filed by <b>XWDISCOs</b> 
					for <b>Periodic Adjustment</b> in tariff for the <b>1st 
					Quarter</b> of FY 2024-25</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20PERIODIC%20ADJUSTMENT%201ST%20QUATER%20FY%202024-25%2005-12-2024%2018921-24.pdf">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									06-11-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>September 2024</b> for <b>XWDISCOs</b> 
									along with Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOs%20MFPA%20SEP-2024%2006-11-2024%2016704-19.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									24-10-2024</td>
                  <td width="80%" style="text-align: justify" >Decision of the 
					Authority in the matter of Fuel Charges Adjustment for the 
					month of August 2024 for <b>XWDISCOs</b> along with 
					Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20MFPA%20August-2024%2024-10-2024%2016163-78.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									11-09-2024</td>
                  <td width="80%" style="text-align: justify" >
									<b>Notification S.R.O No. 1432(I)/2024</b> - 
									NEPRA hereby notifies complete Decision of 
									the Authority in the matter of Requests 
									filed by <b>XWDISCOs</b> for <b>Periodic 
									Adjustment</b> in Tariff for the 4th Quarter 
									of FY 2023-24 already intimated to the 
									Ministry of Energy (Power Division) dated 
									September 06, 2024</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Notifications/2024/09%20Sep/SRO%201432(I)-2024%20DATED%2011-09-2024.pdf">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									06-09-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of July 2024 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOs%20FCA%20July-2024%2006-09-2024%2014012-27.PDF">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									06-09-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of 
									requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in tariff for the <b>
									4th Quarter</b> of FY 2023-24 </td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOs%20Qtr%20Mar-June%20FY%202023-24%2006-09-2024%2014007-10.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									08-08-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>June 2024</b> for <b>XWDISCOs</b> 
									along with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20MFPA%20FCA%20June%202024%20XWDISCOs%2008-08-2024%2012471-86.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									14-07-2024</td>
                  <td width="80%" style="text-align: justify" >
									<b>Notification (S.R.O. 1039(I)/2024 - 
									Federal Government</b> is pleased to <b>
									notify</b> as under the tariff determined by 
									the NEPRA Authority vide its decision dated 
									the 13th day of July, 2024, which is hereby 
									read in conformity with earlier issued 
									applicable notification vide S.R.O No. 
									1025(I)/2024, 1026(I)/2024, 1027(I)/2024, 
									1028(I)/2024, 1029(I)/2024, 1030(I)/2024, 
									1031(I)/2024, 1032(I)/2024, 1033(I)/2024, 
									1034(I)/2024 and 1035(I)/2024 of dated the 
									12th July, 2024 in respect of <b>XWDISCOs 
									and K-Electric</b> namely:-</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Notifications/2024/07%20Jul/SRO%201039%2014-07-2024.pdf">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									13-07-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in <b>Review</b> 
									of the Decision dated July 11, 2024 in the 
									matter of <b>Motion</b> filed by the <b>
									Federal Government</b> under Section 7 and 
									31(7) of the NEPRA Act 1997 read with Rule 
									17 of NEPRA (Tariff Standards and Procedure) 
									Rules, 1998 with respect to Recommendation 
									of Consumer-end-Tariff of <b>XWDISCOs and 
									K-Electric</b> </td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20Review%20Decision%20of%20the%20Decision%20dated%2011-07-2024.PDF">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									12-07-2024</td>
                  <td width="80%" style="text-align: justify" >
									Federal Government<b> Notification (S.R.O. 
									1029(I)/2024 - </b>GEPCO</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Notifications/2024/07%20Jul/SRO%201029%2012-07-2024.pdf">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									11-07-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Motion</b> filed by the <b>Federal 
									Government </b>under Section 7 and 31(7) of 
									the NEPRA Act 1997 read with Rule 17 of 
									NEPRA (Tariff Standards and Procedure) 
									Rules, 1998 with respect to Recommendation 
									of <b>Consumer-end-Tariff</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20and%20KE%20REVIEW%20MOTION%20CONSUMER%20END%20TARIFF%2011-07-2024%2010607-26.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									05-07-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of May 2024 for <b>XWDISCOs</b> along with 
									Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/DECISION%20OF%20THE%20AUTHORITY%20-%20FCA%20MAY%202024%20XW-DISCOs.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									14-06-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of The Authority regarding Request 
									filed by <b>Gujranwala Electric Power 
									Company (GEPCO)</b> For 
									Adjustment/lndexation of Tariff for the FY 
									2024-25 under the MYT</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/DISCOs/GEPCO/2024/TRF-562%20&%20563%20GEPCO%20Indexation%20FY%202024-25%2014-06-2024%209231-37.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									03-06-2024</td>
                  <td width="80%" style="text-align: justify" >
									<b>Notification (S.R.O. 804(I)/2024 - </b>
									NEPRA hereby notifies complete Decision of 
									the Authority in the matter of Requests 
									filed by <b>XWDISCOs</b> for Periodic 
									Adjustment in Tariff for the 3rd Quarter of 
									FY 2023-24</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/SRO%20804(I)-2024%20DATED%2003-06-2024.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%">
  			
  			<div align="center">31-05-2024</div>
  			</td>
                  <td width="80%">Decision of the Authority in the matter of 
									requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in tariff for the <b>
									3rd Quarter</b> of FY 2023-24 </td>
                  <td width="8%"><div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/3rd%20Quarter%202023-24%20Periodic%20Adjustment%20XW-DISCOS.PDF">View</a> </div>
					</td>
                						</tr>
                                     <tr>
										<td width="11%" style="text-align: center">
										08-05-2024</td>
										<td width="80%">Decision of the 
										Authority in the matter of <b>Fuel 
										Charges Adjustment</b> for the month of
										<b>March 2024</b> for <b>XWDISCOs</b> 
										along with Notification Thereof</td>
										<td width="8%" style="text-align: center">
                  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOs%20FPA%20Mar-2024%2008-05-2024%206732-47.PDF">View</a></td>
										</tr>
                                     <tr><td width="11%" style="text-align: center">
										08-04-2024</td>
										<td width="80%">Decision of the Authority in the matter of <b>Fuel Charges Adjustment</b> for the month of
										<b>February 2024</b> for <b>XWDISCOs</b> along with Notification Thereof</td>
										<td width="8%" style="text-align: center">
                  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20MFPA%20XWDISCOs%20FPA%20FEB-2024%2008-04-2024%205011-26.PDF">View</a></td>
										</tr>
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									01-04-2024</td>
                  <td width="80%" style="text-align: justify" >
									<b>Notification (S.R.O. 446(I)/2024 dated 
									1st April, 2024)</b> regarding Notification 
									regarding
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the <b>
									2nd Quarter</b> of FY 2023-24</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20NOTIFICATION%20DECISION%2001-04-2024%204697-4707.PDF">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									28-03-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the <b>
									2nd Quarter</b> of FY 2023-24</td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20PERIODIC%20ADJUSTMENT%202023-24%2028-03-2024%204663-66.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									26-02-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of January 2024 for <b>XWDISCOs</b> along 
									with Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2024/TFF-100%20FCA%20JAN-2024%2026-02-2024%202891-96.PDF">View 
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									02-02-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of 
									<b>Fuel Charges Adjustment</b> for the month of
									<b>December 2023</b> for <b>XWDISCOs</b> along 
									with Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20MFPA%20DEC-2023%2002-02-2024%201695-1710.PDF">View 
											</a></td>
                						</tr>
                                     <tr>
                  <td width="12%" style="text-align: center" >
                  
									04-01-2024</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of 
									Fuel Charges Adjustment for the month of <b>
									November 2023</b> for <b>XWDISCOs</b> along 
									with Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2024/TRF-100%20XWDISCOS%20FPA%20Nov-2023%2004-01-2024%20191-207.pdf">View 
											</a></td>
                						</tr>
                                                                        										
								</table>
								</div>

							</li>

							<!-- /Accordion -->


								<!-- Accordion -->
							<li class="accordion">
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2023</h6>
									
								</div>
								
								<div class="accordion-content">
		<table width="100%" border="0" align="center" cellpadding="2" >
<tr>
                  <td width="12%" rowspan="1">
                  <div align="center">

                                  29-12-2023</td>
                  <td width="80%" style="text-align: justify">
                  					<b>Notification S.R.O. 1873(I)/2023</b> 
									, NEPRA hereby notifies complete Decision of the Authority along with Addendum to the
									said Decision in the matter of Requests filed by <b>XWDISCOs</b> for Periodic Adjustment in Tariff for
									the 1st Quarter of FY 2023-24.</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/SRO%201873%20XWDISCOs%2029-12-2023.PDF">view</a></div></td>
                					</tr>
<tr>
                  <td width="12%" rowspan="1">
                  <div align="center">

                                  21-12-2023</td>
                  <td width="80%" style="text-align: justify">Addendum to the <b>Decision of the Authority</b> 
                  in the matter of requests filed by <b>XWDISCOS</b> for periodic adjustment in tariff for the <b>1st Quarter of FY 2023-24</b></td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20ADDENDUM%20DECISION%2021-12-2023%2038681-83.PDF">view</a></div></td>
                					</tr>
<tr>
                  <td width="12%" rowspan="1">
                  <div align="center">

                                  20-12-2023</td>
                  <td width="80%" style="text-align: justify">DECISION OF THE AUTHORITY IN THE MATTER OF REQUESTS
															FILED BY XWDISCOS FOR PERIODIC ADJUSTMENT IN TARIFF
															FOR THE 1ST QUARTER OF FY 2023-24</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20QTR%20JULSEP%202023%2020-12-2023%2038584%2086.PDF">view</a></div></td>
             				</tr>
                                                                       <tr>
                  <td width="12%">
                  <div align="center">

                                  05-12-2023</td>
                  <td width="80%" style="text-align: justify">Decision of the 
					Authority in the matter of <b>Fuel Charges Adjustment</b> 
					for the month of <b>October</b> 2023 for <b>XWDISCOs</b> along with 
					Notification Thereof</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWAPDA%20FCA%20OCT-23%2005-12-2023%2037883-98.PDF">view</a></div></td>
                													</tr>
<tr>
                  <td width="13%">
                  <div align="center">

                                  08-11-2023</td>
                  <td width="78%" style="text-align: justify" >
                                  Decision of the Authority in the matter of <b>
									Fuel Charges Adjustment</b> for the month of 
									<b>September</b> 2023 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWAPDA%20FCA%20SEP-2023%2008-11-2023%2036277-92.PDF">
						view</a></div></td>
                													</tr>
                                                                       <tr>
                  <td width="12%">
                  <div align="center">

                                  05-10-2023</td>
                  <td width="80%" style="text-align: justify" >
                                  	Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>August 2023</b> for <b>XWDISCOs</b> 
									along with Notification Thereof </td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20FCA%20AUG-2023%2005-10-2023%2033676-92.PDF">view</a></div></td>
                														</tr>
																		<tr>
                  <td width="12%">
                  <div align="center">

                                  02-10-2023</td>
                  <td width="80%" style="text-align: justify" >
                                  	<b>Notification (S.R.O. 1365(I)/2023</b> 
									dated 2nd October 2023) regarding 
									Notification in respect of Decision of the 
									Authority in the matter of requests filed by
									<b>XWDISCOs</b> for Periodic Adjustment in 
									Tariff for the 4th Quarter of FY 2022-23</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/SRO%201365(I)-2023%20dated%2002-09-2023.PDF">view</a></div></td>
                														</tr>
                                                                       <tr>
                  <td width="12%">
                  <div align="center">

                                  22-09-2023</td>
                  <td width="80%" style="text-align: justify" >
                                  Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the 
									Quarter of FY 2022-23</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20PERIODIC%20ADJUSTMENT%20FY%202022-23%2022-09-2023%2033892-94.PDF">view</a></div></td>
                														</tr>
																		<tr>
                  <td width="12%">
                  <div align="center">

                                  08-09-2023</td>
                  <td width="80%" style="text-align: justify" >
                                  Decision of the Authority in the matter of <b>
									Fuel Charges Adjustment</b> for the month of 
									July 2023 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20MFPA%20FCA%20%20XWDISCOS%20JULY%202023%2008-09-2023%2032753-68.PDF">view</a></div></td>
                														</tr>
																		<tr>
                  <td width="12%">
                  <div align="center">

                                  08-08-2023</td>
                  <td width="80%" style="text-align: justify" >
                                  Decision of the Authority in the matter of <b>
									Fuel Charges Adjustment</b> for the month of 
									June 2023 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20FCA%20JUN-2023%2008-08-2023%2020843-58.PDF">view</a></div></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									25-07-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Motion</b> filed by the <b>Federal 
									Government</b> under Section 7 and 31(7) of 
									the NEPRA Act 1997 read with Rule 17 of 
									NEPRA (Tariff Standards and Procedure) 
									Rules, 1998 with respect to Recommendation 
									of <b>Consumer-end-Tariff</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20Review%20filed%20by%20Federal%20Govt%2025-07-2023%2019271-90.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									19-07-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of May 2023 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20MFPA%20XWDISCOS%20FCA%20MAY-2023%2019-07-2023%2018428-43.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									14-07-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									DECISION OF THE AUTHORITY IN THE MATTER OF 
									SETTING UP OF <b>POWER PURCHASE PRICE (PPP)</b> 
									REFERENCES FOR THE FY 2023-24</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20PPP%20REFERENCE%20%20FY%202023%2024%2014-07-2023%2018249-53.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									14-07-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									DECISION OF THE AUTHORITY REGARDING REQUEST 
									FILED BY <b>GUJRANWALA ELECTRIC POWER 
									COMPANY LTD. (GEPCO)</b> FOR <b>
									ADJUSTMENT/INDEXATION</b> OF TARIFF FOR THE 
									FY 2023-24 UNDER THE MYT</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2023/TRF-563%20GEPCO%20FY%202023%2024%2014-07-2023%2018233-39.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									07-07-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification (S.R.O 885(I)2023 dated 7th 
									July, 2023)</b> regarding Notification in 
									respect of Decision of the Authority in the 
									Matter of requests filed by <b>XWDISCOs</b> 
									for <b>Periodic Adjustment</b> in Tariff for 
									the 3rd Quarter of July 2022-23</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/D-17005%20-21%2007-07-2023%20PCPP.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									04-07-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tarff for the 3rd 
									Quarter of FY 2022-23</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOSc%203RD%20OCT%202022-23%2004-07-2023%2016148-50.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									12-06-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of April 2023 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20MFPA%20FCA%20APR%202023%20XWDISCOs%2012-06-2023%2014731-46.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									25-05-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Fuel Charges Adjustment for the month of <b>
									March 2023</b> for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20MFPA%20MAR-2023%20XWDISCOS%20FCA%2025-05-2023%2013105-20.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									18-04-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of February 2023 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOs%20FPA%20February%202023%2018-04-2023%209040-55.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									13-04-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>S.R.O. 488 (I)/2023</b> - NEPRA hereby 
									notifies decision alongwith Category-wise 
									rates of quarterly adjustments for the 2 
									Quarter of FY 2022-23 of XWDISCOs. </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/S.R.O%20488(I)-2023%20dated%2013-04-202.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									12-04-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for 
									Periodic Adjustment in Tariff for the 2nd 
									Quarter of FY 2022-23</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="tariff/Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20PERIODIC%20ADJUSTMENT%20FY%202022-23%2012-04-2023%208795-97.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									30-03-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Motion of the Federal Government</b> 
									under Section 31 of the NEPRA Act 1997 read 
									with Rule 17 of NEPRA (Tariff Standards and 
									Procedure) Rules, 1998 with respect to 
									Recommendation of <b>Consumer-end Tariff</b> 
									for <b>XWDISCOs and K-Electric</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20&%20K-ELECTRIC%20RECOMENDATION%20OF%20CONSUMER-END-TARIFF%2030-03-2023%207542-61.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									10-03-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>January 2023</b> for <b>XWDISCOs</b> 
									along vitli Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20MFPA%20FCA%20XWDISCOS%20Jan-2023%2010-03-2023%204991-5006.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									10-03-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority regarding <b>
									Endorsement of Federal Government Decisions</b> 
									taken for Discontinuation of Regionally 
									Competitive Energy Rates (Rs.19.99/kWh) for
									<b>Export Oriented Sectors and Kissan 
									Package</b> (Relief of Rs.3.60/kWh) from 1st 
									March 2023</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20FG%20Kissan%20Package%2001%20March%202023%2010-03-2023%204970-89.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									09-03-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority regarding Ministry 
									of Energy, Power Division's Policy 
									Guidelines under Section 31 of NEPRA Act 
									1997, for Recovery of Staggered <b>Fuel 
									Charges Adjustment</b> applicable for the 
									months of <b>August and September 2022</b> 
									for <b>Ex-WAPDA Distribution Companies &amp; 
									K-Electric Ltd.</b> alone with Notification 
									Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20MFPA%20FCA%20EX-WAPDA%20&%20KE%20AUG%20&%20SEP%202022%2009-03-2023%204933-43.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									06-03-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Motion of the Federal Government</b> 
									under Section 31 of the NEPRA Act 1997 read 
									with Rule 17 of NEPRA (Tariff Standards and 
									Procedure) Rules, 1998 with respect to 
									Recommendation of Consumer-end Tariff for <b>
									XWDISCOs</b> and <b>K-Electric</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20&%20KE%20REVIEW%20FILED%20BY%20FEDERAL%20GOVT.%2006-03-2023%204258-76.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									16-02-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of December 2022 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20FPA%20DEC-2022%2016-02-2023%202795-10.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									24-02-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>NOTIFICATION S.R.O 235(I)/2023-</b>NEPRA 
									hereby notifies the Decision of the 
									Authority in the matter of Motion for Leave 
									for Review filed by <b>Gujranwala</b> <b>
									Electric Power Company Ltd. (GEPCO)</b> 
									against Decision of the Authority for its 
									Supply of Power Tariff under MYT Regime for 
									the FY 2020-21 to FY 2024-25</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Notifications/2023/Feb-2023/SRO%20235%20(I)-2023%20Dated%2024-02-23.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									08-02-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>S.R.O. 139 (I)/2023</b>.- In pursuance of 
									Sub-Section 7 of Section 31 of the 
									Regulation of Generation, Transmission and 
									Distribution of Electric Power Act, 1997 (XL 
									of 1997), NEPRA hereby notifies the <b>
									Decision of the Authority</b> in the matter 
									of <b>Kissan Package 2022</b> regarding 
									reduction in Price of Electricity and 
									corrigendum of the said decision issued on
									<b>24.01.2023</b>.</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/S.R.O%20139(I)-2023%20dated%2008-02-2023.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									07-02-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification S.R.O NO. 136 (I)/2023</b> - 
									NEPRA hereby notifies decision alongwith 
									Category-wise rates of <b>quarterly 
									adjustments for the 1St Quarter of FY 
									2022-23</b> of <b>XWDISCOs</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/S.R.O%20136(I)-2023%20dated%2007-02-2023.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									24-01-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Corrigendum</b> - Decision of the 
									Authority in the matter of <b>Kissan Package 
									2022</b> regarding reduction in Price of 
									Electricity</td>
                  <td width="8%" style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="tariff/Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20CORRIGENDUM%20Kissan%20Package%202022%2024-01-2023%201111-1113.PDF">View											</a></td>
								  										</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									17-01-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the <b>
									1st Quarter</b> of FY 2022-23</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20Periodic%20Adjustment%2017-01-2023%20758-760.PDF">View 
											</a></td>
                														</tr>
																		<tr>
                  <td width="12%" style="text-align: center" >
                  
									12-01-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Motion for Leave for Review</b> filed by
									<b>Gujranwala Electric Power Company Ltd. (GEPCO)</b> 
									against Determination of the Authority for 
									its <b>Supply</b> of Power Tariff under MYT 
									Regime for the FY 2020-2 1 TO FY 2024-25</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2023/TRF-563%20GEPCO%20Leave%20Review%2012-01-2023%20442-44.PDF">View 
											</a></td>
                														</tr>
                                                                       <tr>
                  <td width="12%" style="text-align: center" >
                  
									11-01-2023</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>November 2022</b> for <b>XWDISCOs</b> 
									along with Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2023/TRF-100%20XWDISCOS%20Nov%202022%2011-01-2023%20D-361-76.PDF">View 
											</a></td>
                														</tr>
										
								</table>
								</div>

							</li>

								
								<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6> 2022 </h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									
									 <tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">26-12-2022</div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Kissan Package 2022 regarding reduction in 
									Price of Electricity</td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20XWDISCOs%20Kissan%20Package%2026-12-2022%2023962-64.PDF">view</a></div></td>
                						</tr>
									
									 <tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">16-12-2022</div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of October 2022 for <b>XWDISCOs </b>along 
									with Notification Thereof</td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20XWDISCOS%20FPA%20Oct-2022%2016-12-2022%2023621-36.PDF">view</a></div></td>
                						</tr>
									
									 <tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">25-10-2022</div></td>
                  <td width="1084" style="text-align: justify" >
									
									<b>NOTIFICATION - S.R.O.1959 (I)/2022 </b>
									NEPRA hereby notifies the Decision of the 
									Authority in the matter of Discontinuation 
									of <b>Incentive Package</b> announced by the 
									Prime Minister regarding <b>reduction</b> in 
									price of Electricity</td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Notifications/2022/10%20Oct/25%20Oct/S.R.O%201959%20(I)-2022%20dated%2025-10-2022.PDF">view</a></div></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									20-10-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification - S.R.O. No. 1932(I)/2022</b> 
									- NEPRA hereby notifies decision alongwith 
									Category-wise uniform quarterly adjustments 
									for the 4th Quarter of FY 2021-22 of 
									XWDISCOs. The category wise component of the 
									allowed quarterly adjustment of each XWDISCO 
									alongwith the uniform rate is attached as 
									Annex-A</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/S.R.O%201932%20(I)-2022%20dated%2020-10-2022.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">14-10-2022</div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for 
									Periodic Adjustment in Tariff for the <b>4th 
									Quarter of FY 2021-22 </b></td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20XWDISCOs%20QTR%2014-10-2022%209818-20.PDF">view</a></div></td>
                						</tr>
										<tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">14-10-2022</div></td>
                  <td width="1084" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>August 2022</b> for <b>XWDISCOs</b> 
									along with Notification Thereof </td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20XWDISCOs%20Aug%202022%2014-10-2022%2019795-04.pdf">view</a></div></td>
                						</tr>
										<tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">12-09-2022</div></td>
                  <td width="1084" style="text-align: justify" >
	Decision of the Authority in the matter of <b>Fuel Charges Adjustment</b> 
	for the month of July 2022 for <b>XWDISCOs</b> along with Notification 
	Thereof</td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20FCA%20July%202022%2012-09-2022%2017117-32%20.PDF">view</a></div></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									23-08-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification - S.R.O. No. 1587(I)/2022</b> 
									- NEPRA hereby notifies decision alongwith. 
									Category-wise uniform quarterly adjustments 
									for the 3rd Quarter of FY 202 1-22 of <b>
									XWDISCOs</b>. The category wise component of 
									the allowed quarterly adjustment of each 
									XWDISCO alongwith the uniform rate is 
									attached as Annex-A.</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/S.R.O%201587%20(I)-2022%2023-08-2022%20XWDISCOs.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									12-08-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of June 2022 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20FCA%20Jun%202022%2012-08-2022%2015173-88.pdf">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									29-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the 
									3rd Quarter of FY 2021-22 </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20XWDISCOs%203rd%20QTR%2029-07-2022%2014562-64.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									25-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification - S.R.O. No. 1170(I)/2022</b> 
									- Tariff Rationalization for Power Sector </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Notifications/2022/July/S.R.O%201170%20(I)-2022%20dated%2025-07-2022.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									22-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Motion filed by the Federal Government</b> 
									under Section 7 and 31(7) of the NEPRA Act 
									1997 read with Rule 17 of the NEPRA (Tariff 
									Standards and Procedure) Rules, 1998 with 
									respect to Recommendation of the <b>
									Consumer-end Tariff</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20XWDISCOs%20Motion%20FG%2022-07-2022%2013540-42%20.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									07-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Fuel Charges Adjustment for the month of May 
									2022 for XWDISCOs alone with Notification 
									Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20XWDISCOS%20FPA%20MAY-2022%2007-07-2022%2012288-03%20(1).pdf">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									07-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification - S.R.O. No. 1587(I)/2022</b> 
									- NEPRA hereby notifies decision alongwith 
									Category-wise uniform quarterly adjustments 
									for the 2nd Quarter of FY 2021-22 of 
									XWDISCOs. </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/S.R.O%20(I)-2022%20993%20dated%2007-07-2022.pdf">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									07-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									NOTIFICATION REGARDING DECISION OF THE 
									AUTHORITY IN THE MATTER OF REQUESTS FILED BY 
									XWDISCOS FOR PERIODIC ADJUSTMENT IN TARIFF 
									FOR THE 2<font size="2">nd</font> QUARTER OF 
									FY 2021-22</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/D-11917%2007-07-2022%20PCPP%20SRO%20993.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									05-07-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority regarding 
									Discontinuation of Incentive Package 
									announced by the Prime Minister regarding 
									reduction in price of Electricity </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20Incetive%20Package%20%2005-07-2022%2011649-51.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									13-06-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of April 2022 for <b>XWD1SCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20XWDISCOs%20FCA%20Apr%202022%2010067-83.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									02-06-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									DETERMINATION OF THE AUTHORITY IN THE MATTER 
									OF PETITION FILED BY GUJRANWALA ELECTRIC 
									POWER COMPANY LTD. (GEPCO) FOR DETERMINATION 
									OF ITS <b>SUPPLY</b> OF POWER TARIFF UNDER 
									MYT REGIME FOR THE FY 2020-21 TO FY 2024-25 </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2022/TRF-563%20GEPCO%20Determination%2002-06-2022%208641-43.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									02-06-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									DETERMINATION OF THE AUTHORITY IN THE MATER 
									OF PETITION FILED BY GUJRANWALA ELECTRIC 
									POWER COMPANY LTD. (GEPCO) FOR DETERMINATION 
									OF <b>DISTRIBUTION TARIFF</b> UNDER MYT 
									REGIME FOR THE FY 2020-21 TO FY 2024-25</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2022/TRF-562%20GEPCO%20Determination%2002-06-2022%208641-43.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									31-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>S.R.O 728(I)/2022</b> Decision of the 
									Authority in the matter of requests filed by
									<b>XWDISCOs</b> for <b>Periodic Adjustments</b> 
									in Tariff for the 1st Quarter of FY 2021-22</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/S.R.O%20728%20(I)-2022%2031-05-2022.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									27-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification S.R.O. 752(I)/2022</b> - 
									NEPRA hereby notifies the Decision of the 
									Authority in the matter of Motion filed by 
									the Federal Government under Section 7 and 
									31 of the NEPRA Act 1997 read with Rule 17 
									of the NEPRA (Tariff Standards and 
									Procedure) Rules 1998 with respect to 
									Recommendation of the Consumer-end-Tariff 
									for XWDISCOs &amp; K-Electric.</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Notifications/2022/June/S.R.O%20752%20(I)2022%20dated%2027-05-2022.PDF">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									27-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification S.R.O. 725(I)/2022</b> - 
									NEPRA hereby notifies the Determination of 
									the Authority in the matter of Policy 
									Guidelines forwarded by the Ministry of 
									Energy (MoE) under Section 31 of Regulation 
									of Generation, Transmission and Distribution 
									of Electric Power Act, 1997 for <b>Re-Targetting 
									Power Sector Subsidies - Phase-II</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Notifications/2022/S.R.O%20725%20(I)-2022%20dated%2027-05-2022.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									27-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification S.R.O. 666(I)/2022</b> - 
									NEPRA hereby notifies the Decision of the 
									Authority in the matter of Motion filed by 
									the Ministry of Energy (Power Division) and 
									request of K-Electric with respect to 
									Recommendation for Extension of 'Abolishment 
									of Time of Use Tariff Scheme' for Industrial 
									Consumers of <b>XWDISCOs and K-Electric.</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Notifications/2022/S.R.O%20666%20(I)-2022%20dated%2027-05-2022.pdf">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									27-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification S.R.O. 659(I)/2022</b> - 
									Decision of the Authority in the matter of 
									Motion filed by the Federal Government with 
									respect to Recommendation of Extension of 
									Incremental Consumption Package for <b>
									K-Electric</b> Industrial Consumers 
									including B1 Consumers of <b>XWDISCOs</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Notifications/2022/S.R.O%20659%20(I)-2022%20dated%2027-05-2022.pdf">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									11-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Review Motion filed by <b>K-Electric</b> 
									against Decision of the Authority regarding 
									Motion filed by Federal Government with 
									respet to Recommendation of Extension of 
									Incremental Consumption Package for 
									K-Electric Industrial Consumers including B1 
									Consumers of <b>XWDISCOs</b> </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20Review%20Motion%20K-E%20&%20XWDISCOs%2011-05-2022%207148-50.PDF">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									09-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the 
									1st Quarter of FY 2021-22 </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20XDISCOs%2009-05-2022%206913-15.PDF">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									06-05-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of <b>March 2022</b> for <b>XWDISCOs</b> 
									along with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20FCA%20XWDISCOs%20Mar-2022%2006-05-2022.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									15-04-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of February 2022 for <b>XWDISCOs</b> along 
									with Notification Thereof </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20Feb%202022%2015-04-2022%205236-52.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									18-03-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Incentive Package</b> announced by the <b>
									Prime Minister</b> regarding <b>reduction in 
									Price of Electricity </b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20PM%20Incentive%20Package%2018-03-2022%204216-18.PDF">View					
											</a></td>
                						</tr>
										<tr>
                  <td width="12%" style="text-align: center" >
                  
									18-03-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Policy Guidelines</b> forwarded by the <b>
									Ministry of Energy (MoE)</b> under Section 
									31 of Regulation of Generation, Transmission 
									and Distribution of Electric Power Act, 1997 
									for Re-Targetting Power Sector Subsidies - 
									Phase-Il </td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20Policy%20Guidelines%2018-03-2022%204194-96.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									10-03-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of January 2022 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20FCA%20Jan%202022%20XWDISCOs%2010-03-2022%203779-95.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									09-03-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Determination of the Authority in the matter 
									of Policy Guidelines forwarded by the <b>
									Ministry of Energy (MoE)</b> under Section 
									31 of Regulation of Generation, Transmission 
									and Distribution of Electric Power Act, 1997 
									for <b>Re-Targetting Power Sector Subsidies 
									- Phase-II</b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20Policy%20Guideline%20Determination%2009-03-2022%203749-51.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									11-02-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of December 2021 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20Decision%20FCA%20XWDISCOS%20December%202021.PDF">View					
											</a></td>
                						</tr>
									
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									20-01-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Notification</b> S.R.O No. 117 (I)/2022 - 
									Decision of the Authority in the matter of 
									Requests filed by <b>XWDISCOs</b> for <b>
									Periodic Adjustment</b> in Tariff for the <b>
									4th Quarter</b> of FY 2020-21</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/S.R.O%20117%20(I)-2022%20dated%2020-01-2022.pdf">View					
											</a></td>
                					</tr>

				
									 <tr>
                  <td width="12%" style="text-align: center" >
                  
									13-01-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of November 2021 for <b>XWD1SCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2022/TRF-100%20MFPA%20FCA%20Nov%202021%20XWDISCOs%2013-01-2000%20649-65.pdf">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									11-01-2022</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Motion filed by the Federal Government with 
									respect to Recommendation of Extension of 
									Incremental Consumption Package for 
									K-Electric Industrial Consumers including Bi 
									Consumers of <b>XWDISCOs </b> </td>
                  <td width="8%" style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/KESC/2022/TRF-100%20Motion%20FG%20KE%2011-01-2021%20498-500.PDF">View					
											</a></td>
                					</tr>

									</table>
									 
								</div>
								
							</li>
							<!-- /Accordion -->

								<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6> 2021 </h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									30-12-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Decision</b> of the Authority in the 
									matter of Requests filed by <b>XWDISCOs</b> 
									for Periodic Adjustment in Tariff for the <b>
									4th Quarter</b> of FY 2020-21</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCOS%20QTR%20Adj%20Sept-Dec%202021%2030-12-2021%2045785-87.pdf">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									09-12-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Fuel Charges Adjustment for the month of <b>
									October 2021</b> for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20FCA%20Oct%202021%2009-12-2021%2042576-92.PDF">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									08-11-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of September 2021 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOS%20FCA%20Sep%202021%2008-11-2021%2040166-82.PDF">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									08-11-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									<b>Tariff Notifications of XWDISCOs (Winter 
									Package)</b> S.R.O No. 1418 dated 05 
									November 2021</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/Tariff%20Notification%20XWDISCOs%20Winter%20Package.PDF">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									05-11-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Motion filed by the Federal Government under 
									Section 7 and 31 of the NEPRA Act 1997 read 
									with Rule 17 of the NEPRA (Tariff Standards 
									and Procedure) Rules 1998 with respect to 
									Recommendation of the Consumer-end-Tariff 
									for <b>XWDISCOs &amp; K-Electric </b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20Motion%20FG%2005-11-2021%2040679-81.PDF">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									03-11-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of 
									Motion filed by the Federal Government with 
									respect to Winter Incentive Package for 
									Electricity Consumers on Incremental 
									Consumption of <b>XWDISCOs</b> &amp; <b>
									K-Electric </b></td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCOs%2003-11-2021%2040478-80.pdf">View					
											</a></td>
                					</tr>
									<tr>
  <td width="12%" dir="ltr" style="text-align: center">08-10-2021</td>
  <td width="80%"dir="ltr"> 
            Decision of the Authority in the matter of <b>Fuel Charges 
			Adjustment </b>for the month of August 2021 for <b>XWDISCOs</b> 
			along with Notification Thereof</td>
  <td width="8%">
  
             
					<div align="center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20FCA%20Aug%202021%2008-10-2021%2038581-97.PDF">View</a></div> </td>
 									</tr>
									<tr>
  <td width="12%" dir="ltr" style="text-align: center">30-09-2021</td>
  <td width="80%"dir="ltr"> 
            <b>Notification S.R.O 1278(I)/2021</b>&nbsp; quarterly adjustments 
			of <b>XWDISCOs</b> for the 1st and 2nd Quarters of FY 2020-21</td>
  <td width="8%">
  
             
					<div align="center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/S.R.O%201778%20(I)2021%2030-09-2021.PDF">View</a></div> </td>
 									</tr>
									<tr>
  <td width="12%" dir="ltr" style="text-align: center">23-09-2021</td>
  <td width="80%"dir="ltr"> 
            <b>Determination</b> in the matter of Policy Guidelines forwarded by 
			the Ministry of Energy (MoE) under Section 31 of the Regulation of 
			Generation, Transmission and Distribution of Electric Power Act, 
			1997 for providing <b>basis for Re-Targeting Power Sector Subsidies</b> 
			in Future </td>
  <td width="8%">
  
             
					<div align="center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20Determination%20XWDISCOs%2023-09-2021%2037543-45.PDF">View</a></div> </td>
 									</tr>
									<tr>
  <td width="12%" dir="ltr" style="text-align: center">10-09-2021</td>
  <td width="80%"dir="ltr"> 
            Decision of the Authority in the matter of <b>Fuel Charges 
			Adjustment</b> for the month of July 2021 for <b>XWDISCOs</b> along 
			with Notification Thereof </td>
  <td width="8%">
  
             
					<div align="center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20Jul%2010-09-2021%2035981-97.pdf">View</a></div> </td>
 									</tr>
									<tr>
  <td >
	<div align="center">25-08-2021</div></td>
  <td align="justify">
	<b>Notification S.R.O No. 1067</b> - NEPRA hereby Notifies the Category-wise 
	uniform quarterly adjustments for the 3rd quarter of FY 2020-21 of XWDISCOs</td>
  <td style="text-align: center" >
  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/SRO%201067%20(I)%202021%2025-08-2021.pdf">View</a></td>
 									</tr>
									<tr>
  <td >
	<div align="center">06-08-2021</div></td>
  <td align="justify">
	<b>Notification S.R.O No. 1010</b> - NEPRA hereby Notifies the Category-wise 
	uniform Quarterly adjustments for the 4th quarter of FY 2019-20 and 1st and 
	2nd quarters of FY 2020-21 of XWDISCOs</td>
  <td style="text-align: center" >
  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/SRO%201010%20(I)%202021%2006-08-2021.pdf">View</a></td>
 									</tr>
									<tr>
  <td >
	<div align="center">06-08-2021</div></td>
  <td align="justify">
	Decision of the Authority in the matter of <b>Fuel Charges Adjustment</b> 
	for the month of June 2021 for <b>XWDISCOs</b> along with Notification 
	Thereof</td>
  <td style="text-align: center" >
  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20%20FCA%20Jun%2006-08-2021%20.PDF">View</a></td>
 									</tr>
									<tr>
  <td >
	<div align="center">30-07-2021</div></td>
  <td align="justify">
	Decision of the Authority in the matter of Requests filed by <b>XWDISCOs</b> 
	for <b>Periodic Adjustment</b> in Tariff for the 3td Quarter of FY 2020-21</h2>
										</td>
  <td style="text-align: center" >
  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCOs%20Periodic%20Adjustment%2030-07-2021%2032992-94.PDF">View</a></td>
 									</tr>
									<tr>
  <td >
	<div align="center">12-07-2021</div></td>
  <td align="justify">Decision of the Authority in the matter of <b>Fuel Charges 
	Adjustment</b> for the month of May 2021 for <b>XWDISCOs</b> along with 
	Notification Thereof </td>
  <td style="text-align: center" >
  
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20FCA%20MAY%202021%2012-07-2021%2031374-90.PDF">View</a></td>
 									</tr>
									<tr>
  <td >
	<div align="center">02-07-2021</div></td>
  <td >
    	Decision of the Authority in the matter of Reconsideration Request filed 
		by the Federal Government under Section 31(7) of the NEPRA Act 1997 read 
		with Rule 17 of the NEPRA (Tariff Standards and Procedure) Rules, 1998 
		with respect to <b>Quarterly Adjustments</b> of <b>XWDISCOs</b> for the 
		1st and 2nd Quarters of FY 2020-21</td>
  <td style="text-align: center" >
  
					<p style="text-align: center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20Reconsideration%20Request%2002-07-2021%2030956-58.PDF">View</a></td>
 									</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									07-06-2021</td>
                  <td width="80%" style="text-align: justify" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of April 2021 for <b>XWDISCOs</b> along with 
									Notification Thereof</td>
                  <td width="8%"style="text-align: center" >
                    						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20FCA%20Apr%202021%2007-06-2021%2028402-18.PDF">View					
											</a></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                  
									07-05-2021</td>
                  <td width="80%" style="text-align: justify" >
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of March 2021 for XWDISCOs along with 
									Notification Thereof</td>
                  <td width="8%" >
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20FCA%20Mar%202021%2007-05-2021%2024819-35.PDF">View					
						</a></div></td>
                					</tr>
									<tr>
                  <td width="146" style="text-align: center" >
                                  <div align="center">07-04-2021</div></td>
                  <td width="1084" style="text-align: justify" >
	Decision of the Authority in the matter of <b>Fuel Charges Adjustment</b> 
	for the month of February 2021 for <b>XWDISCOs</b> along with Notification 
	Thereof </td>
                  <td width="98" align="center" >

                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20Feb%202021%2007-04-2021%2018911-27.PDF">view</a></div></td>
                					</tr>
									<tr>
                  <td width="12%" style="text-align: center" >
                                  09-03-2021</td>
                  <td width="80%" >
									
									Decision of the Authority in the matter of
									<b>Fuel Charges Adjustment</b> for the month 
									of January 2021 for <b>XWDISCOs</b> along 
									with Notification Thereof</td>
                  <td width="8%" style="text-align: center" >
                  	<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20Jan%202021%2009-03-2021%2013188-04.PDF">view</a></div></td>
                					</tr>
									<tr>

										<td width="12%" style="text-align: center" dir="ltr"> 

										12-02-2021</td>

										<td width="80%" dir="ltr">
										
                                         

											Decision of the Authority in the 
											matter of Motion filed by the 
											Federal Government under Section 7, 
											31(4) and 31(7) of the NEPRA Act 
											1997 read with Rule 17 of the NEPRA 
											(Tariff Standards and Procedure) 
											Rules, 1998 with respect to 
											Recommendation of the Consumer-end 
											Tariff for <b>XWDISCOs </b></td>

										<td width="10%" dir="ltr" style="text-align: center">
										<p style="text-align: center">
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCOs%20Review%20by%20GoP%2012-02-2021%207695-97.pdf">View											

										  </a></td>

																		</tr>
									<tr>

										<td width="12%" style="text-align: center" dir="ltr"> 

										10-02-2021</td>

										<td width="80%" dir="ltr">
										
                                         

											Decision of the Authority in the 
											matter of Requests filed by <b>
											XWDISCOs</b> for Periodic Adjustment 
											in Tariff for the <b>4th Quarter</b> 
											of FY 2019-20</td>

										<td width="10%" dir="ltr" style="text-align: center">
										<p style="text-align: center">
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCO%20Periodic%20Adjustment%20Tariff%2010-02-2021%207097-99.PDF">View											

										  </a></td>

																		</tr>
									<tr>

										<td width="12%" style="text-align: center" dir="ltr"> 

										10-02-2021</td>

										<td width="80%" dir="ltr">
										
                                         

											Decision of the Authority in the 
											matter of <b>Fuel Charges Adjustment</b> 
											for the month of December 2020 for
											<b>XWDISCOs</b> along with 
											Notification Thereof </td>

										<td width="10%" dir="ltr" style="text-align: center">
										<p style="text-align: center">
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%2010-02-2021%207045-61.PDF">View											

										  </a></td>

																		</tr>
									<tr>
  <td width="10%">
  
	<div align="center">14-01-2021
	  </div></td>
  <td width="82%">
  
	<div align="justify">Decision of the Authority pursuant to the Judgment 
		dated 08.09.2020 of Honorable Peshawar High Court, Peshawar in Writ 
		Petitions No. 4932/20, 5210/20, 4200/20, 4543/20, 5255/20 and Judgment 
		Dated 29.09.2020 passed by Honorable Peshawar High Court, Mingora Bench 
		/ Dar ut Qaza Swat in WP No. 847-M/2020</div></td>
  <td width="8%" style="text-align: center">
  
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCOs%20Judgment%20PHC%2014-01-2021%202304-2306.PDF">View</a> 
					  </div></td>
 									</tr>
									<tr>

                  <td width="10%" style="text-align: center" >

					<div align="center">11-01-2021</div></td>

                  <td width="82%" style="text-align: justify" >

							

							<div align="justify">Decision of the Authority in 
								the matter of <b>Wheeling Costs</b> to be 
								included in the Tariff Determination of <b>
								DISCOs</b> under Annual &amp; Multi-Year Tariff 
								Regime (FY 2018-19 &amp; FY 2019-20)&nbsp; </div></td>

                  <td width="8%" style="text-align: center" >

					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20XWDISCOs%20Wheeling%20Cost%2011-01-2021%201080-82.PDF">view</a></div></td>

                									</tr>
									<tr>

                  <td width="10%" style="text-align: center" >

					<div align="center">11-01-2021</div></td>

                  <td width="82%" style="text-align: justify" >

							

							<div align="justify">Decision of the Authority in 
								the matter of <b>Fuel Charges Adjustment</b> for 
								the months of October 2020 &amp; November 2020 for
								<b>XWDISCOs</b> alone with Notification Thereof</div></td>

                  <td width="8%" style="text-align: center" >

					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2021/TRF-100%20MFPA%20XWDISCOs%20Oct%202020%2011-01-2021%201062-71.PDF">view</a></div></td>

                									</tr>
																		
								</table>
								
									 
								</div>
								
							</li>
							<!-- /Accordion -->
								<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6>2020</h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									<tr>
										<td width="12%" >
                    <div align="center">24-12-2020</div></td>
                                  						                                  <td width="90%">
                                    <div align="justify">
										Determination of the Authority in the 
										matter of Petition filed by Gujranwala 
										Electric Power Company Ltd. (GEPCO) for 
										Determination of its <b>Supply</b> of 
										Power Tariff for the FY <b>2019-20</b></div></td>
                  <td width="2%"> 
                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2020/TRF-527%20GEPCO%20Determination%2024-12-2020%2046508-10.PDF">View</a> </div></td>
                										</tr>
									<tr>
										<td width="12%" >
                    <div align="center">24-12-2020</div></td>
                                  						                                  <td width="90%">
                                    <div align="justify">
										Determination of the Authority in the 
										matter of Petition filed by Gujranwala 
										Electric Power Company Ltd. (GEPCO) for 
										Determination of its <b>Distribution</b> 
										Tariff for the FY <b>2019-20</b></div></td>
                  <td width="2%"> 
                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2020/TRF-526%20GEPCO%20Determination%2024-12-2020%2046498-500.PDF">View</a> </div></td>
                										</tr>
									<tr>
										<td width="12%" >
                    <div align="center">24-12-2020</div></td>
                                  						                                  <td width="90%">
                                    <div align="justify">
										Determination of the Authority in the 
										matter of Petition filed by Gujranwala 
										Electric Power Company Ltd. (GEPCO) for 
										Determination of its <b>Supply</b> of 
										Power Tariff for the FY <b>2018-19</b></div></td>
                  <td width="2%"> 
                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2020/TRF-525%20GEPCO%20Determination%2024-12-2020%2046503-05.PDF">View</a> </div></td>
                										</tr>
									<tr>
										<td width="12%" >
                    <div align="center">24-12-2020</div></td>
                                  						                                  <td width="90%">
                                    <div align="justify">
										Determination of the Authority in the 
										matter of Petition filed by Gujranwala 
										Electric Power Company Ltd. (GEPCO) for 
										Determination of its <b>Distribution</b> 
										Tariff for the FY <b>2018-19</b></div></td>
                  <td width="2%"> 
                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2020/TRF-524%20GEPCO%20Determination%2024-12-2020%2046493-95.PDF">View</a> </div></td>
                										</tr>
									<tr>
  <td dir="ltr" width="12%" style="text-align: center">
  			14-12-2020</td>

                  <td width="80%" style="text-align: justify">
					
										<b>Decision of the Authority</b> in the 
										matter of <b>Fuel Charges Adjustment for 
										the month of September 2020</b> for 
										XWDISCOs along with Notification Thereof</td>
												
                  <td width="8%" style="text-align: center" >

                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20MFPA%20XWDISCOs%20Sep%202020%2014-12-2020%2045551-68.PDF">view</a></td>

								  	</tr>
									<tr>  <td dir="ltr" width="22%" style="text-align: center">
  			01-12-2020</td>

                  <td width="74%" style="text-align: justify">
					
										Decision of the Authority in the matter 
										of Motion filed by the Ministry of 
										Energy (Power Division) with respect to 
										recommendations of <b>Support Package 
										for Additional Consumption and 
										Abolishment of Time of Use Tariff Scheme 
										for Industrial Consumers</b> <b>of 
										XWDISCOs</b></td>
												
                  <td width="10%" style="text-align: center" >

                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20DISCOs%20Review%20Motion%20of%20MoE%20Recommendation%20of%20Support%20Package%2001-12-2020%2043673-75.PDF">view</a></td>

                														</tr>
									<tr>
                                  <td width="12%" >
                    <div align="center">09-11-2020</div></td>
                                  <td width="80%">
                                  Decision of the Authority in the matter of <b>
									Fuel Charges Adjustment</b> for the Month of 
									August 2020 for <b>XWDISCOs</b> alone with 
									Notification Thereof</td>
                  <td width="8%" style="text-align: center"> 
                    
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20MFPA%20XDISCOs%20%20Aug%202020%2009-11-2020%204086-102.PDF">
					View</a></td>
								  	</tr>
									<tr>
                                  <td width="12%" >
                    <div align="center">29-10-2020</div></td>
                                  <td width="80%">
                                  Decision of the Authority pursuant to the 
									Judgment dated 03.09.2020 of <b>Honorable 
									Peshawar High Court in Writ Petition No. 
									5180-P/2019</b>: and other Petitions 
									regarding Decision of the Authority in the 
									matter of requests filed by <b>XWDISCOs</b> 
									for <b>Periodic Adjustment</b> in the Tariff </td>
                  <td > 
                    
					<div align="center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20XWDISCOs%20%20Periodic%20Adjustment%20Tariff%2029-10-2020%2038508-10.PDF">View</a></td>
                										</tr>
									<tr>                                  <td width="12%" >
                    <div align="center">08-10-2020</div></td>
                                  						                                  <td width="90%">
                                    <div align="justify">
										Decision of the Authority in the matter 
										of <b>Fuel Charges Adjustment</b> for 
										the Month of <b>July 2020</b> for <b>
										XWDISCOs</b> along with Notification 
										Thereof </div></td>
                  <td width="2%"> 
                    
					<div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20MFPA%20FCA%20Jul%202020%2008-10-2020%2034800-17.PDF">View</a> </div></td>
                										</tr>
									<tr>
                  <td width="10%" style="text-align: center" >

                                  	<div align="center">24-09-2020</div></td>

                  <td width="80%" style="text-align: justify">Decision of the 					Authority in the matter of Requests filed by XWDISCOs for 					Periodic Adjustment in Tariff for the 2nd and 3rd Quarters 					of FY 2019-20 </td>
												
                  <td width="10%" >

                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20XWDISCOs%2024-09-2020%2031509-511.PDF">view</a></div></td>

                														</tr>									<tr>
										<td width="144" style="text-align: center" dir="ltr"> 

										07-08-2020</td>

										<td width="80%" dir="ltr">
										Decision of the Authority in the matter 
										of <b>Fuel Charges Adjustment</b> for 
										the Months of November 2019 to June 2020 
										for <b>XWDISCOs</b> along with 
										Notification Thereof</td>

										<td width="10%" dir="ltr" style="text-align: center">
										<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2020/TRF-100%20MFPA%20FCA%20XWDISCOs%2007-08-2020%2020257-74%20.PDF">View										  </a></td>

																		</tr>
									<tr>
	<td width="14%" style="text-align: center">01-01-2020</td>
										<td width="78%">
                                          <p style="text-align: justify">
											Decision of the Authority in the 
											matter of Fuel Charges Adjustment</b> 
											for the Month of October 2019 for 
											XWDISCOs</b> along with Notification 
					Thereof</td>
										<td width="8%">
                                          <p style="text-align: center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20XDISCOs%20Oct%202019%2001-01-2020%2036-45.PDF">View</a></td>
								  	</tr>
									
								</table>
																	 
								</div>
								
							</li>
							<!-- /Accordion -->

							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6> 2019 </h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									<tr>
	<td width="178"  style="text-align: center"><div align="center">26-11-2019</div></td>
										<td width="1008">
                                          <div align="justify">Decision of the 
											Authority in the matter of Requests 
											filed by XWDISCOs</b> regarding
											Periodic Adjustment</b> in Tariff 
									  for 1st Quarter of FY 2019-20</div></td>
										<td width="142" style="text-align: center"><div align="center">
											<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20XWDISCOs%2026-11-2019%2025610-12.PDF">
									  View</a></div></td>
									</tr>
									<tr>
	<td  style="text-align: center"><div align="center">21-11-2019</div></td>
										<td width="1008">
                                          <div align="justify">Decision of the 
											Authority in the matter of Fuel 
											Charges Adjustment</b> for the Month 
											of September 2019 for XWDISCOs</b> 
									  along with Notification Thereof</div></td>
										<td width="142" style="text-align: center"><div align="center">
									  <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20XWDISCOs%20FCA%20Sep%202019%2024875-92.PDF">View</a></div></td>
									</tr>
									<tr>

  <td  dir="ltr" style="text-align: center">

  			<div align="center">23-10-2019</div></td>

  <td width="1008">

										Decision of the Authority in the matter 
										of Fuel Charges Adjustment</b> for the Month
										of August 2019</b> for XWDISCOs</b> along with 
										Notification Thereof</td>

  <td width="142" style="text-align: center" >

  

                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20MFPA%20XWDISCOs%20Aug%202019%2023-10-2019%2020964-81.PDF">View</a></td>
								  	</tr>
									<tr>
  <td  style="text-align: center" dir="ltr">
  			<div align="center">09-10-2019</div></td>
  <td >
										<font size="3">Decision of the 
										Authority in the matter of Fuel Charges 
										Adjustment</b> for the Months
										of June &amp; July 2019 for XWDISCOs</b> along 
										with Notification Thereof</font></td>
  <td width="142" style="text-align: center" >
  
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20XWDISCOs%20MFPA%20Jun-Jul%202019%2009-10-2019.PDF">View</a></td>
								  </tr>
									<tr>
  <td dir="ltr" >
  			<p align="center" style="text-align: center">27-09-2019</td>
  <td >
							Interim Decision of the Authority in the matter of 
							Request filed by
							Ministry of Energy regarding Annual Adjustment / 
							Indexation of
							Distribution Margin of XWDISCOs</td>
  <td width="142" style="text-align: center" >
  
                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20XWDISCOs%2027-09-2019%2017883-85.PDF">View</a></td>
 									</tr>
									<tr>
  <td dir="ltr" >
  			<p align="center" style="text-align: center">27-09-2019</td>
  <td >
							Decision of the Authority in the matter of Requests 
							filed by XWDISCOs
							regarding Periodic Adjustments in Tariff for 3rd & 
							4th Quarters of
							FY 2018-2019</td>
  <td width="142" style="text-align: center" >
  
                    <a target="_blank" class="default-btn" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20XWDISCOs%2027-09-2019%2017864-66.PDF">View</a></td>
 									</tr>
									<tr>
                                  <td  style="text-align: center" ><div align="center">09-07-2019</div></td>
                                  <td width="1008">
                                    <div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of May 2019 for 
							XWDISCOs along with Notification Thereof</div></td>
                  <td width="142" style="text-align: center"> 
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%2009-07-2019%2011565-82.PDF" class="default-btn">View</a> </div></td>
                </tr>
                <tr>
                                  <td style="text-align: center">
                  <div align="center">14-06-2019</div></td>
                                  <td style="text-align: justify">
                                    <div align="justify">Decision of the 
							Authority in the matter of Requests filed by 
							XWDISCOs regarding Periodic Adjustment in 
							Tariff for 1st and 2nd Quarters of FY 2017-18</div></td>
                  <td style="text-align: center"> 
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20XWDISCOs%2010252-64%2014-06-2019.PDF" class="default-btn">View</a> </div></td>
                </tr>
				<tr>
            
                                  <td style="text-align: center" > 
				  <div align="center">03-06-2019</div></td>
                                  <td style="text-align: justify">
	                                <div align="justify">Decision of the Authority in the matter of 
	                                  Fuel Charges Adjustment for the Month of April 2019 for XWDISCOs 
                    along with Notification Thereof</div></td>
                  <td style="text-align: center"> 
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20FCA%20XWDISCOs%20APRIL%202018%209867-84%2003-06-2019.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
                                  <td style="text-align: center" >
                  <div align="center">30-04-2019</div></td>
                                  <td style="text-align: justify">
                                    <div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of March 2019 
							for XWDISCOs along with Notification Thereof</div></td>
                  <td width="142" style="text-align: center"> 
                  <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20XWDISCOs%2030-04-2019%207550-67.PDF" class="default-btn">View</a> </div></td>
                </tr>
                <tr>
                                  <td style="text-align: center" >
                  <div align="center">09-04-2019</div></td>
                                  <td style="text-align: justify">
                                    <div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of February 2019 
							for XWDISCOs along with Notification Thereof</div></td>
                  <td width="142" style="text-align: center"> 
                  <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20XWDISCOs%20Feb%202019%2009-04-2019%205863-80.PDF" class="default-btn">View					</a></div></td>
                </tr>
                <tr>
                                  <td style="text-align: center"  >
                  <div align="center">27-02-2019</div></td>
                                  <td style="text-align: justify">
                                    <div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of January 2019 for 
							XWDISCOs along with Notification Thereof</div></td>
                  <td width="142" style="text-align: center"> 
                  <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20FCA%20Jan%202019%20XWDISCOs%2027-02-2019%203382-99.PDF" class="default-btn">View					</a></div></td>
                </tr>
                <tr>
            
                                  <td style="text-align: center" > 
				  <div align="center">04-02-2019</div></td>
                                  <td  style="text-align: justify">
                                    <div align="justify">Decision of the Authority in the matter of 
                                      Fuel Charges Adjustment for the Month of December 2018 for XWDISCOs 
                    along with Notification Thereof</div></td>
                  <td style="text-align: center"> 
									
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20Dec%202018%20%20XWDISCOs%2004-02-2019%202153-70.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
				  <div align="center">02-01-2019</div></td>
          <td  style="text-align: justify"> 
                            <div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of November 2018 for 
							XWDISCOs along with Notification Thereof</div></td>
          <td width="142" style="text-align: center" > 

					
				  <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2019/TRF-100%20MFPA%20Nov%202018%20XWDICOs%2002-01-2019%2034-51.PDF" class="default-btn">View</a> </div></td>
        		</tr>
									
								</table>
								
									 
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6> 2018 </h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									<tr>
            
  <td width="178" dir="ltr" style="text-align: center" >
  			 
            						<div align="center">19-12-2018	                                </div>
  <td width="1035"   style="text-align: justify">
							
							<div align="justify">Decision of the Authority in the matter of Motion 
							filed by the Federal Government under Section 7, 
							31(4) and 31(7) of NEPRA Act, 1997 read with Rule 17 
							of the NEPRA (Tariff Standards and Procedure) Rules, 
							1998 with respect to Recommendation of the 
							Consumer-end Tariff </div></td>
                  <td style="text-align: center"> 

					
					<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20XWDISCOs%2019-12-2018%2019495-97.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
  <td dir="ltr" style="text-align: center" >
  			<div align="center">22-11-2018</div></td>
  <td dir="ltr" style="text-align: justify">
							<div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of October 2018 for 
							XWDISCOs along with Notification Thereof</div></td>
  <td style="text-align: center">
  
					
					<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20XWDISCOs%20FCA%20Oct%202018%2022-11-2018.PDF" class="default-btn">View</a> </div></td>
 				</tr>
                <tr>
  <td dir="ltr" style="text-align: center" >
  
    <div align="center">31-10-2018</div></td>
  <td dir="ltr" style="text-align: justify">
    <div align="justify">Decision of the Authority in the 
      matter of Fuel Charges Adjustment for the Month of September 2018 for 
      XWDISCOs along with Notification Thereof</div></td>
  <td style="text-align: center">
  
					
					<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20Sep%202018%2031-10-2018%2016678-95.PDF" class="default-btn">View</a> </div></td>
 				</tr>
                <tr>
  <td dir="ltr" style="text-align: center">
    <div align="center">03-10-2018</div></td>
  <td dir="ltr" style="text-align: justify">
    <div align="justify">Decision of the Authority in the 
      matter of Fuel Charges Adjustment for the Month of August 2018 for 
      XWDISCOs along with Notification Thereof</div></td>
  <td style="text-align: center">
  
					<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20XWDISCOs%20MFPA%20Aug%202018%2003-10-2018%2015341-50.PDF" class="default-btn">View</a> </div></td>
 					</tr>
                <tr>
                  <td style="text-align: center" >
                                  <div align="center">10-09-2018</div></td>
                  <td style="text-align: justify">
                                  <div align="justify">Decision of the Authority in the matter of 
									Request filed by Gujranwala Electric Power 
									Company Ltd. (GEPCO) regarding 
									Periodic Adjustment in Tariff</div></td>
                  <td width="115" style="text-align: center">
  
					
				  <div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2018/TRF-439%20GEPCO%20Perodic%20Adjustment%2010-09-2018%2014422-24.PDF" class="default-btn">View</a> </div></td>
                	</tr>
                <tr>
										<td width="14%"><div align="center">03-09-2018
                                      </div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of July 2018 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
					                      <div align="center">
					                          
					                          <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MEPA%20July%202018%20XWDISCOs%2003.09.2018%2013778-95.PDF" class="default-btn">
											
					                          View</a></div></td>
									</tr>

                <tr>
										<td width="14%"><div align="center">27-07-2018
                                      </div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of June 2018 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
  
										  <div align="center">
									                            
									                            <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20June%202018%2027-07-2018%2012204-12221.PDF" class="default-btn">
											
									                            View</a></div></td>
									</tr>
									<tr>
										<td width="14%"><div align="center">20-07-2018
                                      </div></td>
										<td width="79%" style="text-align: justify"><div align="justify">
											Determination of the Authority in 
											the matter of Petition filed by 
											Gujranwala Electric Power Company 
											Ltd. (GEPC0) for the Determination 
											of its Consumer end Tariff for the 
											FY 2016-2017 and FY 2017-18</div></td>
										<td style="text-align: center">
  
										  <div align="center">
									                            
									                            <a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2018/TRF-439%20GEPCO%20Determination%2020-07-2018%2011877-79.PDF">View</a></div></td>
									</tr>
									<tr>
										<td width="14%"><div align="center">03-07-2018
                                      </div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of May 2018 for XWDISCOs along with Notification Thereof </div></td>
										<td style="text-align: center">
  
					
					                      <div align="center">
				                                                
				                                                <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%2003-07-2018%2010038-55.PDF" class="default-btn">
											
				                                                View</a></div></td>
									</tr>
									<tr>
									  <td width="14%"><div align="center">01-06-2018</div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of April 2018 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
  
             
					                      <div align="center">
											
			                                                                                                <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20XWDISCOs%2001-06-2018%208485-8502.PDF" class="default-btn"> 
				                                                                      
			                                                                                                View</a>
										  </div></td>
									</tr>
									<tr>
									  <td width="14%"><div align="center">27-04-2018</div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of March 2018 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
                  	                      <div align="center">
											
                  	                                                  
                                          <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20XWDISCOS%20FPA%20Mar-2018%2027-04-2018%206997-7014.PDF" class="default-btn">
											View</span></a>
											</font>
										  </div></td>
									</tr>
									<tr>
									  <td width="14%"><div align="center">30-03-2018</div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of February 2018 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
                  	                      <div align="center">
											
											<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20XWDISCOS%20FCA%20FEB%202018%2030-03-2018.PDF">
											View</span></a>
											</font>
										  </div></td>
									</tr>
									<tr>
									  <td width="14%"><div align="center">01-03-2018</div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of January 2018 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
                                          <div align="center">
											
                                                                                          
                                                                                          <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20FCA%20Jan%2018%2001-03-2018%203271-88.PDF" class="default-btn">
											View</span></a>
                                        </font></font></div></td>
									</tr>
									<tr>
										<td width="14%"><div align="center">31-01-2018
                                      </div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of December 2017 for XWDISCOs along with Notification Thereof </div></td>
										<td style="text-align: center">
                  	                      <div align="center">
											
											<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20XWDISCOs%20Dec%202017%2031-01-2018.PDF">
                                                            View</span></a>
											</font>
										  </div></td>
									</tr>
									<tr>
										<td width="14%"><div align="center">02-01-2018
                                      </div></td>
										<td width="79%" style="text-align: justify"><div align="justify">Decision of the Authority in the matter of Fuel Charges Adjustment for the Month of November 2017 for XWDISCOs along with Notification Thereof</div></td>
										<td style="text-align: center">
  
                                          <div align="center">
											
											<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2018/TRF-100%20MFPA%20XWDISCOs%20%20173-90%2002-01-2018.PDF"> 
                                                                
                                                            View</a>
										  </div></td>
									</tr>
								</table>
								
									 
								</div>
								
							</li>
							<!-- /Accordion -->
							
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2017</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" ><tr>
  <td dir="ltr" style="text-align: center">
            						
									<div align="center">30-11-2017</div></td>
  <td dir="ltr" style="text-align: justify">
							<div align="justify">Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of October 2017 for
							XWDISCOs along with Notification Thereof					</div></td>
  <td width="73" >
  
                    
  
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20MFPA%20XWDISCOs%20OCT-2017%2030-11-2017%2019570-88.PDF" class="default-btn">View</a> </div></td>
 					</tr>
				<tr>
  <td dir="ltr" style="text-align: center">
  			<div align="center">27-10-2017</div></td>
  <td dir="ltr" style="text-align: justify">
            <div align="justify">Decision of the 
              Authority in the matter of Fuel Charges Adjustment for the 
              Month of September 2017 for XWDISCOs along with Notification 
              Thereof </div></td>
  <td >
  
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20FCA%20XWDISCOs%20SEP-2017%2027-10-2017%2017902-19.PDF" class="default-btn">View</a> </div></td>
 					</tr>
				<tr>
  <td dir="ltr" rowspan="2" style="text-align: center">
  			<div align="center">23-10-2017</div></td>
  				</tr>
				<tr>
  <td dir="ltr" style="text-align: justify">
			<div align="justify">Decision of the Authority in the matter of Suo Moto 
			  Proceedings regarding Periodical Adjustments on account of Power 
			  Purchase Price (PPP) including Impact of T&amp;D Losses on FCA) and 
			  Prior Year :Adjustment (PYA) pertaining to the FY 2016-17 in the 
			  Consumer End Tariff of Gujranwala Electric Power Company Ltd. (GEPCO) </div></td>
  <td >
  
                    <div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2017/TRF-331%20PPP%20GEPCO%20FY%202016-17%2023-10-2017%2017392-94.PDF" class="default-btn">View</a> </div></td>
 					</tr>
				<tr>
  <td dir="ltr" rowspan="2" style="text-align: center">
  			<div align="center">02-10-2017</div></td>
  				</tr>
				<tr>
  <td dir="ltr" style="text-align: justify">
			<div align="justify">Decision of the Authority in the matter of 
			  Fuel Charges Adjustment for the Month of August 2017 for 
			  XWDISCOs along with Notification Thereof</div></td>
  <td >
  
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20XWDISCOs%20FPA%20Aug-2017%2002-10-2017%2016419-36.PDF" class="default-btn">View</a> </div></td>
 					</tr>
				<tr>
            
                                  <td width="168" style="text-align: center"> 
				  <div align="center">18-09-2017</div></td>
                                  <td   style="text-align: justify">
                            
							        <div align="justify">Re-determination of the Authority in the matter 
							of Request for Reconsideration pertaining to the 
							Tariff Determination dated February 29, 2016 and 
							Review Decision dated May 11, 2016 with respect to
							Gujranwala Electric Power Company Ltd. (GEPCO) 
							for the FY 2015-16 under Section 31(4) of NEPRA Act 
				  1997 </div></td>
                  <td> 

            
  
                    <div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2017/TRF-331%20GEPCO%20Re-determination%2018-09-2017%2015603-05.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
  <td dir="ltr" style="text-align: center">
  			<div align="center">29-08-2017</div></td>
  <td dir="ltr" style="text-align: justify">
            <div align="justify">Decision of the 
              Authority in the matter of Fuel Charges Adjustment for the 
              Month of July 2017 for XWDISCOs along, with Notification 
              Thereof</div></td>
  <td >
  
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20MFPA%20XWDISCOs%20July-2017%2029-08-2017%2014848-65.PDF" class="default-btn">View</a> </div></td>
 					</tr>
				<tr>
            
                                  <td width="168" style="text-align: center"> 
            						
									<div align="center">01-08-2017					                </div>
                  <td  style="text-align: justify">
							<div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of June 2017 for 
				  XWDISCOs along with Notification Thereof</div></td>
                  <td> 

             
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20MFPA%20June-2017%2001-08-2017%2013416-33.PDF" class="default-btn">View</a> </div></td>
        		</tr>
				<tr>
  <td dir="ltr" style="text-align: center">
  			<div align="center">30-06-2017</div></td>
  <td dir="ltr" style="text-align: justify">
	<div align="justify">Decision of the Authority in the matter of Fuel 
	  Charges Adjustment for the Month of May 2017 for XWDISCOs along 
	  with Notification Thereof</div></td>
  <td>
  
                      
  
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20MFPA%20XWDISCOs%20May%202017%2030-06-2017%2010750-67.PDF" class="default-btn">View</a> </div></td>
 					</tr>
				<tr>
  <td dir="ltr" style="text-align: center">
  			<div align="center">01-06-2017</div></td>
  <td dir="ltr" style="text-align: justify">
	<div align="justify">Decision of the Authority in the matter of Fuel 
	  Charges Adjustment for the Month of April 2017 for XWDISCOs along 
	  with Notification Thereof </div></td>
  <td>
  
                      
  
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20MFPA%20APRIL-2017%20%20XWDISCOS%2001-06-2017%208395-8412.PDF" class="default-btn">View</a> </div></td>
 					</tr>
                <tr>
            
                                  <td width="168" style="text-align: center"> 
            						 
            						<div align="center">03-05-2017					                </div>
                  <td   style="text-align: justify">
                            <div align="justify">Decisions of the 
							Authority in the matter of Fuel Charges 
							Adjustments for the Months of February and 
							March 2017 for XWDISCOs along with 
				  Notifications Thereof</div></td>
                  <td> 

							 

                      <div align="center"><a target="_blank" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20MFPA%20XWDISCOs%20FEB-MAR%202017%2003-05-2017%206052-69.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
            
                                  <td width="168" style="text-align: center"> 
            						 
            						<div align="center">03-03-2017					                </div>
                  <td   style="text-align: justify">
                            <div align="justify">Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of January 2017 for
				  XWDISCOs along with Notification Thereof </div></td>
                  <td> 

							 

							<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20MFPA%20FCA%20XWDISCOs%2003-03-2017%202879-96.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
                                  <td style="text-align: center"> 
            						 
            						<div align="center">01-02-2017					                </div>
                    <td width="1087" style="text-align: justify">
							<div align="justify">Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of December 2016 for 
				  XWDISCOs along with Notification Thereof</div></td>
                  <td> 

							
							<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2017/TRF-100%20FCA%20XWDISCOs%2001-02-2017%201759-76.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
            
                                  <td style="text-align: center" > 
            						 
            						<div align="center">03-01-2017					                </div>
                    <td width="1087" style="text-align: justify">
							<div align="justify">Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of November 2016 
				  for XWDISCOs along with Notification Thereof</div></td>
                  <td> 

                  
					<div align="center"><a target="_blank" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20FCA%20XWDISCOs%20Nov%202016%2003-01-2016%2062-79.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2016</font></h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
            
                                  <td width="178"> 
            						 
            						<div align="center">30-11-2016									</div>
                  <td  style="text-align: justify">
							Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of October 2016 for 
							XWDISCOs along with Notification Thereof </td>
                  <td width="115"> 

       
                  <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20MFPA%20Oct%202016%20Ex-WAPDA%2030-11-2016%2016093-16111.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						 
            						<div align="center">01-11-2016									</div>
                  <td  style="text-align: justify">
							
                            Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of September 2016 for 
							XWDISCOs along with Notification Thereof </td>
                  <td> 

       
                    <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20FCA%20Sep%202016%20XWDISCOs%2001-11-2016%2014865-83.PDF" class="default-btn">View 
                    </a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						 
            						<div align="center">04-10-2016									</div>
                  <td  style="text-align: justify">
							
                            Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of August 2016 for 
							XWDISCOs along with Notification Thereof </td>
                  <td> 

                   
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20MFPA%20%20August%202016%2004-10-2016%2013703-21.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						
									<div align="center">29-08-2016									</div>
                  <td   style="text-align: justify">
                            Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of July 2016 for XWDISCOs along with Notification Thereof </td>
                  <td> 

             
                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20FCA%20XDISCOs%2029-08-2016%2011813-32.pdf">View
                    	</a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						
                                    <div align="center">01-08-2016									</div>
                  <td  style="text-align: justify">
							
                            Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of June 2016 for XWDISCOs along with Notification Thereof </td>
                  <td> 

                    

                    <div align="center">
						<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20MFPA%20XWDISCOs%20%20Jun%202016%2001-08-2016.PDF">View</a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						
									<div align="center">04-07-2016									</div>
                  <td   style="text-align: justify">
                           Decision 
							of the Authority in the matter of Gujranwala 
							Electric Power Company Ltd. (GEPCO) Biannual 
							Adjustments regarding Power Purchase Price and 
							Annual Adjustment on account of Prior Year 
							Adjustment pertaining to the FY 2015-16 Uptill, May 
							2016</td>
                  <td> 

                    
					<div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2016/TRF-331%20GEPCO%20POWER%20PURCHASE%20FY%202015-16%2004-07-2016%209885-87.PDF" class="default-btn">View</a></div></td>
        		</tr>
				<tr>
            
                                  <td width="178"> 
            						
									<div align="center">01-07-2016									</div>
                  <td   style="text-align: justify">
                            Decision 
							of the Authority in the matter of Request for 
							Reconsideration pertaining to the Tariff 
							Determination dated February 29, 2016 and Review 
							Decision dated May 11, 2016 with respect to GEPCO 
							for the FY 2015-16 under Section 7 &amp; 31(4) of NERPA 
							Act 1997 read with Rule 17 of the NEPRA Tariff 
							(Standards &amp; Procedure) Rules, 1998></td>
                  <td> 

                    
					<div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2016/TRF-331%20GEPCO%20RECONSIDERATION%20FY%202015-16%2001-07-2016%209778-80.PDF" class="default-btn">View</a></div></td>
        		</tr>
                <tr>
                  <td width="178">
                  <div align="center">30-06-2016</div></td>
                  <td width="1035" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of May 2016 for
							XWDISCOs along with Notification Thereof></td>
                  <td>

                  
					<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/Decision%20of%20the%20Authority%20in%20the%20matter%20of%20FCA%20May%202016.PDF" class="default-btn">View</a> </div></td>
                </tr>
				<tr>
            
                                  <td width="178"> 
            						
                                    <div align="center">31-05-2016									</div>
                  <td  style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment  for the Month of April 2016 for  XWDISCOs along with Notification Thereof </td>
                  <td> 

                    
					<div align="center"><a target="_blank" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20MFPA%20XWDISCOs%20APRIL%202016%2031-05-2016%208237-55.PDF" class="default-btn">View</a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						
                                    <div align="center">11-05-2016									</div>
                  <td width="1035"  style="text-align: justify">
                            Decision of the 
							Authority in the matter of Motion for Leave for 
							Review filed by Gujranwala Electric Power Company 
							Ltd. (GEPCO) against Determination of the 
							Authority pertaining to the Financial Year 2015-2016 
							Dated February 29, 2016</td>
                  <td> 

                    
                      <div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2016/TRF-331%20GEPCO%20REVIEW%20MOTION%20FY%202015-16.PDF" class="default-btn">View</a> </div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
            						
									<div align="center">03-05-2016									</div>
                  <td width="1035"  style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of March 2016 for XWDISCOs along with Notification Thereof</td>
                  <td> 

                    
					<div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20MFPA%20XWDISCOs%20MARCH%202016%2003-05-2016%206004-22.PDF" class="default-btn">View</a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
									
									<div align="center">04-04-2016									</div>
                  <td width="1035"  style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of February 2016 for XWDISCOs along with Notification Thereof></td>
                  <td> 

                     
                      <div align="center">
						<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20MFPA%20FCA%20Feb-2016%2004-04-2016%204271-89.PDF">View
                      	</a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
									
									<div align="center">03-03-2016									</div>
                  <td width="1035"  style="text-align: justify">
                            
                            Decision of the 
							Authority in the matter of Fuel Charges Adjustment 
							for the Month of January 2016 for XWDISCOs 
							along with Notification Thereof></td>
                  <td> 

                     
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/TRF-100%20MFPA%20XWDISCOs%20JANUARY%202016%2003-03-2016%202773-91.PDF" class="default-btn">View
                      </a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
									
									<div align="center">29-02-2016									</div>
                  <td   style="text-align: justify">
                            Determination of the 
							Authority in the matter of Petition filed by
							Gujranwala Electric Power Company Ltd. (GEPCO) 
							for the Determination of its Consumer end Tariff 
							Pertaining to Financial Year 2015-2016</td>
                  <td> 

                     
                      <div align="center"><a target="_blank" href="Tariff/DISCOs/GEPCO/2016/TRF-331%20GEPCO%20DETERMINATION%20(FY%202015-16)%2029-02-2016%202703-05.PDF" class="default-btn">View
                      </a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
									
									<div align="center">04-02-2016									</div>
                  <td width="1035"  style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of December 2015 
							for XWDISCOs along with Notification Thereof></td>
                  <td> 

                     
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2016/Decision%20of%20the%20authority%20for%20Fuel%20Charge%20Adjustment%20Dec%202015.PDF" class="default-btn">View
                      </a></div></td>
        		</tr>
                <tr>
            
                                  <td width="178"> 
									
									<div align="center">01-01-2016									</div>
                  <td width="1035"  style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of November 2015 
							for XWDISCOs along with Notification Thereof></td>
                  <td> 

                     
                      <div align="center"><a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20NOVEMBER%202015%20XWDISCOs%2001-01-2016%2018705-23.PDF" class="default-btn">View
                      </a></div></td>
        		</tr>
                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2015</font></h6>
									
								</div>
								
								<div class="accordion-content">
									<table border="0" align="center" cellpadding="2" >
                <tr>
            
                                  <td width="14%" style="text-align: center"> 
									
                  	04-12-2015                                 
									<td width="79%"   style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of October 2015 for XWDISCOs 
							along with Notification Thereof</td>
                  <td width="7%" style="text-align: center" > 

                     
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2015/Decision%20of%20the%20Authority%20%20of%20FCA%20for%20October,%202015%20for%20XWDISCOs.pdf">View					</a></td>
        		</tr>
                <tr>
            
                                  <td style="text-align: center"  > 
									
                  	05-11-2015                                 
									<td   style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment  for the Month of September 2015 for XWDISCOs 
							along with Notification Thereof</td>
                  <td style="text-align: center" > 

                    
					<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20%20XWDISCOs%20SEPTEMBER%202015%2005-11-2015%2016054-72.PDF" class="default-btn">View 

					</a></td>
        		</tr>
				<tr>
            
                                  <td style="text-align: center"  > 
									
                  	27-10-2015                                 
									<td   style="text-align: justify">
                            Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of August 2015  
							for XWDISCOs 
							along with Notification Thereof</td>
                  <td style="text-align: center" > 
                    
                      <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20DISCOs%20August-2015%2015556-74%2027-10-2015.pdf">View
						</a></td>
        		</tr>
                <tr>
            
                                  <td style="text-align: center"  > 
									
                  	01-10-2015                                 
									<td   style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of July 2015 for XWDISCOs 
							along with Notification Thereof</td>
                  <td style="text-align: center" > 
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20July-2015%2001-10-2015%2014452-70.PDF">View 
					</a></td>
        		</tr>
				<tr>
            
                                  <td style="text-align: center"  > 
									
                  	01-10-2015                                 
									<td   style="text-align: justify">
                            Decision 
							of the Authority in the matter of Fuel Charges 
							Adjustment for the Month of June 2015 for XWDISCOs 
							along with Notification Thereof</td>
                  <td style="text-align: center" > 
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20June-2015%2001-10-2015%2014432-50.PDF">View 
					</a></td>
        							</tr>
                <tr>
          <td style="text-align: center" > 
									
									03-08-2015 
			<td  style="text-align: justify"> 
                            Decision of the Authority in the matter of Fuel 
							Charges Adjustment for the Month of May 2015 
							for XWDISCOs along with Notification Thereof</td>
          <td style="text-align: center" > 
                    
                  <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/Decision%20Fuel%20Charge%20Adjustment%20-%20May%202015.PDF">View 
					</a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									
                            10-07-2015      
			<td  style="text-align: justify"> 
                                 Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment for the Month of April 2015 for 
							XWDISCOs along with Notification Thereof</td>
          <td style="text-align: center" > 
                  					<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20April-2015%2010-07-2015%2010369-87.PDF">View 
									</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									
									24-06-2015  
			<td  style="text-align: justify"> 
                                 Decision of the 
									Authority in the matter of Fuel Charges 
									Adjustment for the Month of March 
									2015 for XWDISCOs along with 
									Notification Thereof</td>
          <td style="text-align: center" > 
                  <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20Mar-2015%2024-06-2015%209481-9501.PDF">View</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									16-06-2015</td>
          <td  style="text-align: justify"> 
                                 Decision of the Authority in the matter of 
									Motion 
									for Leave for Review filed by Gujranwala 
									Electric Power Company Ltd. (GEPCO) 
									against the Authority Determination dated 
									March 20, 2015 pertaining to the FY 2014-15</td>
          <td style="text-align: center" > 
                  <a class="default-btn" target="_blank" href="Tariff/DISCOs/GEPCO/2015/TRF-285%20GEPCO%20Review%20Motion%2016-06-2015%209172-74.PDF">View</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									12-06-2015</td>
          <td  style="text-align: justify"> 
                                 Notification of 
									DISCOs SRO No. 566 (I)/2015 to SRO No. 
									575(1)/2015 dated 12-06-2015 </td>
          <td style="text-align: center" > 
                  <a class="default-btn" target="_blank" href="Tariff/Notifications/NOTIFICATIONS%20OF%20DISCOs%20(SRO.%20566%20to%20575).PDF">View</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									 
									09-06-2015</td>
          <td  style="text-align: justify"> 
                  Decision of the Authority in the matter of a Request for 
					Reconsideration of Tariff Determinations for the Ex-WAPDA 
					Distribution Companies for the Financial Year 2014-15 under 
					Section 31(4) of NEPRA Act, 1997 </a></td>
					 <td style="text-align: center" > 
                  <a class="default-btn" target="_blank" href="Tariff/Notifications/NOTIFICATIONS%20OF%20DISCOs%20(SRO.%20566%20to%20575).PDF">View</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									26-05-2015</td>
          <td  style="text-align: justify"> 
   Corrigendum - Determination of the Authority in 
	the matter of Petition filed by Gujranwala Electric Power Company Ltd. (GEPCO) 
	for the Determination of its Consumer end Tariff Pertaining to FY 2014-2015</td>
          <td style="text-align: center" > 
       
                  <a class="default-btn" target="_blank" href="Tariff/DISCOs/GEPCO/2015/TRF-285%20GEPCO%20DETERMINATION%20FY%202014-15%2026-05-2015%208082-85.PDF">View</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
									22-04-2015</td>
          <td  style="text-align: justify"> 
   Decision of the Authority in the 
	matter of Fuel Charges Adjustment for the Month of February 2015 for
	XWDISCOs along with Notification Thereof</td>
          <td style="text-align: center" > 
       
                  <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20Feb-2015%2022-04-2015%206216-36.PDF" class="default-btn">View</a></a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
                                  30-03-2015</td>
          <td  style="text-align: justify"> 
    Decision of the Authority in the matter of Fuel 
		Charges Adjustment for the Month of January 2015 for XWDISCOs 
		along with Notification Thereof </td>
          <td style="text-align: center" > 
      
                  <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2015/TRF-100%20MFPA%20DISCOs%20JANUARY%202015%2030-03-2015%204363-83.PDF" class="default-btn">View</a> </td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
                                  20-03-2015</td>
          <td  style="text-align: justify"> 
   Determination of the Authority 
	in the matter of Petition filed by Gujranwala Electric Power Company Ltd. 
	(GEPCO) for the Determination of its Consumer end Tariff Pertaining to 
	FY 2014-2015</td>
          <td style="text-align: center" > 
            
                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2015/TRF-285%20GEPCO%20(DETERMINATION%20FY%202014-2015)%2020-03-2015%204161-63.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td style="text-align: center" > 
                                   
                                  04-03-2015  
			<td  style="text-align: justify"> 
         Decision of the Authority 
			in the matter of Fuel Charges Adjustment for the Month of December 
			2014 for XWDISCOs along with Notification Thereof </td>
          <td style="text-align: center" > 
            
                  <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2015/Fuel%20Price%20Adjustment%20December%202014.pdf">View</a></td>
        		</tr>
                </table>
									</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2014</font></h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
                                  <td width="178" style="text-align: center"> 
									28-11-2014</td>
                                  <td width="1107" style="text-align: justify">
    Decision of the 
	Authority in the matter of Fuel Charges Adjustment for the Month of October 
	2014 for XWDISCOs along with Notification Thereof</td>
                  <td style="text-align: center"> 
                     
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20XWDISCOs%20OCTOBER%202014%2028-11-2014%2015819-34.pdf">View</a> 
				  </td>
                </tr>
				<tr>
            
                                  <td  style="text-align: center"> 
									
									31-10-2014</td>
                                  <td  style="text-align: justify">
    Decision of the Authority regarding Request for Reconsideration of Tariff 
	Determinations for the Distribution Companies for the Financial Year 2013-14 
	under section 31(4) of NEPRA Act, 1997</td>
                  <td style="text-align: center"> 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/GOP%20Reconsideration%20for%20FY%202013-14%20Tariff.PDF" class="default-btn">
					View
					</a></td>
        		</tr>
				<tr>
            
                                  <td style="text-align: center" > 
									
									31-10-2014</td>
                                  <td  style="text-align: justify">
    Decision of the Authority in the matter of 
	Fuel Charges Adjustment for the Month of September 2014 for 
	XWDISCOs along with Notification Thereof</td>
                  <td style="text-align: center"> 
                    
					 
                    <a href="Tariff/Ex-WAPDA%20DISCOS/2014/FCA%20for%20XWDISCOs%20for%20Sep-2014%2031-10-2014.PDF" class="default-btn" target="_blank">View
					</a></td>
        		</tr>
                <tr>
            
          <td style="text-align: center"> 
			
									21-10-2014</td>
          <td  style="text-align: justify"> 
			
							Decision of the Authority in the matter 
			of Fuel Charges Adjustment for the month of August 2014 
			for XWDISCOs along with Notifications Thereof</td>
			<td style="text-align: center"  >
             
                    
					
             
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20DISCOs%20MFPA%20AUGUST%202014%2021-10-2014%2013021-41.pdf">View</a> 
					 </td>
        			</tr>
                <tr>
            
          <td style="text-align: center"> 
			
									01-09-2014</td>
          <td  style="text-align: justify"> 
			
							Decision of the Authority in the matter 
			of Fuel Charges Adjustment for the month of July 2014 
			for XWDISCOs along with Notifications Thereof</td>
			<td style="text-align: center"  >
            
					<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20DISCOs%20July-2014%2001-09-2014%2010136-55.PDF" class="default-btn">
					View
					</a></td>
        			</tr>
                <tr>
                  <td style="text-align: center">
                                  
									25-07-2014</td>
                  <td style="text-align: justify">
	Decision of the Authority in the matter of 
	Fuel Charges Adjustment for the month of June 2014 for 
	XWDISCOs along with Notifications Thereof</td>
                  <td style="text-align: center">
            
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/Decision%20of%20FCA%20for%20June%202014.PDF" class="default-btn">
					View 
					</a></td>
                </tr>
                <tr>
                  <td><div align="center">14-07-2014</div></td>
                  <td style="text-align: justify"><div align="justify">Decision of the Authority regarding Request for Reconsideration of Tariff Determinations for the WAPDA Distribution Companies for the Financial Year 2013-14 under Section 31(4) of NEPRA Act 1997 </div></td>
                  <td style="text-align: center"> 
            
                    <div align="center">					
                      					
                      <a target="_blank" class="default-btn" href="Tariff/DISCOs/Ex-WAPDA%20DISCOS/TRF-100%20RECONSIDERATION%20BY%20MOWP%2014-07-2014%208231-33.pdf">
                            View					
						</span></a>
						</font>
						</div></td>
                </tr>
                <tr>
          <td  style="text-align: center" > 
            30-06-2014</td>
          <td   style="text-align: justify"> 
			
							Decision of the Authority in the 
							matter of Fuel Charges Adjustment for the 
							Month of May 2014 for XWDISCOs along 
							with Notifications Thereof</td>
			<td width="43" style="text-align: center" >
									 
                  	<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/Decision%20of%20the%20Authority%20in%20matter%20of%20Fuel%20Charge%20Adjustment%20of%20May%202014.PDF" class="default-btn">
					View</a></td>
        		</tr>
				<tr>
          <td  style="text-align: center" > 
            16-06-2014</td>
          <td   style="text-align: justify"> 
			
							 
			
							Decision of the Authority in the matter of 
							Motion for Leave for Review filed by Gujranwala 
							Electric Power Company Ltd (GEPCO) against Tariff 
							Determination of the Authority dated January 16, 
							2014 </td>
			<td width="43" style="text-align: center" >
									 
                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2014/TRF-234%20GEPCO%20REVIEW%20MOTION%2016-06-2014%206298-00.PDF" class="default-btn">
					View</a></td>
        		</tr>
                <tr>
                  <td  style="text-align: center">
             
							27-05-2014</td>
                  <td style="text-align: justify">
			
							Decision of the 
							Authority in the matter of Fuel Charges Adjustment for the Month of
							April 2014  
							for XWDISCOs 
							along with Notifications Thereof
				  </td>
                  <td style="text-align: center">
                  	
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20MFPA%20APRIL%202014%2027-05-2014%205521-40.pdf">
					View</span></a></b></td>
                </tr>
                <tr>
            
          <td  style="text-align: center" > 
             
							29-04-2014</td>
          <td  style="text-align: justify"> 
			 
			Decision of the 
							Authority in the matter of Fuel Charges Adjustment for the Month of
			March 2014 for XWDISCOs 
							along with Notifications Thereof
				  </td>
			<td width="43" style="text-align: center" >
									 
									
									
									 
									<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20MFPA%20XWDISCOs%20MARCH%202014%2029-04-2014%204277-96.PDF" class="default-btn">View</a>
									</a></td>
        		</tr>
				<tr>
          <td  style="text-align: center" > 
            
							31-03-2014</td>
          <td   style="text-align: justify"> 
			
							 
			
							Decision of the 
							Authority in the matter of Fuel Charges Adjustment for the Month of
			February 2014 for 
			XWDISCOs 
							along with Notifications Thereof				  </td>
			<td width="43" style="text-align: center" >
									
									
									<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20MFPA%20DISCOs%20FEBURARY%202014%2031-03-2014%203102-21.PDF">
				  View									</span></a></b>				  </td>
        		</tr>
                <tr>
          <td  style="text-align: center"> 
							24-03-2014</td>
          <td  style="text-align: justify"> 

							Decision of the Authority in the matter of 
							Fuel Charges Adjustment for the Month of
							January 2014 for 
							XWDISCOs along with Notifications Thereof			</td>
          <td width="43" style="text-align: center" > 
									
									
									<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20DISCOs%20MFPA%20JANUARY%202014%2024-03-2014%202654-73.PDF">
				  View									</span></a></b>				  </td>
        		</tr>
                <tr>
          <td  style="text-align: center"> 
							06-02-2014</td>
          <td  style="text-align: justify"> 

							Decision of the 
							Authority in the matter of 
							Fuel Charges Adjustment for the Month of
							December 2013 
							for XWDISCOs along with Notifications Thereof			</td>
          <td width="43" style="text-align: center" > 
									
									
									<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20MFPA%20DISCOs%20DECEMBER%202013%2006-02-2014%201176-95.PDF">
				  View									</span></a></b>				  </td>
        		</tr>
                <tr>
          <td  style="text-align: center"> 
							29-01-2014</td>
          <td  style="text-align: justify"> 
			Corrigendum regarding S.R.O. No. 
							1017(1)/2013 dated 29.11.2013			</td>
          <td width="43" style="text-align: center" > 
									
									
									<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20MFPA%20JULY%20TO%20DEC%202012%20&%20JANUARY%20TO%20MAY%202013%20DISCOs%2029-01-2014%201077-96.PDF">
				  View									</span></a></b>				  </td>
        		</tr>
                <tr>
          <td  style="text-align: center"> 
							27-01-2014</td>
          <td  style="text-align: justify"> 
			Decisions of the 
							Authority in the matter of 
							Fuel Charges Adjustments for the Months 
							of October and November 2013 
							for XWDISCOs along with Notifications 
							Thereof</td>
          <td width="43" style="text-align: center" > 
									
									
									<a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2014/TRF-100%20MFPA%20OCT-NOV-2013%2027-01-2014%20987-06.PDF">
				  View									</span></a></b>				  </td>
        		</tr>
                <tr>
          <td  style="text-align: center"> 
			
			16-01-2014</td>
          <td  style="text-align: justify"> 
			Determination of the Authority in 
			the matter of Petition filed by Gujranwala Electric Power Company Ltd. 
			for Determination of its Consumer end
			Tariff Pertaining to the FY 2013-14</td>
          <td width="43" style="text-align: center" > 
            
									
									<a class="default-btn" target="_blank" href="Tariff/DISCOs/GEPCO/2014/TRF-234%20GEPCO%20Determination%2016-01-2014%20675-77.PDF">
				  View									</span></a></b>				  </td>
        		</tr>
                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2013</font></h6>
									
								</div>
								
								<div class="accordion-content">
															
								<table  border="0" align="center" cellpadding="2" >
                <tr>
          <td width="178" style="text-align: center"> 
			
			03-12-2013
          <td width="1047" style="text-align: justify"> 
			Corrigendum : regarding S.R.O. No. 
			1009(1)/2013 dated 29.11.2013</td>
          <td width="103" style="text-align: center" > 
            
									<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20MFPA%20DISCOs%20CORRIGENDUM%2003-12-2013%2013316-35.PDF" class="default-btn">View									</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			29-11-2013</td>
          <td width="1047" style="text-align: justify"> 
            Decision of the 
			Authority in the matter of Fuel Charges 
			Adjustments for the Months of 
			July, August, September, October, November, December 2012 
			and January, February, March, April &amp; 
			May 2013 for XWDISCOs along with Notifications Thereof</td>
          <td width="103" style="text-align: center" > 
            
									<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20DISCOs%20JULY%20TO%20DEC%202012%20JAN%20TO%20MAY%202013%2029-11-2013%2013239-58.PDF" class="default-btn">View									</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			31-10-2013</td>
          <td width="1047" style="text-align: justify"> 
			
			Decision of the Authority in the matter 
			of Fuel Charges Adjustment for the Month of 
			September 2013 for XWDISCOs and Notification (S.R.O. 
			958(1)/2013 dated 30.10.2013) Thereof</td>
          <td width="103" style="text-align: center" > 
            
									<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20MFPA%20SEP-2013%2031-10-2013%2012241-60.PDF" class="default-btn">View									</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			11-10-2013</td>
          <td width="1047" style="text-align: justify"> 
            Notifications 
			of NEPRA determination for Eight (8) DISCOs except KESC &amp; PESCO</td>
          <td width="103" style="text-align: center" > 
            
			<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/D-8186-14-10-2013-MOWP.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			
							11-10-2013      
			<td width="1047" style="text-align: justify"> 
            
							Decision of the Authority regarding 
							Request for Reconsideration of 
			Tariff Determinations Pertaining to the Ex-WAPDA 
			Distribution Companies for the Financial Year 2012-13 under Section 
			31(4) of NEPRA Act 1997</td>
          <td width="103" style="text-align: center" > 
            
			<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20DISCOs%20GOP%20RECOSIDERATION%2011-10-2013%2011280-82.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			23-09-2013</td>
          <td width="1047" style="text-align: justify"> 
			Decision of the Authority in the matter 
			of Fuel Charges Adjustment for 
			the Month of August 2013 for 
			XWDISCOs and Notification (S.R.O. 804(1)/2013 dated 19.09.2013) 
			Thereof</td>
          <td width="103" style="text-align: center" > 
            
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20DISCOs%20MFPA%20AUG%202013%2023-09-2013%2011470-89.PDF">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
							
			04-09-2013
          <td width="1047" style="text-align: justify"> 
            Decision of the 
			Authority in the matter of Fuel Charges 
			Adjustment for the Month of July 2013  
			for XWDISCOs and Notification (S.R.O. 762(1)/2013 dated 29.08.2013) 
			Thereof</td>
          <td width="103" style="text-align: center" > 
            
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20DISCOs%20MFPA%20JULY%202013%2004-09-2013%2010865-82.PDF">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
							05-08-2013</td>
          <td width="1047" style="text-align: justify"> 
                            Notification of Schedule-I &amp; Schedule-II for 8 DISCO's and KESC except PESCO</td>
          <td width="103" style="text-align: center" > 
            
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/Notification%20of%20Schedule%20I%20and%20II%20for%208%20DISCO's%20and%20KESC.%20Except%20PESCO%2015-08-2013.pdf">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
							15-08-2013</td>
          <td width="1047" style="text-align: justify"> 
                            Notification of Schedule-I &amp; Schedule-II for 8 DISCO's and KESC except PESCO</td>
          <td width="103" style="text-align: center" > 
            
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/Notification%20of%20Schedule%20I%20and%20II%20for%208%20DISCO's%20and%20KESC.%20Except%20PESCO%2015-08-2013.pdf">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
							18-07-2013</td>
          <td width="1047" style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of 
							Fuel Charges Adjustment for the Mouth of
							June 2013 for 
							XWDISCOs and Notification (S.R.O. 671(1)/2013 dated 
							16.07.2013) Thereof</td>
          <td width="103" style="text-align: center" > 
                    <a class="default-btn" target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20DISCOs%20June-2013%208869-86%2018-07-2013.PDF">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
							28-06-2013</td>
          <td width="1047" style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of 
							Fuel Charges Adjustment for the Month of
							May 2013 for XWDISCOs 
							and Notification (S.R.O. 614(1)/2013 dated 
							26.06.2013) Thereof</td>
          <td width="103" style="text-align: center" > 
            
                    					<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20MFPA%20MAY%202013%2028-06-2013-8371-88.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
                            11-06-2013</td>
          <td width="1047" style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of 
							Fuel Charges Adjustment for the Month of
							April 2013 for 
							XWDISCOs and Notification (S.R.O. 493(1)/2013 dated 
							06.06.2013) Thereof</td>
          <td width="103" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20DISCOs%20FPA%20APRIL%202013%205699-5707%2011-06-2013.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
                            17-05-2013</td>
          <td width="1047" style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of 
							Fuel Charges Adjustments for the Months 
							of August, September, 
							October, November, December 2012 and
							January, February &amp; March 
							2013 for XWDISCOs along with Corrigendum 
							and Notifications Thereof</td>
          <td width="103" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2013/TRF-100%20EXWAPDA.PDF" class="default-btn">View</a></td>
        		</tr>
                </table>		
					
								</div>
								
							</li>
							<!-- /Accordion -->
							
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2012</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
          <td width="178" style="text-align: center"> 
                            16-08-2012</td>
          <td width="1061" style="text-align: justify"> 
                            Decision of the Authority in 
			the matter of Fuel 
			Price Adjustment for the Month of 
			June, 2012 for XWDISCOs</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20MFPA%20June-2012%2016-08-2012%206375-92.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
                            11-07-2012							</td>
          <td width="1061" style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment 
                            for 
							the Month of  
                            May 2012 
                            for XWDISCOs</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20MFPA%20May-2012%2011-07-2012%206053-70.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
                            07-06-2012</td>
          <td width="1061" style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							the Month of April 2012 for XWDISCOs 
							and Notification (S.R.O. 694(I)/2012 dated 
							06.06.2012 Thereof</td>
          <td width="89" style="text-align: center" > 
                    
					<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20MFPA%20April-2012%2007-06-2012%205311-27.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			25-05-2012</td>
          <td width="1061" style="text-align: justify"> 
			Addendum in the matter of Determination 
			of the Authority for the 
			1st Quarter (July - September) of the 
			FY-2010-11.</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20Addendum%2025-05-2012%204702-15.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
            22-05-2012</td>
          <td width="1061" style="text-align: justify"> 
            Decision of the Authority in the matter of Fuel Price Adjustment for 
			the Month of March 2012 for XWDISCOs and Notification (S.R.O. 
			524(1)/2012 dated 18.05.2012)
			Thereof</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20Mar-2012%2022-05-2012%204572-89.PDF" class="default-btn">View</a></td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
			22-05-2012</td>
          <td width="1061" style="text-align: justify"> 
			Decision of the Authority in the matter of 
			Fuel Price Adjustment
			for 
			the Month of 
			February 2012
			for XWDISCOs 
			and Notification (S.R.O. 523(1)/2012 dated 18.05.2012) Thereof</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOS%20Feb-2012%2022-05-2012%204572-89.PDF" class="default-btn">View</a></td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
                            16-05-2012</td>
          <td width="1061" style="text-align: justify"> 
                            S.R.O 
							508 (I)/2012 Schedule-II of Tariff for GEPCO</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/Schedule-II%2016-05-2012/GEPCO%20Notification%20Schedule-II%2016-05-2012.pdf">View</a></td>
          		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
                            09-05-2012</td>
          <td width="1061" style="text-align: justify"> 
                            S.R.O 
							488 (I)/2012 Schedule-I of Tariff for GEPCO</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/Schedule-I%2009-05-2012/GEPCO%20Notification%20Schedule-I%2009-05-2012.pdf">View</a></td>
          		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
                            03-05-2012</td>
          <td width="1061" style="text-align: justify"> 
                            Decision of the Authority in the matter of 
							Fuel 
							Price Adjustment for the Month of 
							January 2012 for XWDISCOs and Notification (SRO. 450(I)/2012 dated 
							2.5.2012)
							Thereof</td>
          <td width="89" style="text-align: center"> 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20MFPA%20January-2012%2003-05-2012%204210-27.PDF" class="default-btn">View</a></td>
          		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
            03-05-2012</td>
          <td width="1061" style="text-align: justify"> 
            Decision of the 
			Authority in the matter of Fuel Price Adjustment for the Month of 
			December 2011 for XWDISCOs and Notification (SRO. 449(I)/2012 dated 
			2.5.2012) Thereof</td>
          <td width="89" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20MFPA%20December-2011%2003-05-2012%204190-208.PDF" class="default-btn">View</a></td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
			03-05-2012</td>
          <td width="1061" style="text-align: justify"> 
			Decision of the 
			Authority in the matter of Fuel Price Adjustment for the Month of 
			November 2011 for XWDISCOs and Notification (SRO. 
			448(I)/2012 dated 2.5.2012) Thereof</td>
          <td width="89" style="text-align: center"> 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20MFPA%20November-2011%2003-05-2012%204170-88.PDF" class="default-btn">View</a></td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
            03-05-2012</td>
          <td width="1061" style="text-align: justify"> 
            Decision of the 
			Authority in the matter of Fuel Price Adjustment for the Month of 
			October 2011 for XWDISCOs and Notification (SRO. 447(I)/2012 dated 
			2.5.2012) Thereof</td>
          <td width="89" style="text-align: center"> 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20XWDISCOs%20MFPA%20October-2011%2003-05-2012%204151-68.PDF" class="default-btn">View</a></td>
        		</tr>
                <tr>
                  <td style="text-align: center"> 
                            17-04-2012</td>
                  <td style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of Monthly 
							Fuel Price Adjustment
							for the Month of 
							September 2011
							for XWDISCOs </td>
                                  <td width="89" style="text-align: center">
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2012/TRF-100%20MFPA%20Sept-2011%2017-04-2012%203757-74.PDF" class="default-btn">View</a>
			</a>
					</a></td>
                </tr>
                <tr>
                                  <td width="178" style="text-align: center" >
                            29-02-2012</td>
                                  <td width="1061" style="text-align: justify">
                            Decision of the Authority in 
							the Matter of Fuel Price Adjustment for the month of 
							August 2011 for XWDISCOs &amp; Notification of the 
							Decision SRO 202(I)/2012 dated 28.02.2012</td>
                  <td style="text-align: center"> 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/TRF-100%20MFPA%20AUG-2011%2029-02-2012.pdf">View</a>
			</a>
					</a></td>
                </tr>
                <tr> 
                  <td style="text-align: center"> 
                            24-02-2012</td>
                  <td style="text-align: justify"> 
                            Decision of the 
					Authority in the Matter of  
                            Reconsideration Request filed by 
					Ministry of Water &amp; Power 
                            against Authority's Determination 
					for GEPCO
							for the FY 2011-12</td>
                                  <td width="89" style="text-align: center">
                              <a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2012/TRF-171%20GEPCO%2024-02-2012%201468-70.pdf">View</a></a>			</td>
                </tr>
                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2011</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2">
                <tr>
          <td width="178" style="text-align: center"> 
    	                    13-12-2011</td>
          <td width="1004" style="text-align: justify"> 
    	                    Determination
    	                    of the 
							Authority in the matter of Petition filed by GEPCO 
							for determination of its Consumer end Tariff 
							Pertaining to the 
    	                    FY 2011-12</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" href="Tariff/DISCOs/GEPCO/2011/GEPCO%20Tariff%20Determination.PDF" class="default-btn">View</a></a>				  </td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
    	                    03-10-2011</td>
          <td width="1004" style="text-align: justify"> 
    	                    Decision of the Authority in the matter of 
							Fuel 
							Charges Adjustment
							for the Month of 
							July 2011
							for XWDISCOs</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2011/DISCO'S%20JULY%202011.PDF" class="default-btn">View</a></a>			</td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
			12-08-2011</td>
          <td width="1004" style="text-align: justify"> 
			Decision of the 
			Authority in the Matter of Fuel Charges Adjustment for the Month of 
			June 2011 for XWDISCOs</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20MPFA%20June%202011%2021-08-2011%207390-7392.PDF">View</a> </td>
        		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
    	  19-07-2011</td>
          <td width="1004" style="text-align: justify"> 
    	  Decision of the Authority 
			in the matter of Fuel Charges Adjustment for the month of May 2011 
			for XWDISCOs</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20MPFA%20May%202011%2019-07-2011%205532-5534.PDF" class="default-btn">View</a> </td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
    	  15-07-2011</td>
          <td width="1004" style="text-align: justify"> 
    	  Decision 
			of the Authority in the matter of Fuel Charges Adjustment for the 
			month of April 2011 for XWDISCOs</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20MPFA%20April%202011%2015-06-2011%204295-4297.PDF" class="default-btn">View</a> </td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
                            20-05-2011</td>
          <td width="1004" style="text-align: justify"> 
                            S.R.O. 
							406(I)/2011 Schedule-II - Tariff Notifications of 
							Ex-WAPDA DISCOs I/R of Fuel Price Adjustment for the 
							Month of March, 2011</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/Notifications/TRF-100%20MPFA%20March%202011%2017-05-2011%20SRO%20Notification.PDF" class="default-btn">View</a> </td>
          		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
                            06-05-2011</td>
          <td width="1004" style="text-align: justify"> 
                            S.R.O. 
							365(I)/2011 Schedule-II of Tariff for GEPCO</td>
          <td width="146" style="text-align: center" > 
                    <a target="_blank" href="Tariff/DISCOs/GEPCO/2011/SRO-NOTIFICATION(GEPCO).PDF" class="default-btn">View</a> </td>
          		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
    02-05-2011</td>
          <td width="1004" style="text-align: justify"> 
    Decision of the Authority in the matter of 
	Fuel Charges Adjustment for the month of March 2011 for XWDISCOs</td>
          <td width="146" style="text-align: center"> 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20MPFA%20March%202011%2002-05-2011%203160-3162.PDF" class="default-btn">View</a> </td>
          		</tr>
                <tr>
          <td width="178" style="text-align: center"> 
                            27-04-2011</td>
          <td width="1004" style="text-align: justify"> 
                            Determination of the Authority in the matter 
							of Petition filed by GEPCO for Determination of its 
							Consumer end Tariff pertaining to the 2nd, 3rd and 4th Quarters 
							(October - June 2011) of the FY 2010-11</td>
          <td width="146" style="text-align: center"> 
            <a target="_blank" href="Tariff/DISCOs/GEPCO/2011/TRF-154%20GEPCO%202,3,4%20Qtr%202010-11%2027-04-2011%203000-3002.PDF" class="default-btn">View</a> </td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
            01-04-2011</td>
          <td width="1004" style="text-align: justify"> 
    Decision of the Authority in the Matter of Fuel Charges Adjustment for the 
	Month of February 2011 for XWDISCOs</td>
          <td width="146" style="text-align: center"> 
                    <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20%20XWAPDA%20DISCOS%20February%202011%2001-04-2011%202266-2268.PDF" class="default-btn">View</a></td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
                            15-05-2011</td>
          <td width="1004" style="text-align: justify"> 
                            S.R.O. 
							238(I)/2011 Schedule-II of Tariff for GEPCO</td>
          <td width="146" style="text-align: center"> 
            <a target="_blank" href="Tariff/DISCOs/SROs/1st%20Qtr%202010-2011/GEPCO/SRO%20238%20(I)%202011%2015-03-2011.PDF" class="default-btn">View</a> </td>
        		</tr>
				<tr>
          <td width="178" style="text-align: center"> 
									28-02-2011</td>
          <td width="1004" style="text-align: justify"> 
									Decision of the Authority in the Matter 
			of 
            						Fuel Charges Adjustment
            						for the Month of January 2011
            						for XWDISCOs</td>
          <td width="146" style="text-align: center"> 
            <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20XWDISCOs%20Adjustment%20January%202011%2028-02-2011%201300-1302.pdf">View</a> </td>
        		</tr>
                <tr>
                  <td style="text-align: center" > 
                            08-02-2011</td>
                  <td  style="text-align: justify"> 
                            Decision of the 
							Authority in the matter of Fuel Charges 
							Adjustment 
							for the Month of December 2010 for XWDISCOs</td>
                                  <td width="146" style="text-align: center" >
                    <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2011/TRF-100%20XWDISCOs%20Adjustment%20December%202010%2008-02-2011%20732-734.pdf">View</a> </td>
                </tr>

                <tr>
                  <td  width="178" style="text-align: center">
                            27-01-2011</td>
                  <td  width="1004" style="text-align: justify">
                            Decision of the 
							Authority with respect to Motion for Leave for 
							Review filed under Rule 16(6) of NEPRA (Tariff 
							Standards and Procedure) Rules, 1998 by GEPCO 
							against the Authority's Determination</td>
                  <td style="text-align: center" >
									<a target="_blank" href="Tariff/DISCOs/GEPCO/2011/TRF-154%20GEPCO%20Review%20Motion%2027-01-2011%20529-531.PDF" class="default-btn">View</a> </td>
                </tr>

                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2010</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
                  <td  width="178" style="text-align: center">
                            31-12-2010</td>
                  <td  width="1042" style="text-align: justify">
                           Decision of the 
							Authority in the matter of Fuel Charges Adjustment 
							for the Month of November 2010
							for XWDISCOs</td>
                  <td style="text-align: center" >
									<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-100%20MFPA%20for%20November%202010%2031-12-2010%204912-4914.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td  width="178" style="text-align: center">
                            09-12-2010</td>
                  <td  width="1042" style="text-align: justify">
                           Determination of the 
							Authority in the matter of Petition filed by GEPCO for Determination of 
							its Consumer-end Tariff Pertaining to the 
							1st 
							Quarter (July-September) of 
							FY 2010-11.</td>
                  <td style="text-align: center" >
			<a target="_blank" href="Tariff/DISCOs/GEPCO/2010/TRF-154%20GEPCO%20IST%20QUATER%20JULY%20-SEPTEMBER%202010-2011.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td  width="178" style="text-align: center">
                            26-11-2010</td>
                  <td  width="1042" style="text-align: justify">
                           Decision of the 
							Authority in the matter of Fuel Charges Adjustment 
							for the Month of October 2010 for XWDISCOs</td>
                  <td style="text-align: center" >
									<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-100%20XWDISCOs%2026-11-2010%204083-4085.pdf">View</a> </td>
                </tr>
				<tr>
                                  <td  width="178" style="text-align: center">
                            04-11-2010</td>
                                  <td  width="1042" style="text-align: justify">
                           Determination of the Authority regarding 
							Security Deposit Rates applicable to all DISCOs</td>
                                  <td style="text-align: center" >
                                  <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-100%20Decision%20XWDISCOs%20Security%20Deposit%20rates%2004-11-2010%203685-3687.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
					<td style="text-align: center">
									 
									02-11-2010</td>
					<td style="text-align: justify">
								Decision of the Authority in the matter of 
									Fuel Charges Adjustment
									for the Month of 
									September 2010
									for XWDISCOs</td>
					<td style="text-align: center">
                  <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-100%20MFPA%20for%20September%202010%2002-11-2010%203440-3442.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td style="text-align: center">
									
									01-10-2010</td>
					<td style="text-align: justify">
								Notification - S.R.O 910 (I)/2010 
									Schedule-II, Schedule of Electricity 
									Tariff for GEPCO</td>
					<td style="text-align: center">
                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2010/GEPCO%20SRO%20910(I)2010%20DATED%2001-10-2010.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td style="text-align: center">
									
									27-09-2010</td>
					<td style="text-align: justify">
								Decision of the 
									Authority in the matter of Fuel Charges 
									Adjustment 
									for the Month of 
									August 2010 for XWDISCOs</td>
					<td style="text-align: center">
                  <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-100_XWDISCOs_27-09-2010_2615-2617.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td style="text-align: center">
									 
									08-09-2010</td>
					<td style="text-align: justify">
								Determination of the Authority in the Matter of Petition 
									filed by GEPCO for
									Determination of Consumer-End Tariff for 4th 
									Quarter (April - June 2010) of FY 2009-10</td>
					<td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2010/TRF-126%20GEPCO%2008-09-2010%202366-2368.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td style="text-align: center">
									
									26-08-2010 </td>
									<td>
								Decision of the 
									Authority in the Matter of Fuel Charges 
									Adjustment for the month of July 2010 for XWDISCOs</td>
					<td style="text-align: center">
									<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2010/Decision%20XWDISCOs%20July%202010.pdf">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
									
									26-07-2010</td>
					<td width="1042" style="text-align: justify">
								Decision of the 
									Authority in the matter of Fuel Price 
									Adjustment for the Month of June 2010 for XWDISCOs and 
									Notification of the Decision (S.R.O 
									683(I)2010 dated 26.07.2010)</td>
					<td width="108" style="text-align: center">
                                  	<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/Fuel%20Price%20Adjustment%20for%20the%20Month%20of%20June%202010.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
									
									30-06-2010 </td> 
					<td width="1042">
								Decision of the 
									Authority in the Matter of 
									Fuel Price 
									Adjustment 
									for the Month of 
									May 2010
									for XWDISCOs and Notification of the 
									Decision (S.R.O. 590(I)/2010 dated 
									30.06.2010)</td>
					<td width="108" style="text-align: center">
                                  <a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/2010/Decision%20Fuel%20Price%20Adj.%20of%20May%202010%20(DISCOs).PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
									
									28-05-2010</td>
					<td width="1042" style="text-align: justify">
								Decision of the Authority in the 
									Matter of 
									Fuel Price Adjustment
									for the 
									Month of 
									April 2010
									for XWDISCOs and 
									Notification of the Decision (S.R.O. 
									356(I)/2010 dated 28.05.2010</td>
					<td width="108" style="text-align: center">
                                  	<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-100-MFPA%20Monthly%20Fule%20Price%20Adjustment%20for%20the%20month%20of%20April%202010%20dated%2028-05-2010.pdf">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
									
									30-04-2010 </td>
					<td width="1042" style="text-align: justify">
                                  Decision of the Authority in the Matter of 
									Fuel Price Adjustment for the month of March 
									2010 for Ex-WAPDA Distribution Companies </td> 
					<td style="text-align: center">
									<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2010/Decision%20-%20Fuel%20Price%20Adjustment%20March%202010.pdf">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
                            
                            19-04-2010	
					<td width="1042" style="text-align: justify">
                           Determination of the 
							Authority in matter of Petition filed by GEPCO for Determination of Consumer-end 
							Tariff for 
							2nd Quarter (October-December) of 
                            Fy 
							2009-10</td>
					<td width="108" style="text-align: center">
					<a target="_blank" href="Tariff/DISCOs/GEPCO/2010/TRF-126%20GEPCO%202009%20Determination%202nd%20%20Quarter%20October-December%20of%20FY%202009-2010.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
                            
                            27-03-2010	
					<td width="1042" style="text-align: justify">
                           Decision 
							of the Authority in the matter of Fuel Price 
							Adjustment for the Month of February 2010 for XWDISCOs and 
							Notification of the Decision (S.R.O.209(I)/2010 
							dated 27.03.2010)</td>
					<td width="108" style="text-align: center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2010/TRF-102-109%20Ex-WAPDA%20DISCOs%20Monthly%20Adjustment%20for%20the%20Month%20of%20February%20,%202010.pdf">View</a> </td>
				</tr>
				<tr >
					<td width="178" style="text-align: center" >
					
					05-03-2010</td>
					<td width="1042" style="text-align: justify" >
				Adjustment in the Fuel cost component 
					on account of fuel price 
					variation for the month of
					January 2010 
					for Ex-WAPDA 
							Distribution Companies</td>
					<td width="108" style="text-align: center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/2010/FPA%20Notification%205-Mar-10.pdf">View</a> </td>
				</tr>
				<tr>
					<td width="178" style="text-align: center">
					23-01-2010</td>
					<td width="1042" style="text-align: justify">
				NOTIFICATION of Fuel Price 
    Adjustment for the month of 
    December 2009 for Ex-WAPDA Distribution Companies</td>
					<td width="108" style="text-align: center">
					<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications%20EX-WAPDA%20December%202009.pdf">View</a> </td>
				</tr>
                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2009</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
                                  <td width="178" style="text-align: center">
    29-12-2009</td>
                                  <td width="1048" style="text-align: justify">
    NOTIFICATION of Fuel Price 
    Adjustment for the month of 
    November 2009 for Ex-WAPDA Distribution Companies</td>
                                  <td width="102" style="text-align: center">
                              <a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/Notifications%20EX-WAPDA%20November%202009.pdf">View</a> </td>
                </tr>
				<tr>
                                  <td width="178" style="text-align: center">
    09-12- 
	2009</td>
                                  <td width="1048" style="text-align: justify">
    								1st Quarterly Determination Based on the 
									FY 2009-10 Determined under NEPRA 
	(Tariff Standards and Procedure) Rules, 1998 for GEPCO</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/TRF-126%20GEPCO%202009%20Determination%20Ist%20Quarter%20July-Sep%20of%20FY%20.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            02-12-2009</td>
                                  <td width="1048" style="text-align: justify">
                            Notification of 
                            Fuel 
							Price Adjustment for the Month of 
                            October, 2009 for Ex-WAPDA Distribution Companies</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/Ex-WAPDA%20DISCOS/TRF-102-09%20Notification%20of%20Fuel%20Price%20Adjustment%20for%20the%20month%20of%20October%202009%20for%20Ex-WAPDA%20DISCOs%20Dated%2003-12-2009.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            
                            24-11-2009                  
									<td width="1048" style="text-align: justify">
                           Decision of the Authority in the Matter of 
							Reconsideration Request of Federal Government
							regarding Monthly Adjustment of Power Purchase Price 
							(PPP) for GEPCO</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO-2009%20Modified%20Monthly%20Adjustments%20for%20Months%20of%20May%20and%20June%20,%202009.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            30-10-2009  </td>
                                  <td width="1048" style="text-align: justify">
                           Notification of 
                            Fuel Price Adjustment
							for the Months of 
							August &amp; September, 2009
							for 
                            Ex-WAPDA Distribution Companies</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" class="default-btn" href="Tariff/Ex-WAPDA%20DISCOS/TRF-102-09%20Notification%20of%20Fuel%20Price%20Adjustment%20for%20the%20month%20of%20August%20and%20September%202009%20for%20Ex-WAPDA%20DISCOs%20Dated%2030-10-200.pdf">View</a> </td>
                </tr>
				<tr>
                                  <td width="178" style="text-align: center">
                                  02-10-2009</td>
                                  <td width="1048" style="text-align: justify">
                                 Notification - GEPCO Adjustment for
                                  Power Purchase Price 
									for the Month of 
                                  July 2009</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2009/GEPCO%202009.pdf">View</a> </td>
				</tr>
				<tr>
                                  <td  width="178" style="text-align: center">
                                  14-09-2009  </td>
                                  <td  width="1048" style="text-align: justify">
                                 Determination of 
									the Authority in the Matter of Petition by
                                  GEPCO for Determination of Consumer-end 
                                  Tariff for the Year 2008-2009 under NEPRA 
                                  (Tariff Standards and Procedure) Rules, 1998.</td>
                                  <td style="text-align: center" >
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPOC%202008%20Determination%20Dated%2014-09-2009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td  width="178" style="text-align: center">
                                  	11-09-2009</td>
                                  <td  width="1048" style="text-align: justify">
                                 Decision of the 
									Authority in the Matter of Monthly 
									Adjustment of Power Purchase Price (PPP) 
									(June 2009) for GEPCO</td>
                                  <td style="text-align: center" >
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO-2009%20Monthly%20Adjustment%20for%20Month%20of%20June,%202009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td  width="178" style="text-align: center">
                                  11-09- 2009</td>
                                  <td  width="1048" style="text-align: justify">
                                  Decision of the Authority in the Matter of 
									Monthly Adjustment of Power Purchase Price 
									(PPP) for GEPCO</td>
                                  <td style="text-align: center" >
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO-2009%20Monthly%20Adjustment%20for%20Month%20of%20May,%202009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            03-08-2009</td>
                                  <td width="1048" style="text-align: justify">
                           Decision of the Authority in the Matter of Monthly 
							Adjustment of Power Purchase Price (PPP) for
                            GEPCO.</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO-2009%20Monthly%20Adjustment%20for%20Month%20of%20April%202009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            12-05-2009</td>
                                  <td width="1048" style="text-align: justify">
                           Decision of the Authority in the Matter of Monthly 
							Adjustment of Power Purchase Price (PPP) for
                            GEPCO</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO%20Dated%2013-05-2009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            10-04-2009</td>
                                  <td width="1048" style="text-align: justify">
                           Decision of the Authority in the Matter of Monthly 
							Adjustment of Power Purchase Price (PPP) for
                            GEPCO</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO%20Dated%2010-04-2009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            06-03-2009</td>
                                  <td width="1048" style="text-align: justify">
                           Decision of the Authority in the Matter of Monthly 
							Adjustment of Power Purchase Price (PPP) for
                            GEPCO</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO%20Dated%2006-03-2008.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td width="178" style="text-align: center">
                            29-01-2009  </td>
                                  <td width="1048" style="text-align: justify">
                           Decision of the Authority in the Matter of Monthly 
							Adjustment of Power Purchase Price (PPP) for GEPCO Case No. NEPRA/TRF-102/GEPCO-2008 (3)</td>
                                  <td style="text-align: center">
                                  	<a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO%20Dated%2029-01-2009.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                                  <td width="178" style="text-align: center">
    15-01-2009</td>
                                  <td width="1048" style="text-align: justify">
   Modified 
	Decision of the Authority on Federal Government's Request for the 
	Reconsideration of Gujranwala Electric Power Company Ltd (GEPCO) Decision 
    dated 1st January, 2009 [Case No. NEPRA/TRF-102/GEPCO-2008 (3)]</td>
                                  <td style="text-align: center">
                              <a target="_blank" href="Tariff/DISCOs/GEPCO/2009/TRF-102%20GEPCO%20Modified%20Dated%2015-01-2009.PDF" class="default-btn">View</a> </td>
				</tr>
				</table>
				</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2008</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
                  <td width="178" style="text-align: center" > 
                    02-12-2008</td>
                  <td  style="text-align: justify"> 
                    Decision of the Authority in the Matter of Monthly 
					Adjustment of Power Purchase Price (PPP) for GEPCO 
                      [Case. No. NEPRA/TRF-102/GEPCO-2008 (3)]</td>
                                  <td width="98" style="text-align: center">
                              <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/TRF-102%20GEPCO%20Dated%2002-12-2008.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td width="178" style="text-align: center" > 
                    12-11-2008					</td>
                  <td  style="text-align: justify"> 
                    Notification S.R.O. 1179(1)/2008</td>
                                  <td style="text-align: center">
                                  <a target="_blank" class="default-btn" href="Tariff/DISCOs/GEPCO/2008/SRO%201179%20GEPCO%20dated%2012-11-2008.pdf">View</a> </td>
                </tr>
				<tr>
                  <td width="178" style="text-align: center" > 
                    17-09-2008 </td>
                  <td   style="text-align: justify"> 
                    Corrigendum - Determination of the Authority in the matter 
					of Petition filed by GEPCO for Consumber-end 
                      Tariff and Rates of Security Deposits [(Case No. NEPRA/TRF-102/GEPCO-2008 
                      (3)]</td>
                                  <td style="text-align: center">
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/Deteminaiton%20of%20Tariff%20of%20GEPCO%20dated%2026-06-2004.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td width="178" style="text-align: center" > 
                    09-09-2008</td>
                  <td   style="text-align: justify"> 
                    Determination 
					of Tariff in respect of Petition filed by (GEPCO) [(Case No. NEPRA/TRF-102/GEPCO-2008 (3)]</td>
                                  <td style="text-align: center">
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/TRF-102%20GEPCO%2009-09-2008.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td width="178" style="text-align: center" > 
                    23-08-2008</td>
                  <td   style="text-align: justify"> 
                    Order of the Authority in respect of Petition filed by GEPCO for Determination of the Consumer-end-tariff 
                      and Rates of Security Deposits (Case No. NEPRA/TRF-102/GEPCO-2008)</td>
                                  <td style="text-align: center">
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/Order%20of%20the%20Authority%20%20regarding%20GEPCO%20TRF-102%20dated%2022-08-2008.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td width="178" style="text-align: center" > 
                    22-08-2008</td>
                  <td   style="text-align: justify"> 
                    Decision of the Authority in the Matter of Biannual 
					Adjustment in the Consumer-end Tariff for GEPCO on 
                      account of Change in Power Purchase Price.</td>
                                  <td style="text-align: center">
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/GEPCO%2022-aug%2008.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                  <td width="178" style="text-align: center"> 
                    30-05-2008</td>
                  <td  style="text-align: justify"> 
                    Decision of the Authority on Federal Government's Request 
					for the Reconsideration of GEPCO decision dated January 10, 
                    2008 (Case No. NEPRA/TRF-36/GEPCO-2005)</td>
                                  <td style="text-align: center" >
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/TRF-36%20Decision%20of%20Request%20for%20Reconsideration%20of%20GEPCO-dated%2030-05-2008.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                  <td width="178" style="text-align: center"> 
                    01-02-2008</td>
                  <td  style="text-align: justify"> 
                    Biannual Adjustment in the Consumer-end Tariff on Account of 
					Charge in Power Purchase Price</td>
                                  <td style="text-align: center" >
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/TRF-36%2001.02.08.PDF" class="default-btn">View</a> </td>
				</tr>
				<tr>
                  <td width="178" style="text-align: center"> 
                    10-01-2008</td>
                  <td  style="text-align: justify"> 
                    NEPRA/TRF-36/GEPCO-2005 (Revised)</td>
                                  <td style="text-align: center" >
                                  <a target="_blank" href="Tariff/DISCOs/GEPCO/2008/TRF-36%20Decision%20on%20Motion%20for%20Leave%20for%20Review%20filed%20by%20GEPCO-dated%2010-01-2008.PDF" class="default-btn">View</a> </td>
				</tr>

                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2007</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2" >
                <tr>
                  <td width="178" style="text-align: center"> 
                    23-02-2007 </td>
                  <td width="1054" style="text-align: justify"> 
                    NEPRA/TRF-36/GEPCO-2005</td>
                                  <td width="96" style="text-align: center">
                              <a class="default-btn" target="_blank" href="Tariff/DISCOs/GEPCO/2004-2007/23-02-2007.pdf">View								</a></td>
                </tr>

                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header">
									<div class="accordion-icon"></div>
									<h6>2004</h6>
									
								</div>
								
								<div class="accordion-content">
									<table  border="0" align="center" cellpadding="2">
                <tr>
                  <td width="178" style="text-align: center"> 
                    22-10-2004</td>
                  <td width="1060" style="text-align: justify"> 
                    NEPRA/TRF-23/GEPCO-2003 (REVISED)</td>
                                  <td width="90" style="text-align: center">
                              
                              <a target="_blank" href="Tariff/DISCOs/GEPCO/2004-2007/Determination%20in%20respect%20of%20Review%20Motion%20filed%20by%20GEPCO-dated%2022-10-2004.PDF" class="default-btn">View</a> </td>
                </tr>
				<tr>
                  <td width="178" style="text-align: center" > 
                    28-06-2004					</td>
                  <td width="1060"  style="text-align: justify"> 
                            NEPRA/TRF-23/GEPCO-2003</td>
                                  <td style="text-align: center" >
                              
                              <a target="_blank" href="Tariff/DISCOs/GEPCO/2004-2007/Deteminaiton%20of%20Tariff%20of%20GEPCO%20dated%2026-06-2004.PDF" class="default-btn">View</a> </td>
                </tr>
                </table>
								</div>
								
							</li>
							<!-- /Accordion -->
							
						</ul>
						<!-- /Accordions -->   
															
					</div>
				
				 <div class="col-lg-3 col-md-5">
                        <div class="sidebar-area">
                           
                            <div class="widget widget_recent_posts">
                                <h3 class="widget-title">Quick Links </h3>
                                <ul>
                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution FESCO.php">
                                                <img src="../assets/img/Tariff/fesco1.jpg" height="110" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution FESCO.php">FESCO </a> </h3>  <br>
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution GEPCO.php">
                                                <img src="../assets/img/Tariff/gepco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                           <br> <h3><a href="Distribution GEPCO.php">GEPCO<br></a></h3><br>
                                            
                                        </div>
                                    </li>
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution HAZECO.php">
                                                <img src="../assets/img/Tariff/hazeco1.jpg" alt="blog-image">
                                            </a>
                                        </div>
										<div class="recent-post-content">
                                           <br> <h3><a href="Distribution HAZECO.php">HAZECO</a></h3><br>
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution HESCO.php">
                                                <img src="../assets/img/Tariff/hesco1.jpg" alt="blog-image">
                                            </a>
                                        </div>
										<div class="recent-post-content">
                                           <br> <h3><a href="Distribution HESCO.php">HESCO</a></h3><br>
                                            
                                        </div>
                                    </li>

                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution IESCO.php">
                                                <img src="../assets/img/Tariff/iesco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                           <br> <h3><a href="Distribution IESCO.php">IESCO</a></h3><br>
                                            
                                        </div>
                                    </li>
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution LESCO.php">
                                                <img src="../assets/img/Tariff/lesco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution LESCO.php">LESCO</a></h3><br>
                                           
                                        </div>
                                    </li>
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution MEPCO.php">
                                                <img src="../assets/img/Tariff/mepco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution MEPCO.php">MEPCO</a></h3>
                                            <br>
                                        </div>
                                    </li><li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution PESCO.php">
                                                <img src="../assets/img/Tariff/pesco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution PESCO.php">PESCO</a></h3>
                                            <br>
                                        </div>
                                    </li><li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution QESCO.php">
                                                <img src="../assets/img/Tariff/qesco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution QESCO.php">QESCO</a></h3>
                                            <br>
                                        </div>
                                    </li>
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution SEPCO.php">
                                                <img src="../assets/img/Tariff/sepco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution SEPCO.php">SEPCO</a></h3>
                                            <br>
                                        </div>
                                    </li>
									
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Distribution TESCO.php">
                                                <img src="../assets/img/Tariff/tesco1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Distribution TESCO.php">TESCO</a></h3>
                                            <br>
                                        </div>
                                    </li>
									
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Blogs Section -->
       
         <!-- Start Top Footer Section -->
		<!-- Start Top Footer Section -->
        <footer class="footer-top footer-top-four">
            <div class="container">
                <div class="row">
                    
					<div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Contact</h3>
                            <ul>
                               
								<li>
                                    National Electric Power Regulatory Authority
                                </li>
								<li>
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
									
                                    
                                    NEPRA Tower, G-5/1, Islamabad 
                                </li>
                                <li>
                                    <i class="flaticon-mail-black-envelope-symbol"></i>
                                    
                                    <a href="/cdn-cgi/l/email-protection#b1d8dfd7def1dfd4c1c3d09fdec3d69fc1da"><span class="__cf_email__" data-cfemail="e28b8c848da28c87929083cc8d9085cc9289">[email&#160;protected]</span></a>                                </li>
                                <li>
                                    <i class="flaticon-telephone-handle-silhouette"></i>
                                    
                                    +92 51 2013200 
                                </li>
                                <li>
                                    <i class="flaticon-call"></i>
                                    
                                    +92 51 9210215  
                                </li>
								
                            </ul>
                        </div>

                    </div>
					
                    
                    <div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Important Links</h3>
                            <ul>
                                
                                <li>
								<li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="https://www.sifc.gov.pk">SIFC</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="licensing/Licences/SOPs/Timelines flow chart check list.pdf">SOPs of Licensing</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Power Policies.php">Power Policies</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Admission%20Notices/2019/Intervention%20Request%20Form.pdf" target="_blank">Intervention Request Form</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://webmail.nepra.org.pk:2096/" target="_blank">E-mail (NEPRA Officials Only)</a>                                </li>
                                
                            </ul>
                        </div>
                    </div>
					 <div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                            <h3>Search Website</h3>
                            <div><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://cse.google.com/cse.js?cx=014945713357202780521:kaf1vdqbqiv"></script>
<div class="gcse-searchbox-only"></div></div> <br>
<a href="https://play.google.com/store/apps/details?id=com.govpk.citizensportal&hl=en"><img src="../assets/img/Pakistan Citzen Portal Banner.png" /></a>                    </div>
                    
                </div>
           
			<div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                           
<img src="../assets/img/FBR - ABI Flyer.jpg" />                  </div>
                    
                </div>
            </div>
        </footer>
        <!-- End Top Footer Section -->

        <!-- Start Bottom Footer Section -->
        <footer class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <ul>
                                <li>
                                    <p>NEPRA Copyright 2023. All Rights Reserved.</p> </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <p><i class="flaticon-clock-of-circular-shape-outline"></i> Open Hours 9:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                        <div class="single-widgets">
                            <ul class="social-links">
                                <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://mail.nepra.org.pk"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        
        <!-- End Bottom Footer Section -->		<!-- Stop  Footer Section -->
     

        <!-- Jquery-3.2.1.Slim.Mim.JS -->
       <script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/jquery.waypoints.min.js"></script>
<script src="../assets/js/owl.carousel.min.js"></script>
        <!-- Popper.Mim.JS -->
        <script src="../assets/js/popper.min.js"></script>
        <!-- Bootstrap.Mim.JS -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- Meanmenu.JS -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- Magnific.Popup.Min.JS -->
	    <script src="../assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl.Carousel.Min.JS -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- Wow.Min.JS -->
		<script src="../assets/js/wow.min.js"></script>
        <!-- Waypoints.Min.JS -->
		<script src="../assets/js/waypoints.min.js"></script>
		<!-- Jquery.Counterup.Min.JS -->
		<script src="../assets/js/jquery.counterup.min.js"></script>
		<!-- Jquery.Mixitup.Min.JS -->
		<script src="../assets/js/jquery.mixitup.min.js"></script>
        <!-- Active.JS -->
        <script src="../assets/js/active.js"></script>
		<script src="../assets/js/script.js"></script>
    </body>
</html>