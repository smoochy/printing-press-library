<!doctype html>
<html lang="zxx">
    <head>
        <!-- Required Meta Tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap.Min.CSS  -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <!-- Owl.Carousel.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- Owl.Theme.Default.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
        <!-- Animate.CSS -->
		<link rel="stylesheet" href="../assets/css/animate.css">
        <!-- Font-Awesome.Min.CSS -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
		<link rel="stylesheet" href="../assets/css/fontello.css">
        <!-- Flaticon.CSS -->
        <link rel="stylesheet" href="../assets/font/flaticon.css">
        <!-- Magnific-Popup.CSS -->
		<link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- Style.CSS -->
        <link rel="stylesheet" href="../assets/css/style.css">
        <!-- Responsive.CSS -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
        <!-- Favicon -->
        <link rel="icon" type="image/png" href="../assets/img/favicon.png">

        <!-- TITLE -->
        <title>NEPRA | Tariff Generation IPPs Short Term</title>

    </head>

    <body>

        <!-- Start Preloader Section -->
        <div class="preloader">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
        <!-- End Preloader Section -->

        <head>
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle7.css"><script>
if (window.self !== window.top) {
  window.top.location = window.self.location;
}
</script>
</head>
<!-- Start Header Section -->
         <!-- Start Header Section -->
        <header class="header header-style-one header-style-four">
           <div class="header-wrapper-one header-wrapper-four">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-3" align="right">
                            <a class="navbar-brand" href="../index.php">
                                <img src="https://nepra.org.pk/assets/img/nepra.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-8 col-md-7">
						<h2 align="center" class="header-Filing-titleArea style="color:#fff">National Electric Power Regulatory Authority</h2> <h4 align="center" class="headerSec-Filing-titleArea" style="padding-top:5px;color:#fff">Islamic Republic of Pakistan</h4> 
                        </div>
						<div class="col-lg-2 col-md-2">
                                    <div class="right-btn">
                                        <a href="" data-toggle="modal" data-target="#myModal2">
                                            <ul class="contact-info contact-info-three four">
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                            </ul>
                                        </a>
                                    </div>
                      </div>
						
                  </div>
              </div>
          </div>
            </div>
            <!-- End header-wrapper-Four -->

            <!-- Start Navbar Area -->
		    <div class="navbar-area">
                <!-- Menu For Mobile Device -->
                <div class="mobile-nav">
                    <a href="index.php" class="logo">
                        <img src="https://nepra.org.pk/assets/img/logo.png" alt="">
                    </a>
                </div>
    
                <!-- Menu For Desktop Device -->
                <div class="construction-nav-one construction-nav-four">
                    <div class="container">
                        <nav class="navbar navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/index.php" class="nav-link">Home</a> </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">About Us</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/About.php">About NEPRA</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Authority.php">The Authority</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Management.php">Sr. Management</a>                                            </li>
											
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/careers.php">Careers</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/tenders.php">Tenders</a>                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Legal.php" class="nav-link">Legal</a>									</li>
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Licences</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Concurrences.php">Concurrences</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation GENCOs.php">GENCOs</a>  </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation K-Electric.php">K-Electric</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IPPs.php">IPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Netmetering.php">Net-Metering</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IGCs.php">IGCs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation SPPs.php">SPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation CPPs.php">CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NCPPs.php">N-CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NPPs.php">NPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation WAPDA Hydel.php">WAPDA Hydel</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Distributed Generation.php">Distributed Generation</a>                                                    </li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Transmission.php">Transmission</a>                                          </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Industrial Estates.php">Industrial Estates</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution CPPs.php">CPPs</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution SPPs.php">SPPs</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Independent System and Market Operator.php" class="nav-link">ISMO</a>   
								            </li>
											 
											 <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Electric Power Suppliers</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Suppliers of Last Resort.php">Suppliers of Last Resort</a>                                                    </li>
                                                    
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Special Purpose Agent.php">Special Purpose Agent</a>
								             </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/elicensing" class="nav-link">e-Licensing</a>   
								             </li>  
											  
											   
                                        </ul>
                                    </li> 
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Tariff</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation K-Electric.php">K-Electric</a></li>
                                                        <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation GENCOs.php">GENCOs</a></li>

                                                   <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation WAPDA Hydroelectric.php">WAPDA Hydroelectric</a></li>
												    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation IPPs.php">IPPs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Upfront.php">UP-front</a></li>
													
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Benchmark.php">Benchmark</a></li>
													
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation CPPs.php">CPPs</a></li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Transmission</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission NTDC.php">NTDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission HVDC.php">HVDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission STDCPL.php">ST&DCPL</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution WAPDA.php">WAPDA</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Market Operators.php" class="nav-link">Market Operators</a>                                          </li> 
											 <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Petitions.php" class="nav-link">Petitions</a>                                             </li>      
                                        </ul>
                                    </li>   
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Consumer Affairs</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" target="_blank" href="https://nepra.org.pk/consumer affairs/cad/NEPRA Asaan Approach1.jpg">NEPRA Asaan Approach</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/cregister.php">Register Complaint</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/tcomplaint.php">Track a Complaint</a>                                            </li>
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Authority Decisions.php">Authority Decisions</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Appellate Board.php">Appellate Board</a>                                            </li>
											
											
												<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Understand Your Electricity Bill.php">Understand Electricity Bill</a>                                            </li>
                                        </ul>
                                    </li>
                                   
                                    
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">M & E</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/M&E/Orders%20of%20the%20Authority.php">Orders of the Authority</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/dxp/">Data Exchange Portal</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Performance%20Reports.php">Performance Evaluation Reports</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Inquiry%20Reports.php">Inquiry Reports</a> </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Publications</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Annual Reports.php">Annual Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/State of Industry Reports.php">State of Industry Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/News Letters.php">News Letters</a></li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Performance Reports.php">Performance Reports</a></li>
                                        </ul>
                                    </li>
									
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/news.php" class="nav-link">News</a>                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Suggestions</a>
                                        <ul class="dropdown-menu">
                                           
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Suggestion Box.php">NEPRA Employees Only</a></li>
                                        </ul>
                                    </li>
									
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Contact.php" class="nav-link">contact</a>                                    </li>
                                     
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div><!-- End Navbar Area -->
        </header> 
		<!-- End Header Section -->

        <!-- Start Sidebar Modal -->
		<div class="sidebar-modal">  
            <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="flaticon-close-cross"></i></span></button>

                            <h2 class="modal-title" id="myModalLabel2"><a href="index.php"><img src="https://nepra.org.pk/assets/img/logo.png" alt="logo"></a></h2>
                        </div>

                        <div class="modal-body">
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Additional Links</h3>

                                <ul>
                                    <li><a href="https://nepra.org.pk/energyweek.php">NEPRA Energy Week</a></li>
									<li><a href="https://nepra.org.pk/Media%20Gallery.php">Media Gallery</a></li>
									<li><a href="https://nepra.org.pk/Power Policies.php">Power Policies</a></li>
                                    
                                    <li><a href="https://nepra.org.pk/consumer affairs/Electricity Bill.php">Applicable Tariff</a></li>
                                    <li><a href="https://webmail.nepra.org.pk:2096/">E-mail (NEPRA Officials Only)</a></li>
                                </ul>
                            </div>
                            
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Contact Info</h3>

                                <ul class="contact-info">
                                    <li>
                                        <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
                                        Address
                                        <span>NEPRA Tower G-5/1, Islamabad, Pakistan</span>
                                    </li>
                                    <li>
                                        <i class="flaticon-close-envelope"></i>
                                        Email
                                        <span><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="761f1810193618130604175819041158061d">[email&#160;protected]</a></span>
                                    </li>
                                    <li>
                                        <i class="flaticon-telephone-handle-silhouette"></i>
                                        Phone
                                        <span>+92 51 2013200</span>
                                    </li>
									<li>
                                        <i class="flaticon-call"></i>
                                        Fax
                                        <span>+92 51 9210215</span>
                                    </li>
                                </ul>
                            </div>

                            <div class="sidebar-modal-widget">
                                <h3 class="title">Connect With Us</h3>

                                <ul class="social-list">
                                    <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://webmail.nepra.org.pk/"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
        </div>
        <div align="justify">
          <!-- End Sidebar Modal -->        <!-- End Header Section -->

        <!-- Start Page Banner Section -->
        <section class="banner-section nepra-tariff-ipps-shortterm">
            <div class="d-table">
                <div class="d-tablecell">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title page-title-one">
                                    <h2><span> IPPs</span> Short Term</h2>
                                    <ul>
                                        <li><a href="../index.php">home <i class="flaticon-right"></i></a><a href="Generation IPPs.php">IPPs <i class="flaticon-right"></i> </a></li><li>Short Term</li>
                                    </ul>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        </section>
        <!-- End Page Banner Section -->

        <!-- Start Blogs Section -->
         <section class="team-man-section team-man-section-two ptb-100">
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-9 col-md-6 col-sm-6">
                        
									<!-- Accordions -->
						<ul class="accordions toggles">
								
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6>Gulf Powergen (Private) Limited (GPPL)</h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									
									08-08-2017</td>
                                  <td width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment. for Gulf Powergen 
							Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Gulf%20Powergen%20(Private)%20Limited%20(GPPL)/TRF-365%20GPPL%20FPA%20MAY-2017%2008-08-2017%2013740-44.PDF" class="default-btn">view</a> </td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									
									22-08-2017</td>
                                  <td width="687" style="text-align: justify">
                            Decision 
							of the Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Gulf Powergen 
							Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Gulf%20Powergen%20(Private)%20Limited%20(GPPL)/TRF-356%20GPPL%20QTR%2022-08-2017%2014407-09.PDF" class="default-btn">view</a> </td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									
									08-08-2017</td>
                                  <td width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment. for Gulf Powergen 
							Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Gulf%20Powergen%20(Private)%20Limited%20(GPPL)/TRF-365%20GPPL%20FPA%20MAY-2017%2008-08-2017%2013740-44.PDF" class="default-btn">view</a> </td>
        		</tr>
				<tr>
            
                                  <td width="74" style="text-align: center" > 
									
									08-08-2017</td>
                                  <td width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment. for Gulf Powergen 
							Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Gulf%20Powergen%20(Private)%20Limited%20(GPPL)/TRF-365%20GPPL%20FPA%20JUNE-2017%2008-08-2017%2013734-38.PDF" class="default-btn">view</a> </td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									
									12-07-2017</td>
                                  <td width="687" style="text-align: justify">
                            Decision 
							of the Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Gulf Powergen 
							Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Gulf%20Powergen%20(Private)%20Limited%20(GPPL)/TRF-356%20GPPL%20QTR%20APRIL-JUNE%202017%2012082-84%2012-07-2017.PDF" class="default-btn">view</a> </td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center"  > 
									
									09-06-2016</td>
                                  <td   width="687" style="text-align: justify">
                            Approval 
							of National Electric Power Regulatory Authority in 
							the matter of Application of Gulf Powergen (Private) 
							Limited (GPPL) for Unconditional Acceptance of 
							Upfront Tariff for Utilization of Existing Available 
							Capacity Short-Term Independent Power Producers
							</td>
                  <td  > 

                     
                      <a target="_blank" href="Tariff/IPPs/Gulf%20Powergen%20(Private)%20Limited%20(GPPL)/TRF-356%20GPPL%20UPFRONT%20TARIFF%2009-06-2016%208638-40.PDF"class="default-btn">View
						</a></td>
        		</tr>
																		
								</table>
																	 
								</div>
								
							</li>
							<!-- /Accordion -->
							<!-- Accordion -->
							<li class="accordion">
								
								<div class="accordion-header" >
									<div class="accordion-icon"></div>
									<h6>Reshma Power Generation (Private) Limited (RPGPL)</h6>
									
								</div>
								
								<div class="accordion-content">
									 
								<table border="1" width="100%">
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									26-02-2020</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma
							Power Generation Private Ltd</td>
                  <td > 

                     
                      <a target="_blank" class="default-btn" href="Tariff/IPPs/Reshma%20Power/2020/TRF-321%20RPGPL%20FPA%20Jan%202020%2026-02-2020%206701-05.PDF">view</a></td>
        							</tr>
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									13-02-2020</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Reshma Power 
							Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" class="default-btn" href="Tariff/IPPs/Reshma%20Power/2020/TRF-321%20RPGPL%20QTR%20Jan-Mar%202020%2013-02-2020%205218-20.PDF">view</a></td>
        							</tr>
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									25-09-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma
							Power Generation Private Ltd</td>
                  <td > 

                     
                      <a target="_blank" class="default-btn" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20Rashma%2025-09-2019.pdf">view</a></td>
        			</tr>
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									18-09-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Reshma Power 
							Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" class="default-btn" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20QTR%20Jul-Sep%202019%2018-09-2019%2016971-73.PDF">view</a></td>
        			</tr>
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									17-09-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma Power Generation Private 
							Ltd</td>
                  <td > 

                     
                      <a target="_blank" class="default-btn" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20FPA%20Aug%202019%2017-09-2019%2016826-30.PDF">view</a></td>
        			</tr>
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									12-09-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma Power Generation Private 
							Ltd</td>
                  <td > 

                     
                      <a target="_blank" class="default-btn" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20FPA%20Jun%202019%2012-09-2019%2016366-70.PDF">view</a></td>
        			</tr>
									<tr>
            
                                  <td width="99" style="text-align: center" > 
									24-06-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20FPA%20May%202019%2024-06-2019%2011020-24.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									30-04-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in 
							the matter of Quarterly Indexation/Adjustment of 
							Tariff for Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20QTR%20Apr-Jun%202019%2030-04-2019%207538-40.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									19-02-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20FPA%20Jan%202019%2019-02-2019%202815-19.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									23-01-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20FPA%202018%20Dec%202018%2023-01-2019%201190-94.PDF" class="default-btn">view</a> </td>
        			</tr>
				<tr>
            
                                  <td width="74" style="text-align: center" > 
									23-01-2019</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in 
							the matter of Quarterly Indexation/Adjustment of 
							Tariff for Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2019/TRF-321%20RPGPL%20QTR%20Jan-Mar%202019%2023-01-2019%201103-05.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									16-11-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Oct%202018%2016-11-2018%2017869-73.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									25-10-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in 
							the matter of Quarterly Indexation/Adjustment of 
							Tariff for Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20QTR%20Oct-Dec%202018%2025-10-2018%2016453-55.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									
									11-10-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Sep%202018%2011-10-2018%2015639-43.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									10-09-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Aug%202018%2010-09-2018%2014486-90.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									13-08-2018</td>
                                  <td  width="687" style="text-align: justify">
							Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma Power Generation Private 
							Ltd</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20July%202018%2013-08-2018%2012903-07.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									
									20-07-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in 
							the matter of Quarterly Indexation/Adjustment of 
							Tariff for Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20QTR%20Jul-Sep%202018%2020-07-2018%2011824-26.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									09-07-2018</td>
                                  <td  width="687" style="text-align: justify">
							Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma Power Generation Private 
							Ltd</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20June%202018%2009-07-2018%2010728-32.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									14-06-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20May%202018%2014-06-2018%209306-10.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									16-05-2018</td>
                                  <td  width="687" style="text-align: justify">
							Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma Power Generation Private 
							Ltd</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Apr%202018%2016-05-2018%207746-50.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									
									18-04-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in 
							the matter of Quarterly Indexation/Adjustment of 
							Tariff for Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20QTR%20Apr-Jun%2018%2018-04-2018%206397-99.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									12-04-2018</td>
                                  <td  width="687" style="text-align: justify">
							Decision of the Authority in the matter of Fuel 
							Price Adjustment for Reshma Power Generation Private 
							Ltd</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Mar%2018%2012-04-2018%205677-81.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									30-03-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Feb%202018%2030-03-2018%205311-15.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									14-02-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Jan%2018%2014-02-2018%202365-69.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									23-01-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20QTR%20Jan-Mar%202018%2023-01-2018%201116-18.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									15-01-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Fuel Price Adjustment for 
							Reshma Power Generation Private Ltd.</td>
                  <td > 

                     
                      <a href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%20Dec%2017%2015-01-2018%20585-89.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									01-01-2018</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/2018/TRF-321%20RPGPL%20FPA%20Dec%2017%2015-01-2018%20585-89.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									08-11-2017</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%2018362-66%2008-11-2017.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									19-10-2017</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Reshma Power 
							Generation Private Ltd</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20QTR%20Oct-Dec%202017%2019-10-2017%2017272-74.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									13-10-2017</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%20Sep-2017%2013-10-2017%2016954-58.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center"  > 
									
									25-09-2017</td>
                                  <td   width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td  > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%20Aug-2017%2025-09-2017%2016001-05.PDF"class="default-btn">View
						</a></td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									15-08-2017</td>
                                  <td  width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Reshma Power 
							Generation Private Ltd</td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%20QTR%20JULY%20SEP%202017%2015-08-2017%2013996-13998.PDF" class="default-btn">view</a> </td>
        			</tr>
                <tr>
            
                                  <td width="74" style="text-align: center"  > 
									
									08-08-2017</td>
                                  <td   width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td  > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20JULY-2017%2008-08-2017%2013725-29.PDF"class="default-btn">View
						</a></td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center" > 
									03-08-2017</td>
                                  <td  width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%20JUNE-2017%2003-08-2017%2013547-51.PDF" class="default-btn">view</a> </td>
        		</tr>
				<tr>
            
                                  <td width="74" style="text-align: center"  > 
									
									03-08-2017</td>
                                  <td   width="687" style="text-align: justify">
							Decision of the Authority in the 
							matter of Fuel Price Adjustment for Reshma Power 
							Generation Private Ltd. </td>
                  <td  > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20FPA%20MAY-2017%2003-08-2017%2013541-45.PDF"class="default-btn">View
						</a></td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center"  > 
									12-07-2017</td>
                                  <td   width="687" style="text-align: justify">
                            Decision of the 
							Authority in the matter of Quarterly 
							Indexation/Adjustment of Tariff for Reshma Power 
							Generation Private Ltd</td>
                  <td  > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/TRF-321%20RPGPL%20QTR%20APRIL-JUNE%202017%2012076-78%2012-07-2017.PDF" class="default-btn">view</a> </td>
        		</tr>
                <tr>
            
                                  <td width="74" style="text-align: center"  > 
									
									04-02-2016</td>
                                  <td   width="687" style="text-align: justify">
                            Approval of National 
							Electric Power Regulatory Authority in the matter of 
							Application of <span style="font-weight: 400">Reshma Power Generation (Private) 
							Limited (RPGPL)</span> for Unconditional Acceptance of 
							Upfront Tariff for Utilization of Existing Available 
							Capacity Short-Term Independent Power Producers</td>
                  <td  > 

                     
                      <a target="_blank" href="Tariff/IPPs/Reshma%20Power/Decision%20of%20the%20authority%20in%20matter%20of%20reshma%20Power.PDF"class="default-btn">View
						</a></td>
        		</tr>

									</table>
								
									 
								</div>
								
												
							
							</li>
							<!-- /Accordion -->
							
						</ul>
						<!-- /Accordions -->						
					</div>               
				<div class="col-lg-3 col-md-5">
                        <div class="sidebar-area">
                           
                            <div class="widget widget_recent_posts">
                                <h3 class="widget-title">Quick Links </h3>
                                <ul>
                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Thermal.php">
                                                <img src="../assets/img/Tariff/thermal1.jpg" height="110" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Generation IPPs Thermal.php">Thermal </a> </h3>  <br>
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Hydel.php">
                                                <img src="../assets/img/Tariff/hydel1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                           <br> <h3><a href="Generation IPPs Hydel.php">Hydel<br></a></h3><br>
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Wind.php">
                                                <img src="../assets/img/Tariff/wind1.jpg" alt="blog-image">
                                            </a>
                                        </div>
										<div class="recent-post-content">
                                           <br> <h3><a href="Generation IPPs Wind.php">Wind<br></a></h3><br>
                                            
                                        </div>
                                    </li>

                                    <li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Solar.php">
                                                <img src="../assets/img/Tariff/solar1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                           <br> <h3><a href="Generation IPPs Solar.php">Solar</a></h3><br>
                                            
                                        </div>
                                    </li>
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Coal.php">
                                                <img src="../assets/img/Tariff/coal1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Generation IPPs Coal.php">Coal</a></h3><br>
                                           
                                        </div>
                                    </li>
									<li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Bio Energy.php">
                                                <img src="../assets/img/Tariff/bioenergy1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Generation IPPs Bio Energy.php">Bio Energy</a></h3>
                                            <br>
                                        </div>
                                    </li><li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Waste to Energy.php">
                                                <img src="../assets/img/Tariff/waste1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Generation IPPs Waste to Energy.php">Waste to Energy</a></h3>
                                            <br>
                                        </div>
                                    </li><li>
                                        <div class="recent-post-thumb">
                                            <a href="Generation IPPs Short Term.php">
                                                <img src="../assets/img/Tariff/shortterm1.jpg" alt="blog-image">
                                            </a>
                                        </div>

                                        <div class="recent-post-content">
                                            <br><h3><a href="Generation IPPs Short Term.php">Short Term</a></h3>
                                            <br>
                                        </div>
                                    </li>
									
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Contents Section -->
       
         <!-- Start Top Footer Section -->
		<!-- Start Top Footer Section -->
        <footer class="footer-top footer-top-four">
            <div class="container">
                <div class="row">
                    
					<div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Contact</h3>
                            <ul>
                               
								<li>
                                    National Electric Power Regulatory Authority
                                </li>
								<li>
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
									
                                    
                                    NEPRA Tower, G-5/1, Islamabad 
                                </li>
                                <li>
                                    <i class="flaticon-mail-black-envelope-symbol"></i>
                                    
                                    <a href="/cdn-cgi/l/email-protection#e28b8c848da28c87929083cc8d9085cc9289"><span class="__cf_email__" data-cfemail="056c6b636a456b607577642b6a77622b756e">[email&#160;protected]</span></a>                                </li>
                                <li>
                                    <i class="flaticon-telephone-handle-silhouette"></i>
                                    
                                    +92 51 2013200 
                                </li>
                                <li>
                                    <i class="flaticon-call"></i>
                                    
                                    +92 51 9210215  
                                </li>
								
                            </ul>
                        </div>

                    </div>
					
                    
                    <div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Important Links</h3>
                            <ul>
                                
                                <li>
								<li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="https://www.sifc.gov.pk">SIFC</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="licensing/Licences/SOPs/Timelines flow chart check list.pdf">SOPs of Licensing</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Power Policies.php">Power Policies</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Admission%20Notices/2019/Intervention%20Request%20Form.pdf" target="_blank">Intervention Request Form</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://webmail.nepra.org.pk:2096/" target="_blank">E-mail (NEPRA Officials Only)</a>                                </li>
                                
                            </ul>
                        </div>
                    </div>
					 <div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                            <h3>Search Website</h3>
                            <div><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://cse.google.com/cse.js?cx=014945713357202780521:kaf1vdqbqiv"></script>
<div class="gcse-searchbox-only"></div></div> <br>
<a href="https://play.google.com/store/apps/details?id=com.govpk.citizensportal&hl=en"><img src="../assets/img/Pakistan Citzen Portal Banner.png" /></a>                    </div>
                    
                </div>
           
			<div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                           
<img src="../assets/img/FBR - ABI Flyer.jpg" />                  </div>
                    
                </div>
            </div>
        </footer>
        <!-- End Top Footer Section -->

        <!-- Start Bottom Footer Section -->
        <footer class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <ul>
                                <li>
                                    <p>NEPRA Copyright 2023. All Rights Reserved.</p> </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <p><i class="flaticon-clock-of-circular-shape-outline"></i> Open Hours 9:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                        <div class="single-widgets">
                            <ul class="social-links">
                                <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://mail.nepra.org.pk"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        
        <!-- End Bottom Footer Section -->		<!-- Stop  Footer Section -->
     

        <!-- Jquery-3.2.1.Slim.Mim.JS -->
       <script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/jquery.waypoints.min.js"></script>
<script src="../assets/js/owl.carousel.min.js"></script>
        <!-- Popper.Mim.JS -->
        <script src="../assets/js/popper.min.js"></script>
        <!-- Bootstrap.Mim.JS -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- Meanmenu.JS -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- Magnific.Popup.Min.JS -->
	    <script src="../assets/js/jquery.magnific-popup.min.js"></script>
        <!-- Owl.Carousel.Min.JS -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- Wow.Min.JS -->
		<script src="../assets/js/wow.min.js"></script>
        <!-- Waypoints.Min.JS -->
		<script src="../assets/js/waypoints.min.js"></script>
		<!-- Jquery.Counterup.Min.JS -->
		<script src="../assets/js/jquery.counterup.min.js"></script>
		<!-- Jquery.Mixitup.Min.JS -->
		<script src="../assets/js/jquery.mixitup.min.js"></script>
        <!-- Active.JS -->
        <script src="../assets/js/active.js"></script>
		<script src="../assets/js/script.js"></script>
    </body>
</html>