<!doctype html>

<html lang="zxx">

    <head>

        <!-- Required Meta Tags -->

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



        <!-- Bootstrap.Min.CSS  -->

        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

        <!-- Owl.Carousel.Min.CSS -->

        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">

        <!-- Owl.Theme.Default.Min.CSS -->

        <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">

        <!-- Animate.CSS -->

		<link rel="stylesheet" href="../assets/css/animate.css">

        <!-- Font-Awesome.Min.CSS -->

        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">

		<link rel="stylesheet" href="../assets/css/fontello.css">

        <!-- Flaticon.CSS -->

        <link rel="stylesheet" href="../assets/font/flaticon.css">

        <!-- Magnific-Popup.CSS -->

		<link rel="stylesheet" href="../assets/css/magnific-popup.css">

        <!-- Style.CSS -->

        <link rel="stylesheet" href="../assets/css/style.css">

        <!-- Responsive.CSS -->

        <link rel="stylesheet" href="../assets/css/responsive.css">

        <!-- Favicon -->

        <link rel="icon" type="image/png" href="../assets/img/favicon.png">



        <!-- TITLE -->

        <title>NEPRA | Licences Generation IPPs 1994</title>



    </head>



    <body>



        <!-- Start Preloader Section -->

        <div class="preloader">

            <div class="spinner">

                <div class="rect1"></div>

                <div class="rect2"></div>

                <div class="rect3"></div>

                <div class="rect4"></div>

                <div class="rect5"></div>

            </div>

        </div>

        <!-- End Preloader Section -->



        <head>
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle.css">
<link rel="stylesheet" href="../assets/css/newEnhanceStyle7.css"><script>
if (window.self !== window.top) {
  window.top.location = window.self.location;
}
</script>
</head>
<!-- Start Header Section -->
         <!-- Start Header Section -->
        <header class="header header-style-one header-style-four">
           <div class="header-wrapper-one header-wrapper-four">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-3" align="right">
                            <a class="navbar-brand" href="../index.php">
                                <img src="https://nepra.org.pk/assets/img/nepra.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-8 col-md-7">
						<h2 align="center" class="header-Filing-titleArea style="color:#fff">National Electric Power Regulatory Authority</h2> <h4 align="center" class="headerSec-Filing-titleArea" style="padding-top:5px;color:#fff">Islamic Republic of Pakistan</h4> 
                        </div>
						<div class="col-lg-2 col-md-2">
                                    <div class="right-btn">
                                        <a href="" data-toggle="modal" data-target="#myModal2">
                                            <ul class="contact-info contact-info-three four">
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                                <li><span></span></li>
                                            </ul>
                                        </a>
                                    </div>
                      </div>
						
                  </div>
              </div>
          </div>
            </div>
            <!-- End header-wrapper-Four -->

            <!-- Start Navbar Area -->
		    <div class="navbar-area">
                <!-- Menu For Mobile Device -->
                <div class="mobile-nav">
                    <a href="index.php" class="logo">
                        <img src="https://nepra.org.pk/assets/img/logo.png" alt="">
                    </a>
                </div>
    
                <!-- Menu For Desktop Device -->
                <div class="construction-nav-one construction-nav-four">
                    <div class="container">
                        <nav class="navbar navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                                <ul class="navbar-nav ml-auto">
                                    
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/index.php" class="nav-link">Home</a> </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">About Us</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/About.php">About NEPRA</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Authority.php">The Authority</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Management.php">Sr. Management</a>                                            </li>
											
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/careers.php">Careers</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/tenders.php">Tenders</a>                                            </li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Legal.php" class="nav-link">Legal</a>									</li>
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Licences</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Concurrences.php">Concurrences</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation GENCOs.php">GENCOs</a>  </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation K-Electric.php">K-Electric</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IPPs.php">IPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Netmetering.php">Net-Metering</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation IGCs.php">IGCs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation SPPs.php">SPPs</a> </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation CPPs.php">CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NCPPs.php">N-CPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation NPPs.php">NPPs</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation WAPDA Hydel.php">WAPDA Hydel</a>                                                    </li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Generation Distributed Generation.php">Distributed Generation</a>                                                    </li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Transmission.php">Transmission</a>                                          </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution Industrial Estates.php">Industrial Estates</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution CPPs.php">CPPs</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Distribution SPPs.php">SPPs</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Independent System and Market Operator.php" class="nav-link">ISMO</a>   
								            </li>
											 
											 <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Electric Power Suppliers</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/licensing/Suppliers of Last Resort.php">Suppliers of Last Resort</a>                                                    </li>
                                                    
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/licensing/Special Purpose Agent.php">Special Purpose Agent</a>
								             </li>
											<li class="nav-item">
                                                <a href="https://nepra.org.pk/elicensing" class="nav-link">e-Licensing</a>   
								             </li>  
											  
											   
                                        </ul>
                                    </li> 
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Tariff</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Generation</a>
                                                <ul class="dropdown-menu">
                                                    
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation K-Electric.php">K-Electric</a></li>
                                                        <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation GENCOs.php">GENCOs</a></li>

                                                   <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation WAPDA Hydroelectric.php">WAPDA Hydroelectric</a></li>
												    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation IPPs.php">IPPs</a></li>
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Upfront.php">UP-front</a></li>
													
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation Benchmark.php">Benchmark</a></li>
													
													<li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Generation CPPs.php">CPPs</a></li>
                                                </ul>
                                            </li>
											<li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Transmission</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission NTDC.php">NTDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission HVDC.php">HVDC</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Transmission STDCPL.php">ST&DCPL</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" class="nav-link dropdown-toggle">Distribution</a>
                                                <ul class="dropdown-menu">
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution XWDISCOs.php">XW-DISCOs</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution K-Electric.php">K-Electric</a>                                                    </li>
                                                    <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution Housing Colonies.php">Housing Colonies</a>                                                    </li>
													 <li class="nav-item">
                                                        <a class="dropdown-item" href="https://nepra.org.pk/tariff/Distribution WAPDA.php">WAPDA</a>                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Market Operators.php" class="nav-link">Market Operators</a>                                          </li> 
											 <li class="nav-item">
                                                <a href="https://nepra.org.pk/tariff/Petitions.php" class="nav-link">Petitions</a>                                             </li>      
                                        </ul>
                                    </li>   
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Consumer Affairs</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" target="_blank" href="https://nepra.org.pk/consumer affairs/cad/NEPRA Asaan Approach1.jpg">NEPRA Asaan Approach</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/cregister.php">Register Complaint</a>                                            </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/CAD-Database/CMS-CAD/tcomplaint.php">Track a Complaint</a>                                            </li>
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Authority Decisions.php">Authority Decisions</a>                                            </li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Appellate Board.php">Appellate Board</a>                                            </li>
											
											
												<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/consumer affairs/Understand Your Electricity Bill.php">Understand Electricity Bill</a>                                            </li>
                                        </ul>
                                    </li>
                                   
                                    
									<li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">M & E</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/M&E/Orders%20of%20the%20Authority.php">Orders of the Authority</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/dxp/">Data Exchange Portal</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Performance%20Reports.php">Performance Evaluation Reports</a> </li>
												<li class="nav-item">
												<a class="dropdown-item" href="https://nepra.org.pk/publications/Inquiry%20Reports.php">Inquiry Reports</a> </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Publications</a>
                                        <ul class="dropdown-menu">
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Annual Reports.php">Annual Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/State of Industry Reports.php">State of Industry Reports</a> </li>
                                            <li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/News Letters.php">News Letters</a></li>
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/publications/Performance Reports.php">Performance Reports</a></li>
                                        </ul>
                                    </li>
									
									<li class="nav-item">
                                        <a href="https://nepra.org.pk/news.php" class="nav-link">News</a>                                    </li>
                                    <li class="nav-item">
                                        <a href="#" class="nav-link dropdown-toggle">Suggestions</a>
                                        <ul class="dropdown-menu">
                                           
                                            
											<li class="nav-item">
                                                <a class="dropdown-item" href="https://nepra.org.pk/Suggestion Box.php">NEPRA Employees Only</a></li>
                                        </ul>
                                    </li>
									
                                    <li class="nav-item">
                                        <a href="https://nepra.org.pk/Contact.php" class="nav-link">contact</a>                                    </li>
                                     
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div><!-- End Navbar Area -->
        </header> 
		<!-- End Header Section -->

        <!-- Start Sidebar Modal -->
		<div class="sidebar-modal">  
            <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="flaticon-close-cross"></i></span></button>

                            <h2 class="modal-title" id="myModalLabel2"><a href="index.php"><img src="https://nepra.org.pk/assets/img/logo.png" alt="logo"></a></h2>
                        </div>

                        <div class="modal-body">
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Additional Links</h3>

                                <ul>
                                    <li><a href="https://nepra.org.pk/energyweek.php">NEPRA Energy Week</a></li>
									<li><a href="https://nepra.org.pk/Media%20Gallery.php">Media Gallery</a></li>
									<li><a href="https://nepra.org.pk/Power Policies.php">Power Policies</a></li>
                                    
                                    <li><a href="https://nepra.org.pk/consumer affairs/Electricity Bill.php">Applicable Tariff</a></li>
                                    <li><a href="https://webmail.nepra.org.pk:2096/">E-mail (NEPRA Officials Only)</a></li>
                                </ul>
                            </div>
                            
                            <div class="sidebar-modal-widget">
                                <h3 class="title">Contact Info</h3>

                                <ul class="contact-info">
                                    <li>
                                        <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
                                        Address
                                        <span>NEPRA Tower G-5/1, Islamabad, Pakistan</span>
                                    </li>
                                    <li>
                                        <i class="flaticon-close-envelope"></i>
                                        Email
                                        <span><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="2c45424a436c42495c5e4d02435e4b025c47">[email&#160;protected]</a></span>
                                    </li>
                                    <li>
                                        <i class="flaticon-telephone-handle-silhouette"></i>
                                        Phone
                                        <span>+92 51 2013200</span>
                                    </li>
									<li>
                                        <i class="flaticon-call"></i>
                                        Fax
                                        <span>+92 51 9210215</span>
                                    </li>
                                </ul>
                            </div>

                            <div class="sidebar-modal-widget">
                                <h3 class="title">Connect With Us</h3>

                                <ul class="social-list">
                                    <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://webmail.nepra.org.pk/"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- modal-content -->
                </div><!-- modal-dialog -->
            </div><!-- modal -->
        </div>
        <div align="justify">
          <!-- End Sidebar Modal -->
        <!-- End Header Section -->



        <!-- Start Page Banner Section -->

        <section class="banner-section nepra-lic-ipps-1994">

            <div class="d-table">

                <div class="d-tablecell">

                    <div class="container">

                        <div class="row">

                            <div class="col-12">

                                <div class="page-title page-title-one">

                                    <h2>IPPs<span> Setup under Power Policy 1994</span></h2>

                                    <ul>

                                        <li><a href="../index.php">home <i class="flaticon-right"></i> </a></li><li><a href="Generation IPPs.php">IPPs <i class="flaticon-right"></i> </a></li>

                                        <li>IPPs 1994</li>

                                    </ul>   

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div> 

        </section>

        <!-- End Page Banner Section -->



        <!-- Start Blogs Section -->

         <section class="team-man-section team-man-section-two ptb-100">

            <div class="container">

                <div class="row">

                   

                    <div class="col-lg-9 col-md-6 col-sm-6">

                        

						<!-- Accordions -->

						<ul class="accordions toggles">

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>AES Lal Pir (Pvt.) Ltd</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="116"  >  

                      						Plant Detail</td>

                  <td width="370"   style="text-align: center">

                            

                            1 

                            x 362 MW S.T.</td>

                </tr>

                <tr > 

                  <td width="116"  >  

                      Plant Type</td>

                  <td width="370"   style="text-align: center"> 

                   &nbsp;Thermal 

					(Combined 

                      Cycle)</td>

                </tr>

                <tr > 

                  <td width="116" >  

                      Gross Capacity</td>

                  <td width="370"  style="text-align: center"> 

                            

                            362 MW</td>

                </tr>

                <tr > 

                  <td width="116"  >  

                      Fuel Type</td>

                  <td width="370"   style="text-align: center"> 

                            

                            RFO</td>

                </tr>

                <tr > 

                  <td width="116" >  

                      Licence No. </td>

                  <td width="370"  style="text-align: center"> 

                            

                            IPGL/06/2003</td>

                </tr>

                <tr > 

                  <td width="116"  >  

                      Licence 

                      Details</td>

                  <td width="370"   style="text-align: center"> 

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-07%20AES%20Lal%20Pir%20Pvt%20Ltd/LAG-07%20Generation%20Licen%20AES%20Lal%20Pir%20Pvt%20Ltd%20-dated%2030-08-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>



								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

							

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>AES PakGen (Pvt.) Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="116"  ><div align="left">

                    Plant Detail</div></td>

                  <td   style="text-align: center"><div align="center">

                    9 

                      x 17.0305 MW D.G. + 1 x 12.01 MW S.T.</div></td>

                </tr>

                <tr > 

                  <td width="116"  ><div align="left">

                    Plant 

                      Type</div></td>

                  <td   style="text-align: center">

                    Combined 

                      Cycle </td>

                </tr>

                <tr > 

                  <td width="116"  ><div align="left">

                    Gross 

                      Capacity</div></td>

                  <td   style="text-align: center">

                    365 

                      MW</td>

                </tr>

                <tr > 

                  <td width="116"  ><div align="left">

                    Fuel 

                      Type</div></td>

                  <td   style="text-align: center"><div align="center">

                    RFO</div></td>

                </tr>

                <tr > 

                  <td width="116"  ><div align="left">

                    Licence 

                      No. </div></td>

                  <td   style="text-align: center"><div align="center">

                    IPGL/07/2003</div></td>

                </tr>

                <tr > 

                  <td width="116"  ><div align="left">

                    Licence 

                      Details</div></td>

                  <td   style="text-align: center"> 

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-08%20AES%20Pak%20Gen/LAG-08%20Gen%20Licen%20AES%20Pak%20Gen-dated%2030-08-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Altern Energy Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

								 <tr > 

                  <td width="116"  > 

                  Plant 

                      Detail</td>

                  <td width="370"  style="text-align: center"> 

                   

                      3 

                      x 3.5 MW Gas Engines (G.E.)</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Plant 

                      Type</td>

                  <td width="370"  style="text-align: center"> 

                   

                      Thermal (Simple Cycle)</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Gross 

                      Capacity</td>

                  <td width="370"  style="text-align: center"> 

                   

                    10.5 MW</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Fuel 

                      Type</td>

                  <td width="370"  style="text-align: center"> 

                   

                      Flare Gas</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Licence 

                      No. </td>

                  <td width="370"  style="text-align: center"> 

                   

                      IPGL/21/2004</td>

                </tr>

                					<tr>

                  <td width="116"  > 

                  Licence 

                      Details</td>

                  <td width="370"  style="text-align: center"> 

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-21%20Altern%20Energy%20Ltd/LAG-21%20Generation%20Licen%20Altern%20Energy%20Ltd-dated%2022-09-2004.PDF" class="default-btn">View</a></td>

                					</tr>

                <tr > 

                  <td width="116"  > 

                  Licence Modification</td>

                  <td width="370"  style="text-align: center"> 

                   

						<a target="_blank" class="default-btn" href="Licences/Generation/IPPs%201994/LAG-21%20Altern%20Energy%20Ltd/LAG-21%20RENEWAL%20OF%20GENERATION%20LICENCE%20ALTERN%20ENERGY.PDF">View</a></td>

                </tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Davis Energen private Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									<tr > 

                  <td width="116"  > 

                  Plant 

                      Detail</td>

                  <td width="370"  colspan="3"  style="text-align: center"> 

                  

					4x3.014 G.E</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Plant 

                      Type</td>

                  <td width="370"  colspan="3"  style="text-align: center"> 

                   

                      Combined  Cycle </td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Gross 

                      Capacity</td>

                  <td width="370"  colspan="3"  style="text-align: center"> 

                   

                  12.164  

                    MW</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Fuel 

                      Type</td>

                  <td width="370"  colspan="3"  style="text-align: center"> 

                   

                      						Natural Gas</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Licence 

                      No. </td>

                  <td width="370"  colspan="3"  style="text-align: center"> 

                   

                      IPGL/22/2010</td>

                </tr>

                <tr > 

                  <td width="116"  > 

                  Licence 

                      Details</td>

                  <td width="370"  colspan="3"  style="text-align: center"> 

                   

						<a target="_blank" href="Licences/Generation/IPP-1994/LAG-150%20Generation%20License%20Davis%20Energen%20Ltd-dated%2026-02-2010.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Fauji Kabirwala Power Company Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

								 <tr > 

                  <td width="116"  > 

                    Plant Detail</td>

                  <td width="370"> <div align="center">

					2x48.00 

					MW G.T+ 1 x 74.00 MW S.T.</div>

                    </td>

                </tr>

                <tr > 

                  <td width="116"  >

                  Plant Type</td>

                  <td width="370"   style="text-align: center">

                   

                  170 

                      MW</td>

                </tr>

                <tr > 

                  <td width="116"  >

                  Gross Capacity</td>

                  <td width="370"   style="text-align: center">

                  

                  					Thermal 

                  (Combined 

                      Cycle)</td>

                </tr>

                <tr > 

                  <td width="116"  >

                  Fuel Type</td>

                  <td width="370"   style="text-align: center">

                  

					Natural Gas</td>

                </tr>

                <tr > 

                  <td width="116"  >

                  Licence No. </td>

                  <td width="370"   style="text-align: center">

                            

                            IPGL/05/2003</td>

                </tr>

                <tr > 

                  <td width="116"  >

                  Licence Details</td>

                  <td width="370"   style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-06%20Fauji%20Kabirwala%20Power%20Co%20Ltd/LAG-06%20Generation%20Licen%20Fauji%20Kabirwala%20Power-dated%2030-08-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>



									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Gul Ahmed Energy Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="115"  > 

                  Plant 

                      Detail</td>

                  <td width="371"   style="text-align: center"> 

                  

                    9 x 15.13 MW Diesel Engines (Reciprocating Engines).</td>

                </tr>

                <tr > 

                  <td width="115"  > 

                  Plant 

                      Type</td>

                  <td width="371"   style="text-align: center"> 

                  

                    Thermal (Simple Cycle)</td>

                </tr>

                <tr > 

                  <td width="115"  > 

                  Gross 

                      Capacity</td>

                  <td width="371"   style="text-align: center"> 

                  

                    136.17 MW</td>

                </tr>

                <tr > 

                  <td width="115"  > 

                  Fuel 

                      Type</td>

                  <td width="371"   style="text-align: center"> 

                  

                    RFO</td>

                </tr>

                <tr > 

                  <td width="115"  > 

                  Licence 

                      No. </td>

                  <td width="371"   style="text-align: center"> 

                  

                    IPGL/09/2003</td>

                </tr>

                <tr > 

                  <td width="115"  > 

                  Licence 

                      Details</td>

                  <td width="371"   style="text-align: center"> 

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-10%20Gul%20Ahmed%20Energy%20Ltd/LAG-10%20Generation%20Licen%20Gul%20Ahmed%20Energy%20Ltd-dated%2030-08-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

                <tr > 

                  <td width="115"  > 

                  Licence Modification-I</td>

                  <td width="371"   style="text-align: center"> 

                   

						<a target="_blank" class="default-btn" href="Licences/Generation/IPPs%201994/LAG-10%20Gul%20Ahmed%20Energy%20Ltd/LAG-10%20Modification-I%20GL%20Gul%20Ahmed%20Energy%2019-03-2020%20.PDF">View</a></td>

                </tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Habibullah Coastal Power (Pvt.) Co.</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									  <tr > 

                  <td width="114" >

                  Plant Detail</td>

                  <td width="372"  style="text-align: center">

                            

                            3 x 37 MW G.T.+ 1 x 29 MW S.TE</td>

                </tr>

                <tr > 

                  <td width="114" >

                  Plant Type</td>

                  <td width="372"  style="text-align: center">

                            

                            C.C (Combined Cycle)</td>

                </tr>

                <tr > 

                  <td width="114" >

                  Gross Capacity</td>

                  <td width="372"  style="text-align: center">

                            

                            155 MW</td>

                </tr>

                <tr > 

                  <td width="114" >

                  Fuel Type</td>

                  <td width="372"  style="text-align: center">

                            

                            Natural Gas</td>

                </tr>

                <tr > 

                  <td width="114" >

                  Licence No.

                  </td>

                  <td width="372"  style="text-align: center">

                            

                            IPGL/012/2003</td>

                </tr>

                <tr > 

                  <td width="114" >

                  Licence Details</td>

                  <td width="372"  style="text-align: center">

                   

						<a target="_blank" class="default-btn" href="Licences/Generation/IPP-1994/Habibullah%20Coastal%20Power/LAG-13%20Generation%20Licen%20Habibullah%20Coastal-dt%2030-08-2003.PDF">View</a>

						</td>

                </tr>

                <tr > 

                  <td width="114" >

                  

					Licence	

					Modification-I</td>

                  <td width="372"  style="text-align: center">

                   

						<a target="_blank" class="default-btn" href="Licences/Generation/IPP-1994/Habibullah%20Coastal%20Power/LAG-13%2005-12-2016%20IPGL-Modification-I%20%2016314-20.PDF">View</a>

						</td>

                </tr>

									

										<tr>

                  <td width="114" >

                  

					Licence	

					Modification-II</td>

                  <td width="372"  style="text-align: center">

                   

						<a target="_blank" class="default-btn" href="Licences/Generation/IPP-1994/Habibullah%20Coastal%20Power/LAG-13%20Modification-II%20Habibullah%20Coastal%20Power%2005-11-2020.PDF">View</a>

						</td>

                						</tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Japan Power Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="114" >

                  Plant Detail</td>

                  <td  style="text-align: center">

                            

                            24 x 5.625 MW D.G.

                            (Reciprocating Engines)</td>

                </tr>

                <tr > 

                  <td >

                  Plant Type</td>

                  <td  style="text-align: center">

                            

                            Thermal (Simple Cycle)</td>

                </tr>

                <tr > 

                  <td >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            

                            120 MW</td>

                </tr>

                <tr > 

                  <td >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            

                            RFO</td>

                </tr>

                <tr > 

                  <td >

                  Licence No.

                  </td>

                  <td  style="text-align: center">

                            

                            IPGL/19/2004</td>

                </tr>

                <tr > 

                  <td >

                  Licence Details</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-22%20Japan%20Power%20Generation%20Ltd/LAG-22%20Geneation%20Licen%20Japan%20Power%20Gen%20Ltd%20-dated%2011-05-2004.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

							

							

								

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Kohinoor Energy Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									  <tr > 

                  <td width="114" >

                  Plant Detail</td>

                  <td  style="text-align: center">

                            

                            8 x 15.68 MW D.G+ 1 x 6 S.T. MW</td>

                </tr>

                <tr > 

                  <td >

                  Plant Type</td>

                  <td  style="text-align: center">

                            

                            Thermal (Combined Cycle)</td>

                </tr>

                <tr > 

                  <td >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            

                            131.44 MW</td>

                </tr>

                <tr > 

                  <td >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            

                            RFO</td>

                </tr>

                <tr > 

                  <td >

                  Licence No. </td>

                  <td  style="text-align: center">

                            

                            IPGL/16/2003</td>

                </tr>

                <tr > 

                  <td >

                  Licence Details</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-17%20Kohinoor%20Energy%20Ltd/LAG-17%20Generation%20Licen%20Kohinoor%20Energy%20Ltd-dated%2002-09-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>

                <tr > 

                  <td >

                  

					Licence 

					Modification-I</td>

                  <td  style="text-align: center">

                      	<a target="_blank" href="Licences/Generation/IPP-1994/LAG-17%20KOHINOOR%20EL%20MODIFICATION-I%20GENERATION%20LIC%2015-10-2014%2012800-05.pdf" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

																	 

								</div>

								

							</li>

							<!-- /Accordion -->

							

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>TNB Liberty Power Ltd</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="114" " > 

                   

                      Plant Detail</td>

                  <td width="372" "  style="text-align: center">

                            

                            1 x 155 MW G.T. +1 x &nbsp;80 MW S.T.</td>

                </tr>

                <tr > 

                  <td width="114"  > 

                   

                      Plant Type</td>

                  <td   style="text-align: center"> 

                            

                            Thermal (Combined Cycle)</td>

                </tr>

                <tr > 

                  <td width="114"  > 

                   

                      Gross Capacity</td>

                  <td   style="text-align: center"> 

                             

                            235 MW</td>

                </tr>

                <tr > 

                  <td width="114"  > 

                   

                      Fuel Type</td>

                  <td   style="text-align: center"> 

                             

                            Low BTU Gas</td>

                </tr>

                <tr > 

                  <td width="114"  > 

                   

                      Licence No. 

                      </td>

                  <td   style="text-align: center"> 

                             

                            IPGL/08/2003</td>

                </tr>

                <tr > 

                  <td width="114" > 

                   

                      Licence Details</td>

                  <td  style="text-align: center">  

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-09%20TNB%20Liberty%20Power%20Ltd/LAG-09%20Generation%20Licen%20TNB%20Liberty%20Power%20Ltd-dated%2030-08-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

								

									 

								</div>

								

							</li>

							<!-- /Accordion -->

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Rousch (Pakistan) Power Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="114" >

                  Plant Detail</td>

                  <td width="372"  style="text-align: center">

                            

                            2 x 152 MW G.T. + 1 x 146 MW S.T.</td>

                </tr>

                <tr > 

                  <td >

                  Plant Type</td>

                  <td  style="text-align: center">

                            

                            Combined Cycle</td>

                </tr>

                <tr > 

                  <td >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            

                            450 MW</td>

                </tr>

                <tr > 

                  <td >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            

                            Natural Gas</td>

                </tr>

                <tr > 

                  <td >

                  Licence No.

                  </td>

                  <td  style="text-align: center">

                            

                            IPGL/15/2003</td>

                </tr>

                <tr > 

                  <td >

                  Licence Details 

					&amp;

					

					Modification - I</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-16%20Rousch%20Pakistan%20Power%20Ltd/LAG-16%20Generation%20Licen%20Rousch%20Pakistan%20Power%20Ltd-dated%2002-09-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

								

									 

								</div>

								

							</li>

							<!-- /Accordion -->

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Saba Power Company Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									<tr > 

                  <td width="114" >

                  Plant Detail</td>

                  <td width="372"  style="text-align: center">

                            

                            1 x 136 MW S.T</td>

                </tr>

                <tr > 

                  <td >

                  Plant Type</td>

                  <td  style="text-align: center">

                            

                            Thermal (Simple Cycle)</td>

                </tr>

                <tr > 

                  <td >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            

                            136 MW</td>

                </tr>

                <tr > 

                  <td >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            

                            RFO</td>

                </tr>

                <tr > 

                  <td >

                  Licence No.

                  </td>

                  <td  style="text-align: center">

                            

                            IPGL/11/2003</td>

                </tr>

                <tr > 

                  <td >

                  Licence Details</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-12%20Saba%20Power%20Co%20Pvt%20Ltd/LAG-12%20Generation%20Licen%20Saba%20Power%20-dated%2030-08-2003.PDF" class="default-btn">View</a> 

                      	</td>

                </tr>

									

								</table>

								

									 

								</div>

								

							</li>

							<!-- /Accordion -->

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Southern Electric Power Company Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

								  <tr > 

                  <td width="113" >

                  Plant Detail</td>

                  <td width="373"  style="text-align: center">

                            

                            5 x 23.4 MW Diesel 

							Generators

							(Reciprocating Engines)</p>

                            </td>

                </tr>

                <tr > 

                  <td >

                  Plant Type</td>

                  <td  style="text-align: center">

                            Thermal (Simple Cycle)</td>

                </tr>

                <tr > 

                  <td >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            117 MW</td>

                </tr>

                <tr > 

                  <td >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            RFO</td>

                </tr>

                <tr > 

                  <td >

                  Licence No.

                  </td>

                  <td  style="text-align: center">

                            IPGL/18/2004</td>

                </tr>

                <tr > 

                  <td >

                  Licence Details</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-20%20Southern%20Electric%20Co%20Ltd/LAG-20%20Generation%20Licen%20Southern%20Electric%20Power%20Co%20Ltd-dated%2011-05-2004.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

								</table>

								

									 

								</div>

								

							</li>

							<!-- /Accordion -->

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Tapal Energy Private Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									 <tr > 

                  <td width="300" >

                  Plant Detail</td>

                  <td width="1034"  style="text-align: center">

                            

                            9 x 15.13 MW Diesel Engines

                            (Reciprocating Engines).</p>                            </td>

                </tr>

                <tr > 

                  <td >

                  Plant Type</td>

                  <td  style="text-align: center">

                            Thermal (Simple Cycle)</td>

                </tr>

                <tr > 

                  <td >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            126 MW</td>

                </tr>

                <tr > 

                  <td >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            RFO</td>

                </tr>

                <tr > 

                  <td >

                  Licence No.                  </td>

                  <td  style="text-align: center">

                            IPGL/10/2003</td>

                </tr>

                <tr > 

                  <td >

                  Licence Details</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-11%20Tapal%20Energy%20Pvt%20Ltd/LAG-11%20Generation%20Licen%20Tapal%20Energy%20-dated%2030-08-2003.PDF" class="default-btn">View</a>						</td>

                </tr>

                <tr > 

                  <td >

                  Licence Modification-I</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPP-1994/Tapal%20Energy%20Limited/LAG-11%20GL%20Tapal%20Energy%2020-11-2018.PDF" class="default-btn">View</a>						</td>

                </tr>

                <tr >

                  <td >Licence Modification-II</td>

                  <td  style="text-align: center"><a target="_blank" href="Licences/Generation/IPP-1994/Tapal Energy Limited/LAG-11 GL Tapal Energy 09-03-2020.PDF" class="default-btn">View</a></td>

                </tr>

								</table>

								

									 

								</div>

								

							</li>

							<!-- /Accordion -->

							<!-- Accordion -->

							<li class="accordion">

								

								<div class="accordion-header" >

									<div class="accordion-icon"></div>

									<h6>Uch Power Limited</h6>

									

								</div>

								

								<div class="accordion-content">

									 

								<table border="1" width="100%">

									  <tr > 

                  <td width="119" >

                  Plant Detail</td>

                  <td  style="text-align: center">

                            3 x 130 G.T. + 1 x 190 S.T.</td>

                </tr>

                <tr > 

                  <td width="119" >

                  Plant Type</td>

                  <td  style="text-align: center">

                            Combined Cycle</td>

                </tr>

                <tr > 

                  <td width="119" >

                  Gross Capacity</td>

                  <td  style="text-align: center">

                            586.2 MW</td>

                </tr>

                <tr > 

                  <td width="119" >

                  Fuel Type</td>

                  <td  style="text-align: center">

                            Low BTU Gas</td>

                </tr>

                <tr > 

                  <td width="119" >

                  Licence No. </td>

                  <td  style="text-align: center">

                            IPGL/14/2003</td>

                </tr>

                <tr > 

                  <td width="119" >

                  Licence Details</td>

                  <td  style="text-align: center">

                   

						<a target="_blank" href="Licences/Generation/IPPs%201994/LAG-15%20Uch%20Power%20Ltd/LAG-15%20Generation%20Licen%20Uch%20Power%20Ltd-dated%2030-08-2003.PDF" class="default-btn">View</a>

						</td>

                </tr>

									

                <tr > 

                  <td width="119" >

                  08-05-2023 - DETERMINATION OF THE AUTHORITY IN THE MATTER OF 
					APPLICATION OF UCH POWER (PRIVATEI LIMITED FOR RENEWAL OF 
					ITS GENERATION LINCENCE </td>

                  <td  style="text-align: center">

                   

						<a target="_blank" class="default-btn" href="Licences/Generation/IPPs%201994/LAG-15%20Uch%20Power%20Ltd/LAG-15%20Determination%20of%20Uch%20Powr%20for%20renewal%20of%20Generation%20Licence%2008-05-2023.PDF">View</a>

						</td>

                </tr>

									

								</table>

								

									 

								</div>

								

							</li>

							<!-- /Accordion -->

							

							

						</ul>

						<!-- /Accordions -->					

					

                                

                            </div>

                       

                   <div class="col-lg-3 col-md-5">

                        <div class="sidebar-area">

                           

                            <div class="widget widget_recent_posts">

                                <h3 class="widget-title">Quick Links </h3>

                                <ul>

                                    <li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 1994.php">

                                                <img src="../assets/img/licences/1994.jpg" height="110" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <br><h3><a href="Generation IPPs 1994.php">IPPs 1994 </a> </h3>  <br>

                                            

                                        </div>

                                    </li>

                                    <li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 1995 Hydel.php">

                                                <img src="../assets/img/licences/1995.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                           <br> <h3><a href="Generation IPPs 1995 Hydel.php">IPPS 1995 Hydel<br></a></h3><br>

                                            

                                        </div>

                                    </li>

                                    <li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 2002.php">

                                                <img src="../assets/img/licences/2002.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                           <br> <h3><a href="Generation IPPs 2002.php">IPPs 2002</a></h3> <br>

                                            

                                        </div>

                                    </li>



                                    <li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs RE 2006.php">

                                                <img src="../assets/img/licences/2006.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                           <br> <h3><a href="Generation IPPs RE 2006.php">IPPs 2006 RE</a></h3><br>

                                            

                                        </div>

                                    </li>

									<li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 2006 punjab.php">

                                                <img src="../assets/img/licences/punjab.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <br><h3><a href="Generation IPPs 2006 punjab.php">IPPs 2006 Punjab</a></h3><br>

                                           

                                        </div>

                                    </li>

									<li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 2006 kpk.php">

                                                <img src="../assets/img/licences/kpk.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <br><h3><a href="Generation IPPs 2006 kpk.php">IPPs 2006 KPK</a></h3>

                                            <br>

                                        </div>

                                    </li>

									<li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 2007 Balochistan.php">

                                                <img src="../assets/img/licences/balochistan1.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <h3 align="left"><a href="Generation IPPs 2007 Balochistan.php">IPPs 2007 Balochistan</a></h3>

                                            <br>

                                        </div>

                                    </li>

									<li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs 2015.php">

                                                <img src="../assets/img/licences/2015.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <br><h3><a href="Generation IPPs 2015.php">IPPs 2015</a></h3>

                                            <br>

                                        </div>

                                    </li><li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs others.php">

                                                <img src="../assets/img/licences/others.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <br><h3><a href="Generation IPPs others.php">IPPs Others</a></h3>

                                            <br>

                                        </div>

                                    </li>

									<li>

                                        <div class="recent-post-thumb">

                                            <a href="Generation IPPs short term.php">

                                                <img src="../assets/img/licences/stipps.jpg" alt="blog-image">

                                            </a>

                                        </div>



                                        <div class="recent-post-content">

                                            <br><h3><a href="Generation IPPs short term.php">IPPs Short Term</a></h3>

                                            <br>

                                        </div>

                                    </li>

                                </ul>

                            </div>



                        </div>

                    </div>

                </div>

            </div>

        </div>

        <!-- End Blogs Section -->



        

        

       

         <!-- Start Top Footer Section -->

		<!-- Start Top Footer Section -->
        <footer class="footer-top footer-top-four">
            <div class="container">
                <div class="row">
                    
					<div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Contact</h3>
                            <ul>
                               
								<li>
                                    National Electric Power Regulatory Authority
                                </li>
								<li>
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
									
                                    
                                    NEPRA Tower, G-5/1, Islamabad 
                                </li>
                                <li>
                                    <i class="flaticon-mail-black-envelope-symbol"></i>
                                    
                                    <a href="/cdn-cgi/l/email-protection#731a1d151c331d160301125d1c01145d0318"><span class="__cf_email__" data-cfemail="3950575f5679575c494b5817564b5e174952">[email&#160;protected]</span></a>                                </li>
                                <li>
                                    <i class="flaticon-telephone-handle-silhouette"></i>
                                    
                                    +92 51 2013200 
                                </li>
                                <li>
                                    <i class="flaticon-call"></i>
                                    
                                    +92 51 9210215  
                                </li>
								
                            </ul>
                        </div>

                    </div>
					
                    
                    <div class="col-lg-3 col-md-4 col-sm-4">
                        <div class="single-widget mb-30">
                            <h3>Important Links</h3>
                            <ul>
                                
                                <li>
								<li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="https://www.sifc.gov.pk">SIFC</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a target="_blank" href="licensing/Licences/SOPs/Timelines flow chart check list.pdf">SOPs of Licensing</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Power Policies.php">Power Policies</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://nepra.org.pk/Admission%20Notices/2019/Intervention%20Request%20Form.pdf" target="_blank">Intervention Request Form</a>                                </li>
                                <li>
                                    <i class="flaticon-right"></i>
                                    <a href="https://webmail.nepra.org.pk:2096/" target="_blank">E-mail (NEPRA Officials Only)</a>                                </li>
                                
                            </ul>
                        </div>
                    </div>
					 <div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                            <h3>Search Website</h3>
                            <div><script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script async src="https://cse.google.com/cse.js?cx=014945713357202780521:kaf1vdqbqiv"></script>
<div class="gcse-searchbox-only"></div></div> <br>
<a href="https://play.google.com/store/apps/details?id=com.govpk.citizensportal&hl=en"><img src="../assets/img/Pakistan Citzen Portal Banner.png" /></a>                    </div>
                    
                </div>
           
			<div class="col-lg-3 col-md-6 col-sm-6">
                       <div class="single-widget mb-30">
                           
<img src="../assets/img/FBR - ABI Flyer.jpg" />                  </div>
                    
                </div>
            </div>
        </footer>
        <!-- End Top Footer Section -->

        <!-- Start Bottom Footer Section -->
        <footer class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <ul>
                                <li>
                                    <p>NEPRA Copyright 2023. All Rights Reserved.</p> </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-widget">
                            <p><i class="flaticon-clock-of-circular-shape-outline"></i> Open Hours 9:00 AM - 5:00 PM</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                        <div class="single-widgets">
                            <ul class="social-links">
                                <li>
                                    <a href="https://twitter.com/NEPRA5" target="_blank"><i class="flaticon-twitter-black-shape"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.youtube.com/channel/UCzxdd9BgjpigYC7seUT3JhA" target="_blank"><i class="flaticon-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.facebook.com/neprapakistan/" target="_blank"><i class="flaticon-facebook-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://www.linkedin.com/company/nepra-national-electric-power-regulatory-authority/"  target="_blank"><i class="flaticon-linkedin-logo"></i></a>
                                </li>
                                <li>
                                    <a href="https://mail.nepra.org.pk"><i class="flaticon-mail-black-envelope-symbol"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        
        <!-- End Bottom Footer Section -->
		<!-- Stop  Footer Section -->

     



        <!-- Jquery-3.2.1.Slim.Mim.JS -->

       <script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/jquery.waypoints.min.js"></script>
<script src="../assets/js/owl.carousel.min.js"></script>

        <!-- Popper.Mim.JS -->

        <script src="../assets/js/popper.min.js"></script>

        <!-- Bootstrap.Mim.JS -->

        <script src="../assets/js/bootstrap.min.js"></script>

        <!-- Meanmenu.JS -->

        <script src="../assets/js/jquery.meanmenu.js"></script>

        <!-- Magnific.Popup.Min.JS -->

	    <script src="../assets/js/jquery.magnific-popup.min.js"></script>

        <!-- Owl.Carousel.Min.JS -->

        <script src="../assets/js/owl.carousel.min.js"></script>

        <!-- Wow.Min.JS -->

		<script src="../assets/js/wow.min.js"></script>

        <!-- Waypoints.Min.JS -->

		<script src="../assets/js/waypoints.min.js"></script>

		<!-- Jquery.Counterup.Min.JS -->

		<script src="../assets/js/jquery.counterup.min.js"></script>

		<!-- Jquery.Mixitup.Min.JS -->

		<script src="../assets/js/jquery.mixitup.min.js"></script>

        <!-- Active.JS -->

        <script src="../assets/js/active.js"></script>

		<script src="../assets/js/script.js"></script>

    </body>

</html>